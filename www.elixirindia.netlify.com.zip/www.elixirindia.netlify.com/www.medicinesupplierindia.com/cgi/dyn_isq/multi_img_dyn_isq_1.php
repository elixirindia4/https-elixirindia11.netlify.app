<div class="tdw_pp" style="display:none;" id="ffc_blow_up">
<div class="tdw_pp_c tdw_pp_bg1 tdw_pp_c_tnku" id="blwup">
<div class="tdw_pp_s tdw_pp_df">
<div class="load_div" id="form_load" style="display: none;"><img class="load_img" id="loadImg" alt="Please wait" src="https://tdw.imimg.com/template-tdw/loader.gif"></div>
<div id="default_icon" class="tdw_pp_pi tdw_pp_df tdw_pp_ai tdw_pp_jc cen2_p" style="display:none"><img class="ImgF_p" alt="Send Your Enquiry" src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA="  dataimg="https://tdw.imimg.com/template-tdw/send_enq.png"></div>
<div class="tdw_pp_tnarror prd_f_imgform" id="infocus_div">
<span class="tdw_pp_at" id="arrw1" style="display:none;" onclick="return slide('thumbnail-containerpop','up');"><span class="lArrow tdw_pp_cp"><svg xmlns="http://www.w3.org/2000/svg" width="22.828" height="12.828" viewBox="0 0 22.828 12.828" class="pa t0 l0"><g id="Group_3877" data-name="Group 3877" transform="translate(1.414 1.414)"><path id="Line_466" d="M0 10L10 0" class="cls-1" data-name="Line 466"></path><path id="Line_467" d="M10 10L0 0" class="cls-1" data-name="Line 467" transform="translate(10)"></path></g></svg></span></span>
<span class="tdw_pp_ab" id="arrw2" style="display:none;" onclick="return slide('thumbnail-containerpop','down');"><span class="rArrow tdw_pp_cp"><svg xmlns="http://www.w3.org/2000/svg" width="22.828" height="12.828" viewBox="0 0 22.828 12.828"><g id="Group_3875" data-name="Group 3875" transform="translate(-61.086 -900.086)"><path id="Line_466" d="M0 0l10 10" class="cls-1" data-name="Line 466" transform="translate(62.5 901.5)"></path><path id="Line_467" d="M10 0L0 10" class="cls-1" data-name="Line 467" transform="translate(72.5 901.5)"></path></g></svg></span></span>
<div id="multi_img_box" class="prd_f_imgform"></div>
</div>
<div class="tdw_pp_pi" id="imgbox">
<a id="bimg_zoom_up_center" class="anc_img tdw_imgc tdw_pp_bg1 tdw_pos_rel"><img class="heading_zoom mx_p" src="data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=" alt="company name"></a>
<p class="prd_f prd_bimgname tdw_w100" id="bimgname_zoom_title"></p><p id="bimgname_zoom_price" class="tdw_pb7 fw_p prd_f"></p>
<p class="tdw_pb7 tdw_pp_clr1 tdw_pp_fs13 prd_f" id="compdiv">Sold By- <span id="cmpname" class="tdw_clr1">Mehadia Tradelinks</span></p>
<div id="add_isq_det" class="tdw_pp_clr1 tdw_pp_fs13 prd_f"></div>
</div>
<div id="productform" class="tdw_w100">
<div class="tdw_pp_f1">
<FORM ACTION="/cgi/dyn_isq/autotdw_enq_pop_dyn_isq_1.php" METHOD="POST" NAME="zoom_dataform" ENCTYPE="multipart/form-data" class="zoom_dataform" onsubmit="return validate_bind_zoom_popup()">	
<INPUT TYPE="hidden" NAME="required" VALUE="Description,S_country,S_mobile" > 
<INPUT TYPE="hidden" NAME="S_referer" ID="refer_detail" VALUE="">
<INPUT TYPE="HIDDEN" NAME="enqform_type" ID="enqform_type" VALUE="">
<INPUT TYPE="HIDDEN" NAME="enqform_cta" ID="enqform_cta" VALUE="">
<INPUT TYPE="hidden" NAME="usr_login_mode" ID="usr_login_mode" VALUE="3">
<INPUT TYPE="hidden" NAME="S_current_url" ID="current_refer_detail" value="">
<INPUT TYPE="hidden" NAME="S_reference_text" ID="reference_text_detail" VALUE="">
<input TYPE="hidden" NAME="sort" VALUE="order:Item Required,Description">
<input TYPE="hidden" NAME="Item Required" VALUE="" ID="zoom_cart_details">
<input type="hidden" name="modref_id" value="">
<input type="hidden" name="modref_type" value="2">
<input TYPE="hidden" NAME="gluser_id" VALUE="11156742">
<input type="hidden" name="S_glusr_id" value="">
<input type="hidden" name="style_id" value="1160">
 <INPUT TYPE="hidden" NAME="modid" VALUE="TDW"><input type="hidden" name="country_iso" id="country_iso" value="IN" class="cnty_iso">
<input id="txtCountry_pop" type="hidden" value="India" name="S_country" class="cnty_name">
<input type="hidden" name="country" value="IN" ID="txtCountry1" class="cnty_iso">
<input value="+91"  name="S_phone_country_code" type="hidden" id="S_phone_country_code_pop" class="cnty_isd">
<input name="S_name" type="hidden" id="firstnamefs">
<input name="S_lname" type="hidden" id="lastnamefs">
<input name="S_organization" type="hidden" value="" id="S_organization">
<INPUT TYPE="hidden" NAME="twostep" ID="twostep" VALUE=""> 
<input type="hidden" name="modref_name" id="modref_name" value="">
<input type="hidden" name="mcat_id" id="mcat_id" value=""> 
<div id="dataform_alert_display" style="display:none;" class="h14_p txc_p">
<div class="tnkmsg1"><div class="m47_p tdw_pp_mb10 fw_p tdw_fs20"><i class="cHkIcon"></i>Thank You!</div>
<div id="tnk_msg_other" class="tdw_pp_mb10" data-role="" style="">Your requirement has been sent to <span class="fw_p">Mehadia Tradelinks</span></div>
<div id="tnk_msg_rcb" class="tdw_pp_mb10" data-role="" style="">We will get back shortly for better understanding of your requirement</span></div>
</div>
<div class="tdw_fbg txc_p"><a target="_blank" href="https://paywith.indiamart.com/invoice/#/mdc/11156742" onclick="_gaq.push(['b._trackEvent','Bottom','paywithim/thanku','d0005'])"><span class="thk_sprt pay_lgo"></span><div class="tdw_clr1">Protect your payments for <span class="fw_p">FREE,</span> Pay sellers online via <span class="fw_p">Pay with IndiaMART</span></div><div class="thk_info tdw_clr1 tdw_mt10 tdw_mb15 tdw_fs11 fw_p"><span><span class="thk_sprt thk_bprt"></span> 100% Buyer Protection</span><span><span class="thk_sprt thk_payopt"></span> Multiple Payment Options</span><span><span class="thk_sprt thk_bnow"></span> Buy Now, Pay At Ease </span></div><div class="thk_last tdw_fs11 tdw_clr1"><span>Credit Card   &nbsp;|&nbsp;   UPI / Wallet / Net Banking   &nbsp;|&nbsp;   Cardless EMI   &nbsp;|&nbsp;   Pay Later</span><br><span class="thk_knmr fw_p">Know More  &gt;</span></div></a></div></div>
<div id="dataform_alert_display_search" style="display:none;"><p class="fnt3_zoom3"><span class="rght_p blow"></span><span class="ft10_p">Thank you !</span><br>Your requirement has been sent successfully.</p></div>
<div id="dataform_alrt">
<p class="tdw_pp_pn prd_f_imgform fw_p" id="bimgname_zoom_title_imgform"></p>
<p class="tdw_pp_pn_p tdw_pp_mb10 tdw_pp_fs14 tdw_pp_clr1 prd_f_imgform">
<span id="bimgname_zoom_price_imgform" class="pp_m8"></span>Sold By- <span id="cmpname_imgform" class="tdw_clr1">Mehadia Tradelinks</span></p>
<p class="prd_f tdw_unidt">
<span id="prd_form"><span id="txt_id" class="fw_p"></span> and details from "<span class="compname">Mehadia Tradelinks</span>" on your mobile quickly</span>
<span id="non_prd_form">Connect with "<span class="compname fw_p" id=cmpname_s>Mehadia Tradelinks</span>"</span>
<span id="auto_zoom_form">Share your requirement with "<span class="compname fw_p" id=cmpname_s>Mehadia Tradelinks</span>"</span>
</p>
<h2 class="prd_f_imgform" id='imgf_head'>Get customised quotes from us</h2>
<h2 class="prd_f tdw_fwn tdw_clr1" id="ipt_fld_head">Mobile Number</h2>
<div class="tdw_f_cc_f tdw_eqq" id="int_fd_err">
<input type="text" readonly id="mobile-number_zoom_dataform" name="S_cmobile" value="+91"  class="cnty_isd" onblur="check_country_flag();" autocomplete="off">
<div id="mobilefield_zoom_dataform" style="display:block">
<input type="text" name="S_mobile" placeholder="Enter your mobile" id="S_mobile2" onblur="check_Mobile2();" tabindex="3" onclick="javascript:check_Mobile_focus(this);" onkeydown="javascript:check_Mobile_focus(this);" autocomplete="off" maxlength="10"></div>
<div id ="emailfield_zoom_dataform" style="display:none"><input type="text" class="tdw_frgneml" id="S_email" name="S_email" tabindex="2" placeholder="Enter your email" tabindex="2" onblur="check_Email2();" onkeydown="check_Email_focus(this,event);" onclick="check_Email_focus(this);" autocomplete="off"></div>
<span id="m1" class="error_notification2" style="display:none"></span><span id="e1_pop" class="error_notification2" style="display:none"></span>
</div>
<p class="tdw_pp_clr2 tdw_pp_fs12 m13_p" id="tnkMsg"></p>
<div class="tdw_pp_ff2 tdw_eqq"><textarea class="c11_p" name="Description1" id="Description1" onclick="check_Description_focus(this);" onblur="check_Description2();" tabindex="1" style="display:none" ></textarea><span id="d1" class="error_notification2" style="display:none"></span></div> 
<input type="hidden" name="Description" value="">
<div id="3pv_desc" style="display:none" class="tdw_f_cc_f tdw_f_cc_eml"><input type="text" tabindex="2" class="c11_p" value="Product/Service" autocomplete="off" name="ss_frm" id="ss_frm" onclick="searchClear_frm();" onblur="check_ss_frm();" onfocus="searchClear_frm();" maxlength="60"><span id="s1" class="error_notification2" style="display: none;">Kindly Describe Your Requirement.</span></div>
<div class="tdw_f_cc_f tdw_f_cc_f_eml m41_p" id="S_name_zoom_dataform"><input type="text" class="c11_p" id="fullnamefs" name="fullname" tabindex="4" value="Enter your name" onblur="check_Fullname2();" onclick="check_Fullname_focus(this);" onkeydown="check_Fullname_focus(this);" autocomplete="off" style="border: none;"><span id="f1" class="error_notification2" style="display:none"></span></div>
<div class="tdw_f_cc_f tdw_eqq" id="int_fd_err1" style="display:none">
<input type="text" readonly id="mobile-number1_zoom_dataform" name="S_cmobile" value="+91"  class="cnty_isd" onblur="check_country_flag();" autocomplete="off">
<div id="mobilefield_zoom_dataform" style="display:block">
<input type="text" name="S_mobile1" placeholder="Enter your phone number" id="S_mobile2" onblur="check_Mobile2();" tabindex="5" onclick="javascript:check_Phone_focus(this);" onkeydown="javascript:check_Phone_focus(this);" autocomplete="off" maxlength="20"></div>
<span id="m2" class="error_notification2" style="display:none"></span>
</div>
<p class="tdw_pp_clr2 tdw_pp_fs12 m13_p" id="tnkMsg"></p>
<div id="isq_fields_imgf" class="tdw_isqs" style="display: none;">
<div id="isq_imgf" style="display: block;"><input type="text" class="tdw_pp_rbs" name="Quantity"><select class="tdw_pp_qstn tdw_pp_clr1 tdw_pp_mb10 tdw_pp_fs13" style="border-left: none;" name="Qunt_Unt_imgf" id="Quan_unt" onchange="changeSelectField(this)"></select><input style="display:none;" class="isq_quntu" id="cust_qunt_val" onblur="inp_sel_blr(this)" disabled="" autocomplete="off" placeholder="Enter custom unit"></div>
</div>
<div class="tdw_pp_cta " id="contact_btn"><input type="submit" Value="Submit Now" class="tdw_pp_cp tdw_f16" tabindex="4" id="SubmitEnq"><div class="enqload"></div></div> 
<div class="tdw_pp_cta " id="contact_btn1" style="display:none"><input type="submit" Value="Contact Now" class="tdw_pp_cp tdw_f16" tabindex="4"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="ask_price" style="display:none"><input type="submit" Value="Submit Now" class="tdw_pp_cp tdw_f16" tabindex="4"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="GetLatestPrice" style="display:none"><input type="submit" Value="Submit Now" class="tdw_pp_cp tdw_f16" tabindex="4"><div class="enqload"></div></div> 
<div class="tdw_pp_cta " id="GetBestQuote" style="display:none"><input type="submit" Value="Submit Now" class="tdw_pp_cp tdw_f16" tabindex="4"><div class="enqload"></div></div> 
<div class="tdw_pp_cta " id="ImgForm" style="display:none"><input type="submit" Value="Get Quotes" class="tdw_pp_cp tdw_f16" tabindex="4" id="SubmitEnq"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="Imgf_iden_usr" style="display:none"><input type="submit" Value="Contact Us" class="tdw_pp_cp tdw_f16" tabindex="4" id="SubmitEnq"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="GetBestQuote_video" style="display:none"><input type="submit" Value="Submit Now" class="tdw_pp_cp tdw_f16" tabindex="4" id="SubmitEnq"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="Rcb_btn" style="display:none"><input type="submit" Value="Submit Now" class="tdw_pp_cp tdw_f16" tabindex="4"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="searchnotfound2" style="display:none"><input type="submit" Value="Submit Now" class="tdw_pp_cp tdw_f16" onclick="_gaq.push(['b._trackEvent','Body','SendEnquiry/Notfound-SP','d0005']);"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="Sbt_sendSMS" style="display:none"><input type="submit" Value="Submit" class="tdw_pp_cp tdw_f16"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="Sbt_sendEmail" style="display:none"><input type="submit" Value="Submit" class="tdw_pp_cp tdw_f16"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="Sbt_getInTouch" style="display:none"><input type="submit" Value="Submit" class="tdw_pp_cp tdw_f16" onclick="_gaq.push(['b._trackEvent','Body','GetInTouch/2/homepage','d0005']);"><div class="enqload"></div></div>
<div class="tdw_pp_cta " id="Sbt_CallUs" style="display:none"><input type="submit" Value="Submit" class="tdw_pp_cp tdw_f16"><div class="enqload"></div></div>
</div></form></div>
<div class="tdw_pp_f1 tdw_pp_f2" id="twostepenquiry" style="display:none"></div>
<div class="tdw_pp_f1 tdw_pp_f3" id="otpverification" style="display:none"></div>
<div class="tdw_pp_bcd tdw_pp_fs14" id="contInfo" style="display:none"><p class="tdw_pp_clr2"><b>Your Contact Information</b></p><p class="tdw_pp_clr1" id="twostepusrname"></p><p class="tdw_pp_clr1" id="twostepph_em"></p></div>
</div>
<p class="tdw_pp_cls tdw_pp_cp" onclick="javascript:fg_hideform_zoom();_gaq.push(['b._trackEvent','Body','ProductZoom/Close','d0005']);" id="closebtn"></p>
</div></div></div>
<script>var current_url=document.URL;
document.getElementById('current_refer_detail').value = current_url;
var REMOTE_ADDR ="101.0.63.2";
</script>
<style>
	.tdw_f_cc_f .intl-tel-input>input{width: 85px;}
	.tdw_f_cc_f #mobilefield_zoom_dataform>input{padding-left: 100px;}
	.m41_p{margin-top: 8px;}
	#tnkMsg{line-height: 20px;}
</style>