
    <style>.slr_rew{padding:10px 20px 20px;line-height:20px} .slr_rew>p:last-child{line-height:20px} .rvw_img>span{min-width:100px;max-width:100px;min-height:100px;max-height:100px;border:#d8d8d8 1px solid;border-radius:4px;} .rvw_img>span img{max-width:100px;max-height:100px}
.revw-user:not(:last-of-type) {border-right: 1px solid #e4e4e4;} .grph-area {width: 155px;} .rtng-grph{padding-right:55px} .revw-date{min-width:95px} .rtng-stfn{padding-left:55px} .stfn-name{margin-right:5px} .fs30 {font-size: 30px} .rpdr-nme>span:first-child {min-width: 104px;max-width: 104px;}
.slr_rew p{text-align:left}
@media screen and (max-width:1024px){
.grph-item{font-size:16px} .revw-date{font-size:12px;} .revw-like .stfn-thmup{margin-left:5px} .revw-like .stfn-name{margin-right:4px;font-size:13px} .grph-area {width:155px;} .rtng-stfn {padding-left:40px;} .rpr60 {padding-right:50px;}
.rvw_img>span{min-width:100px;max-width:100px;min-height:100px;max-height:100px;margin-right:7px;}
.rvw_img>span img {max-width:100px;max-height:100px;}
}
</style>
<h2  >Ratings & Reviews </h2>


<div class="rtng-inr rmt20 rdf rfww rjcc cont6"> 
<div class="rtng rdf m6">
    <div class="rtng-gred rclr2 rpr60">
        <div class="rdf"><span class="rtng-get"><span class="fs30 fwb" title="4.3 out of 5 Votes">4.3<span class="fs18">/5</span></span></span>        <div class="revw-star rdib rpr  "> <span class="star-clr fs30 rpa rzi1 roh" style="width:86%">&starf;&starf;&starf;&starf;&starf;</span><span class="fs30">&starf;&starf;&starf;&starf;&starf;</span></div></div>
        <p class="rtng-cont fs14">Reviewed by 438 Users</p>
    </div>

    <ul class="rtng-grph rpr60 lh0">
        <li class="grph-item wsnw ft5_p rclr1 ft5_p"><span>5&starf;</span><span class="grph-area rpr rdib rml10"><span class="grph-fill rdb rpa" style="width:67.123287671233%"></span></span><span class="grph-count rml10 rdib">67%</span></li>
        <li class="grph-item rclr1 ft5_p"><span>4&starf;</span><span class="grph-area rpr rdib rml10"><span class="grph-fill rdb rpa" style="width:9.5890410958904%"></span></span><span class="grph-count rml10 rdib">10%</span></li>
        <li class="grph-item rclr1 ft5_p"><span>3&starf;</span><span class="grph-area rpr rdib rml10"><span class="grph-fill rdb rpa" style="width:3.8812785388128%"></span></span><span class="grph-count rml10 rdib">4%</span></li>
        <li class="grph-item  rclr1 ft5_p"><span>2&starf;</span><span class="grph-area rpr rdib rml10"><span class="grph-fill rdb rpa" style="width:3.1963470319635%"></span></span><span class="grph-count rml10 rdib">3%</span></li>
        <li class="grph-item  rclr1 ft5_p"><span>1&starf;</span><span class="grph-area rpr rdib rml10"><span class="grph-fill rdb rpa" style="width:16.2100456621%"></span></span><span class="grph-count rml10 rdib">16%</span></li>
</ul>


<!--User Satisfaction section Start -->
    <ul class="rtng-stfn rasc lh0 "> 
        <li class="stfn-hdng txc_p fs20 rclr2 ">
        <span class="stfn-thmup vr1"><svg height="24" viewBox="0 0 24 24" width="24" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span>User Satisfaction</li>
        <li class="grph-item rclr1 wsnw ft5_p "><span class="stfn-area rdib">Response</span><span class="grph-area rpr rdib rml10"><span class="grph-fill rdb rpa" style="width:80%"></span></span><span class="grph-count rml10 rdib">80%</span></li>
        <li class="grph-item rclr1 ft5_p "><span class="stfn-area rdib">Quality&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="grph-area rpr rdib rml10"><span class="grph-fill rdb rpa" style="width:83%"></span></span><span class="grph-count rml10 rdib">83%</span></li>
        <li class="grph-item rclr1 ft5_p "><span class="stfn-area rdib">Delivery&nbsp;&nbsp;&nbsp;</span><span class="grph-area rpr rdib rml10"><span class="grph-fill rdb rpa" style="width:81%"></span></span><span class="grph-count rml10 rdib">81%</span></li>
    </ul>
<!--User Satisfaction section End -->
</div>
<!--Rating Short By and Comment section Start -->
<div class="revw w100 rmt20">
    <div class="revw-shrt raic"><p class="fwb rclr2 fnt24">Most Relevant Reviews</p></div>
<!--Rating Comment section Start -->
        <div class="reww-item rmt20 w100 rdf lh2">
            <div class="revw-user rdf">
                <div class="revw-latr rimgc rclr1 fwb fs20 ">C</div>
        <div class="revw-detl fs13 rml5  w1">
		<div class="rdf jcsb">		<div class="revw-star rpr"><span class="star-clr fs18 rpa rzi1 roh" style="width:100%">★★★★★</span><span class="fs18">★★★★★</span></div>
		<div class="rclr1 revw-date">17-November-21</div>
		</div>
		<div class="revw-nme rclr1 fnt21">Carlo</div>
				<div class="revw-citylh4">United Kingdom</div>
        		<div class="rpdr-nme rdf  lh4 rmt5"><span class="rclr1">Product Name :</span> <span class="lne2txt ov">Ivermectin Tablets</span></div>
         
        <div class="revw-comnt  ln6 mr11 ">All good</div>
                <div class="revw-like rdf m13  ">
                        <div class="stfn-name rdf raic">Response <span class="stfn-thmup rdf raic rml10"><svg height="20" viewBox="0 0 24 24" width="20" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span></div>
                                            <div class="stfn-name rdf raic">Quality <span class="stfn-thmup rdf raic rml10"><svg height="20" viewBox="0 0 24 24" width="20" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span></div>
                                           <div class="stfn-name rdf raic">Delivery <span class="stfn-thmup rdf raic rml10"><svg height="20" viewBox="0 0 24 24" width="20" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span></div>
                           </div>
<div class="rvw_img mr11df raic rfww ovh">
<span class="rdf raic rjcc mr20"><img src="https://5.imimg.com/data5/IOS/RatingImage/2021/11/SJ/AB/TH/140621978/product-jpeg-500x500.png"  alt="reviewImg1"  ></span>
<span class="rdf raic rjcc mr20"><img src="https://5.imimg.com/data5/IOS/RatingImage/2021/11/EK/XT/DO/140621978/product-jpeg-500x500.png"  alt="reviewImg1"  ></span>
</div>
        </div>
        </div>
<div class="revw-user rdf">
                <div class="revw-latr rimgc rclr1 fwb fs20 ">C</div>
        <div class="revw-detl fs13 rml5  w1">
		<div class="rdf jcsb">		<div class="revw-star rpr"><span class="star-clr fs18 rpa rzi1 roh" style="width:100%">★★★★★</span><span class="fs18">★★★★★</span></div>
		<div class="rclr1 revw-date">17-January-23</div>
		</div>
		<div class="revw-nme rclr1 fnt21">Cordell Goody</div>
				<div class="revw-citylh4">Spain</div>
        		<div class="rpdr-nme rdf  lh4 rmt5"><span class="rclr1">Product Name :</span> <span class="lne2txt ov">Sodium Valproate Tablet</span></div>
         
        <div class="revw-comnt  ln6 mr11 ">Hassle free service.</div>
                <div class="revw-like rdf m13  ">
                        <div class="stfn-name rdf raic">Response <span class="stfn-thmup rdf raic rml10"><svg height="20" viewBox="0 0 24 24" width="20" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span></div>
                                            <div class="stfn-name rdf raic">Quality <span class="stfn-thmup rdf raic rml10"><svg height="20" viewBox="0 0 24 24" width="20" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span></div>
                           </div>
        </div>
        </div>
<div class="revw-user rdf">
                <div class="revw-latr rimgc rclr1 fwb fs20 ">M</div>
        <div class="revw-detl fs13 rml5  w1">
		<div class="rdf jcsb">		<div class="revw-star rpr"><span class="star-clr fs18 rpa rzi1 roh" style="width:100%">★★★★★</span><span class="fs18">★★★★★</span></div>
		<div class="rclr1 revw-date">28-October-22</div>
		</div>
		<div class="revw-nme rclr1 fnt21">Mandara Shetty</div>
				<div class="revw-citylh4">Krishnarajanagara, Karnataka</div>
        		<div class="rpdr-nme rdf  lh4 rmt5"><span class="rclr1">Product Name :</span> <span class="lne2txt ov">Pharmaceutical Tablets</span></div>
         
        <div class="revw-comnt  ln6 mr11 ">Good service</div>
                <div class="revw-like rdf m13  ">
                        <div class="stfn-name rdf raic">Response <span class="stfn-thmup rdf raic rml10"><svg height="20" viewBox="0 0 24 24" width="20" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span></div>
                                            <div class="stfn-name rdf raic">Quality <span class="stfn-thmup rdf raic rml10"><svg height="20" viewBox="0 0 24 24" width="20" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span></div>
                                           <div class="stfn-name rdf raic">Delivery <span class="stfn-thmup rdf raic rml10"><svg height="20" viewBox="0 0 24 24" width="20" fill="#72ad44" class="FM_m20"><rect height="10" width="3" x="2" y="10"></rect><path d="M19,9H14V4a1,1,0,0,0-1-1H12L7.66473,8.37579A3.00021,3.00021,0,0,0,7,10.259V18a2,2,0,0,0,2,2h6.43481a2.99991,2.99991,0,0,0,2.69037-1.67273L21,12.5V11A2,2,0,0,0,19,9Z"></path></svg></span></div>
                           </div>
        </div>
        </div>
    </div>
<!--Rating Comment section End -->
 </div>
<!--Rating Short By and Comment section End -->
    <div class="fl raq_btn"><a href="testimonial.html#reviewsratings"><div name="checkname" class="btn1">View More Reviews</div></a></div>
          </div>
