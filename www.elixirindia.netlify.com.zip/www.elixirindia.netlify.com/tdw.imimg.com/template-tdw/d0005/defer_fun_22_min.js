var formloaded = 0;

function impfun() {
    $.ajaxSetup({
        cache: !0
    });
    var origin_url = window.location.origin,
        match_res = origin_url.match(/dev-/);
    if (null != match_res) var post_url = $(this).data("url");
    else var post_url = origin_url;
    $.ajax({
        type: "POST",
        url: post_url,
        data: {
            menudata: "yes"
        }
    }).done((function(msg) {
        window.ss = eval(msg)
    })), $.getScript("https://utils.imimg.com/imcookies/js/im-imvc-rw-cf.js").done((function() {
        $.getScript(central_path + "cent_dynamic/dyn_isq/multi_img_enq_dyn_isq_16_min.js").done((function() {
            loadFormcss(), "category" != pagenameqw && "search" != pagenameqw && "catindex" != pagenameqw || setTimeout((function() {
                show_form_onpage()
            }), 100), $.getScript(cent_path + "optform/function_8_min.js").done((function() {
                "" != pns_no && "franchisee" != pagenameqw && tollfree(), "search" == pagenameqw ? settext() : settextvalue(), LoadImageinViewPort()
            })), $.getScript(central_path + "cntryintlTelInput_new4.js").done((function() {
                $.getScript(central_path + "cent_dynamic/dyn_isq/Sms_valiadation_dyn_isq_min.js"), $(".mobile-number").intlTelInputs({}), "job" == pagenameqw && $(".mobile-number_job").intlTelInputs({}), "franchisee" != pagenameqw && "job" != pagenameqw && "search" != pagenameqw && "notfoundpage" != pagenameqw && "enquiry" != pagenameqw && setTimeout((function() {
                    $("#mobile-number_footerprd_dataform").intlTelInputs({}), $.getScript(cent_path + "prd_footer_form-old5min.js")
                }), 200), "franchisee" == pagenameqw && ($("#mobile-number_fran").intlTelInputs({}), $.getScript(cent_path + "franchisee_min.js")), 0 == formloaded && ("" == srchNoResultPage && loadMultiImgForm(), formloaded = 1, $.getScript(cent_path + "dropdown_min.js").done((function() {
                    f31(), $("#m1tlm0").attr("onmouseover", "exM(m1,'m1mn3','m1tlm0',event)"), $("#m1tlm0").attr("onmouseout", "coM(m1,'m1mn3')"), $("#m1tlm1").attr("onmouseover", "exM(m1,'m1mn1','m1tlm1',event)"), $("#m1tlm1").attr("onmouseout", "coM(m1,'m1mn1')")
                })))
            }))
        }))
    })), $(document).ready((function() {
        $(".accordion-body").hide(), $("#vid_sec_play").click((function(e) {
            "aboutus" == pagenameqw ? clsVid1() : clsVid()
        })), "category" == pagenameqw ? ($("#show").css("display", "block"), $("#show").prev().addClass(acc_head_class).removeClass("acc-head").removeClass("cpo")) : "notfoundpage" != pagenameqw && $(".accordion-heading:first").addClass(acc_head_class).removeClass("cpo").next().show(), $(".accordion-heading").click((function() {
            return $(this).next().is(":hidden") && ($(".accordion-heading").removeClass(acc_head_class).addClass("acc-head cpo").next().slideUp(), $(this).toggleClass(acc_head_class).next().slideDown(), $(this).removeClass("acc-head"), $(this).removeClass("cpo")), !1
        }))
    })), suggcls = "search" == pagenameqw ? "sug-ss2" : "sug-ss", setTimeout((function() {
        $.getScript("https://utils.imimg.com/suggest/js/jq-ac-ui.js").done((function() {
            var e = window.ss;
            new Suggester({
                element: "ss",
                placeholder: "Search Products/Services",
                minStringLengthToDisplaySuggestion: 1,
                source: e,
                autocompleteClass: suggcls,
                finder: finder,
                onSelect: searchCheck,
                rowsToDisplay: 15,
                recentData: !1
            });
            if ("notfoundpage" == pagenameqw) new Suggester({
                element: "S_country",
                onSelect: onselect_countryfcp,
                onExplicitChange: onExplicitChangeCountryEnq,
                placeholder: "",
                minStringLengthToFetchSuggestion: 1,
                updateCache: !1,
                type: "country",
                fields: "isd,iso",
                minStringLengthToDisplaySuggestion: 1
            });
            "enquiry" == pagenameqw && $.getScript(cent_path + "suggest_new_8_min.js").done((function() {
                get_ip()
            })), "category" != pagenameqw && "search" != pagenameqw && "catindex" != pagenameqw && "aboutus" != pagenameqw || $.getScript("https://utils.imimg.com/imjsv/js/imjsv.js").done((function() {
                $.getScript(cent_path + "Quick_4min.js").done((function() {
                    $("#mobile-number_side_zoom_dataform").intlTelInputs({});
                    var e = $("#sidepop").offset().top + 0;
                    $(window).scroll((function() {
                        var t = $("#contact-stop").offset().top,
                            a = $("#sidepop").height();
                        e + a + 100 < t && ($(window).scrollTop() > e && $(window).scrollTop() > t - a - 100 ? $("#sidepop").hasClass("abs") || $("#sidepop").addClass("abs").removeClass("stick").css("top", t - (a + 43) + "px") : $(window).scrollTop() > e && $(window).scrollTop() < t - a ? ($("#sidepop").addClass("stick"), $("#sidepop").removeClass("abs"), $("#sidepop").css("top", 0)) : $(window).scrollTop() < e && $("#sidepop").removeClass("stick"))
                    }))
                }))
            }))
        }))
    }), 500);
    var backcls = '.qhl_p,.qhr_p,.qrr_p,.qlb_p,.qrb_p,.cale_p,.pls_p,.mns_p,.radd_p a,.mns1_p,.pls1_p,.pls2_p,.mns2_p,.dlt_p,.dlt1_p,.mpd1_p,.ilog,.med1,.med2,.med3,.blow,.ts,.ts1,.ts_t,.ts1_t,.main,.kor,.eml,.sms,.blwp,.clsp_s,.fsms6_s,.byr_s,.hh,#rateMe .on,#rateMe a, .blow1_p, .clos_11_p, #zoom_slider_hide, .rightZoomScroll, .leftZoomScroll, .zoom_left_icon, .zoom_right_icon, .addc, .prd_exst,.m_icon,.m_icon1,.m_icon2,.plus_p,.minus_p,.arw1_p,.cart_p,.blow2_p,.blow3_p,.arw11_p,.arw11_footer_p,.acc-head1,.acc-head2,.ive { background-image:url("' + central_path + 'blowupd5_10.png")!important }';
    backcls += '.sprt, .bg3, .k-6 a:hover, .rd-mr, .rd-mr:hover, .prd_ct ul li a, .mainnew, .carousel .nextButton, .carousel .prevButton, .pdf_1, .crt,.acc-head { background-image:url("' + central_path + "d0005/" + PC_CLNT_STYLE_ID + '/t4s.png") }', backcls += '.intl-tel-input .flag_ctry{ background-image:url("' + central_path + 'cntry_flags.png") }', backcls += '.ImgF_p{ background-image:url("' + central_path + 'send_enq.png") }';
    var styleele1 = document.createElement("style");

    function loadMultiImgForm() {
        "" === document.getElementById("searchnotfound").innerHTML && $.ajax({
            type: "POST",
            url: "/cgi/dyn_isq/multi_img_dyn_isq_1.php",
            data: {
                glid: gluser_id,
                stlyid: PC_CLNT_STYLE_ID,
                tmpl_path: PC_CLNT_TMPL_PATH,
                cat_name: CAT_NAME,
                central_path: central_path,
                pagetypeName: pagenameqw,
                compName: CompanyName
            },
            success: function(e) {
                $("#searchnotfound").html(e)
            }
        }).done((function() {
            $.getScript(central_path + "cent_dynamic/suggest_new_product_dyn_1_min.js"), $.getScript(central_path + "cent_dynamic/dyn_isq/dyn_isq_form9_min.js"), $("#mobile-number_zoom_dataform").intlTelInputs({}), $("#mobile-number1_zoom_dataform").intlTelInputs({})
        }))
    }
    styleele1.type = "text/css", document.getElementsByTagName("head")[0].appendChild(styleele1), styleele1.styleSheet ? styleele1.styleSheet.cssText = backcls : styleele1.innerHTML = backcls, "homepage" == pagenameqw && ($.getScript(central_path + "d0005/jquery.carousel.js", (function() {
        $(".carousel").carousel({
            carouselWidth: 1e3,
            carouselHeight: 330,
            directionNav: !0,
            shadow: !0,
            buttonNav: "bullets",
            hAlign: "center"
        })
    })), null != typeof news_count && news_count > 0 && $.getScript(cent_path + "news1.js").done((function() {
        setTimeout((function() {
            newsscrol = new pausescroller(pausecontent, "pscroller1", "someclass", 3e3), newsscrol.initialize()
        }), 400)
    })), null != typeof printhotdata && printhotdata > 0 && $.getScript(cent_path + "slidenews.js"), null != typeof prd_hot_img_flg && "enabled" == prd_hot_img_flg && $(document).ready((function() {
        $(".paging").show(), $(".paging a:first").addClass("active");
        var e = $(".window").width(),
            t = $(".image_reel img").size(),
            a = e * t;
        $(".image_reel").css({
            width: a
        }), rotate = function() {
            var t = ($active.attr("dataimg") - 1) * e;
            $(".paging a").removeClass("active"), $active.addClass("active"), $(".image_reel").animate({
                left: -t
            }, 500)
        }, rotateSwitch = function() {
            play = setInterval((function() {
                $active = $(".paging a.active").next(), 0 === $active.length && ($active = $(".paging a:first")), rotate()
            }), 3e3)
        }, rotateSwitch(), $(".image_reel a").hover((function() {
            clearInterval(play)
        }), (function() {
            rotateSwitch()
        })), $(".paging a").click((function() {
            return $active = $(this), clearInterval(play), rotate(), rotateSwitch(), !1
        }))
    }))), "category" != pagenameqw && "corporate-video" != pagenameqw && "search" != pagenameqw && "homepage" != pagenameqw && "aboutus" != pagenameqw || setTimeout((function() {
        null != typeof vdo_flag && 1 == vdo_flag && $.getScript(cent_path + "product_video_js1.js")
    }), 100), "homepage" != pagenameqw && "category" != pagenameqw || (window.wasScrolled = !1, $(window).bind("scroll", (function() {
        window.wasScrolled || ($.getScript(cent_path + "scroll-img-index_2.js").done((function() {
            fillup()
        })), window.wasScrolled = !0)
    }))), "enquiry" != pagenameqw && "franchisee" != pagenameqw && "homepage" != pagenameqw && "category" != pagenameqw && (window.wasScrolled = !1, $(window).bind("scroll", (function() {
        window.wasScrolled || ($.getScript(cent_path + "scroll-img_1.js").done((function() {
            fillup()
        })), window.wasScrolled = !0)
    })))
}

function getComputedTranslateY(e) {
    if (window.getComputedStyle) {
        var t = getComputedStyle(e),
            a = t.transform || t.webkitTransform || t.mozTransform || t.msTransform,
            n = a.match(/^translate\((.+)\)$/);
        return n ? parseFloat(n[1].split(", ")[13]) : (n = a.match(/^matrix\((.+)\)$/)) ? parseFloat(n[1].split(", ")[5]) : 0
    }
}

function slide(e, t) {
    var a = document.getElementById(e),
        n = a.getElementsByTagName("li").length,
        o = 83;
    "thumbnail-containerpop" == e && (o = 72), n > 4 && (window.lilength = parseInt(n - 4) * o);
    var s = getComputedTranslateY(a);
    "down" == t ? -window.lilength < parseInt(s) && (s = parseInt(s - o)) : 0 != parseInt(s) && (s = parseInt(s + o)), document.getElementById(e).style.transform = "translate(0px, " + s + "px)"
}

function on_video_mouseover(e) {
    $("#pvdo" + e).show(), $("#zoom" + e).hide()
}
"category" != pagenameqw && (CAT_NAME = ""), "category" != pagenameqw && "search" != pagenameqw || $(".smlimg").on("hover", (function() {
    $(".smlimg").removeClass("actvPrd"), $(this).addClass("actvPrd")
}));
var flag = 0;
if (null != typeof testimonial && null != testimonial && null != typeof rtng_dsplay_flag && null != rtng_dsplay_flag && null != typeof suplyr_rtng_flag && null != suplyr_rtng_flag && null != typeof sort_type && null != sort_type && (flag = 1), null != typeof rtng_dsplay_flag && 1 == rtng_dsplay_flag && (suplyr_rtng_flag, 1) && suplyr_rtng_flag > 0 && "testimonial" != pagenameqw && "enquiry" != pagenameqw && "thankyou" != pagenameqw && "notfound" != pagenameqw && 1 == flag && $.ajax({
        type: "POST",
        url: "/cgi/desktop_rating_footer.php",
        data: {
            glusrId: gluser_id,
            pagename1: pagenameqw,
            testmonialLink: testimonial,
            tmpl_path: PC_CLNT_TMPL_PATH,
            stylid: PC_CLNT_STYLE_ID,
            sort_type: sort_type
        },
        success: function(e) {
            $("#rating_ajx").html(e)
        }
    }), "testimonial" == pagenameqw) {
    function getRatingAjax(e, t, a) {
        $.ajax({
            type: "POST",
            url: "/cgi/review_rating_new.php",
            data: {
                input_supplier_id: gluser_id,
                sort_type: sort_type,
                tmpl_path: PC_CLNT_TMPL_PATH,
                tmpl_style_Id: PC_CLNT_STYLE_ID,
                limit: e,
                strt: t
            },
            success: function(e) {
                1 == a ? $("#commentHTML").html(e) : $("#commentHTML").append(e), $(".loader").hide()
            }
        }).done((function() {
            $(".loader").hide(), $(".loader1").hide(), total_cnt - (t - 1) > 20 ? ($(".view_more").addClass("disf"), $(".view_more").removeClass("disn")) : ($(".view_more").removeClass("disf"), $(".view_more").addClass("disn"))
        }))
    }

    function getRatings() {
        let e = parseInt($(".revw-user").last().attr("id")) + 20,
            t = parseInt($(".revw-user").last().attr("id")) + 1;
        $(".loader1").show(), getRatingAjax(e, t, 0)
    }
    $(".FM_sortng").change((function() {
        sort_type = $("#sortValue").val();
        $(".loader").show(), getRatingAjax(20, 1, 1)
    }))
}
if ("category" == pagenameqw || "sitemap" == pagenameqw) {
    function showmore(category, id, server) {
        if ("string" == typeof id || id instanceof String) {
            var myArray = id.split("_"),
                num = myArray[1],
                new_num = parseInt(num) + 1,
                str_idx = 40 + 40 * (num - 1),
                end_idx = str_idx + 39;
            $.ajax({
                type: "POST",
                url: "/cgi/d05_showmore.php",
                data: {
                    start: str_idx,
                    end: end_idx,
                    cat_idx: category,
                    server: server,
                    id: num,
                    action: "showmore",
                    domain_alias: domain_alias,
                    pageHtmlType: pagehtmlTyp
                },
                success: function(result) {
                    gtEle("paginate").innerHTML += result;
                    var getEnqData = eval(document.getElementById("enqDataref").innerHTML);
                    if (dataref1 = dataref1.concat(getEnqData), $("#enqDataref").remove(), end_idx >= t_prod_count) gtEle(id).style.display = "none";
                    else {
                        var new_id = "showmore_" + new_num;
                        gtEle(id).setAttribute("id", new_id)
                    }
                }
            }).done((function() {}))
        } else {
            var l_id = category.toString();
            category = "list_".concat(l_id), $.ajax({
                type: "POST",
                url: "/cgi/d05_showmore.php",
                data: {
                    cat_idx: id,
                    server: server,
                    action: "site_view",
                    domain_alias: domain_alias
                },
                success: function(e) {
                    gtEle(category).innerHTML += e, gtEle(id).style.display = "none"
                }
            }).done((function() {}))
        }
    }

    function gtEle(e, t) {
        return "class" == t ? document.getElementsByClassName(e) : document.getElementById(e)
    }
}