var scmob, ZoomElementNamesHash_footerprd = new im_elementHash("S_name", "S_name", "S_lname", "S_lname", "S_email", "S_email", "S_cmobile", "S_cmobile", "S_phone_country_code", "S_phone_country_code", "S_organization", "S_organization", "S_country", "S_country", "country", "country", "S_mobile", "S_mobile", "S_fullname", "fullname", "S_glusr_id", "S_glusr_id"),
    ajaxprocessing_footerprd = !1,
    email_check_footerprd = !1,
    scountry = "India",
    sphonecode = "+91",
    countryiso = "IN",
    contry = "IN";
"" != im_readCookie("ImeshVisitor") ? fill_cookies_footerprd() : ($("#S_mobile_footerprd").val("Enter your number:"), document.footerprd_dataform.S_mobile.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd c11_p", document.footerprd_dataform.fullname.value = "Enter your name:", document.footerprd_dataform.fullname.className = "m41_p icon_ff icon3_ff icon0_ff icon_datauri validate_footerprd req_footerprd chars_footerprd c11_p", $("#S_email_footerprd").val("Enter your email:"), document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid c11_p"), $(document).ready(function() {
    $(".validate_footerprd.req_footerprd").keypress(function(e) {
        if (13 == e.keyCode) return $(this).trigger("blur"), $("#SubmitEnq_footerprd").trigger("click"), !0
    }), $(".submit_form_footerprd").click(function() {
        $("form[name=footerprd_dataform]").trigger("submit")
    }), $("#S_email_footerprd").change(function() {
        /^[A-z0-9][_.A-z0-9-]+@[a-zA-Z0-9]+[\.\-\_]{0,1}[a-zA-Z0-9]+\.[a-zA-Z]{2,6}\.?[a-zA-Z]{0,4}$/.test(document.footerprd_dataform.S_email.value) || (email_check_footerprd = !1)
    }), document.footerprd_dataform.Description.className = "icon_ff icon1_ff clr7_p h1_p fnt_p icon16_p icon_datauri validate_footerprd Desc_err_footerprd c11_p", $("#fullname_footerprd").change(function() {
        var e = $(this).val().split(" ");
        $("#firstname_footerprd").val(e[0]), e.shift(), e.join(" ") ? $("#lastname_footerprd").val(e.join(" ")) : $("#lastname_footerprd").val(" ")
    })
}), $(".footerprd_dataform").change(function() {
    popupopen = "footerprd_dataform"
}), $(document).ready(function() {
    $.ajaxSetup({
        cache: !0
    }), "function" == typeof getCookieValues1 && getCookieValues1(), "function" == typeof product_style_footerprd ? product_style_footerprd() : setTimeout(function() {
        product_style_footerprd()
    }, 1e3)
});
var trySubmit_footerprd = 0;

function footerprd_checkdatafetch(e) {
    return email_check_footerprd ? trySubmit_footerprd < 4 && (setTimeout(function() {
        $(e).submit()
    }, 200), trySubmit_footerprd++, !1) : (trySubmit_footerprd = 0, validate_bind_footerprd())
}
var submitQuery_footerprd = 0;

function check_description_focus_footerprd(e) {
    "Describe your requirement in detail:" == e.value && (e.value = ""), e.className = "icon_ff icon1_ff clr7_p h1_p fnt_p icon16_p icon_datauri validate_footerprd Desc_err_footerprd", document.getElementById("d1_f").style.display = "none"
}

function check_Email_focus_footerprd(e) {
    "Enter your email:" == e.value && (e.value = ""), e.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid", document.getElementById("e1_f").style.display = "none"
}

function check_Fullname_focus_footerprd(e) {
    "Enter your name:" == e.value && (e.value = ""), e.className = "m41_p icon_ff icon3_ff icon0_ff icon_datauri validate_footerprd req_footerprd chars_footerprd", document.getElementById("f1_f").style.display = "none"
}

function check_Mobile_focus_footerprd(e) {
    "Enter your number:" == e.value && (e.value = ""), e.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd", document.getElementById("m1_f").style.display = "none"
}

function check_Description_footerprd() {
    return document.footerprd_dataform.Description.value = document.footerprd_dataform.Description.value.replace(/^\s+|\s+$/g, ""), "" == document.footerprd_dataform.Description.value || "Describe your requirement in detail:" == document.footerprd_dataform.Description.value ? (document.footerprd_dataform.Description.value = "Describe your requirement in detail:", document.getElementById("d1_f").style.display = "block", document.getElementById("d1_f").innerHTML = "Kindly Describe Your Requirement.", document.footerprd_dataform.Description.className = "icon_ff icon1_ff clr7_p h1_p fnt_p icon16_p icon_datauri validate_footerprd Desc_err_footerprd c11_p", !1) : (document.footerprd_dataform.Description.className = "icon_ff icon1_ff clr7_p h1_p fnt_p icon16_p icon_datauri validate_footerprd Desc_err_footerprd", document.getElementById("d1_f").style.display = "none", !0)
}

function check_Email_footerprd() {
    if ("none" == document.getElementById("emailfield_footerprd_dataform").style.display) return !0;
    document.footerprd_dataform.S_email.value = document.footerprd_dataform.S_email.value.replace(/^\s+|\s+$/g, "");
    var e = document.footerprd_dataform.S_email.value;
    return null == e || "" == e ? (document.getElementById("e1_f").style.display = "block", document.getElementById("e1_f").innerHTML = "Please enter your email.", document.getElementById("S_email_footerprd").value = "Enter your email:", document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid c11_p", !1) : /^[A-z0-9][_.A-z0-9-]+@[a-zA-Z0-9]+[\.\-\_]{0,1}[a-zA-Z0-9]+\.[a-zA-Z]{2,6}\.?[a-zA-Z]{0,4}$/.test(document.footerprd_dataform.S_email.value) ? (document.getElementById("e1_f").style.display = "none", !0) : (document.getElementById("e1_f").style.display = "block", "Enter your email:" == document.footerprd_dataform.S_email.value ? (document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid c11_p", document.getElementById("e1_f").innerHTML) : (document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid", document.getElementById("e1_f").innerHTML = "Please enter valid email."), !1)
}

function check_Fullname_footerprd() {
    if (foreign = 0, "block" != document.getElementById("mobilefield_footerprd_dataform").style.display ? foreign = 1 : foreign = 0, document.footerprd_dataform.fullname.value = document.footerprd_dataform.fullname.value.replace(/^\s+|\s+$/g, ""), 1 == foreign && ("" == document.footerprd_dataform.fullname.value || "Enter your name:" == document.footerprd_dataform.fullname.value)) return document.getElementById("f1_f").style.display = "block", document.getElementById("f1_f").innerHTML = "Please enter your name.", document.footerprd_dataform.fullname.className = "m41_p icon_ff icon3_ff icon0_ff icon_datauri validate_footerprd req_footerprd chars_footerprd c11_p", !1;
    if ("" == document.footerprd_dataform.fullname.value || "Enter your name:" == document.footerprd_dataform.fullname.value) document.getElementById("fullname_footerprd").value = "Enter your name:", document.getElementById("f1_f").style.display = "none", document.footerprd_dataform.fullname.className = "m41_p icon_ff icon3_ff icon0_ff icon_datauri validate_footerprd req_footerprd chars_footerprd c11_p";
    else {
        if (!/^[A-z][A-z. ]{0,42}$/.test(document.footerprd_dataform.fullname.value)) return document.getElementById("f1_f").style.display = "block", document.getElementById("f1_f").innerHTML = "Please enter valid name.", document.footerprd_dataform.fullname.className = "m41_p icon_ff icon3_ff icon0_ff icon_datauri validate_footerprd req_footerprd chars_footerprd", !1;
        document.getElementById("f1_f").style.display = "none"
    }
    return !0
}

function check_Mobile_footerprd() {
    if ("none" == document.getElementById("mobilefield_footerprd_dataform").style.display) return !0;
    "Enter your number:" != document.footerprd_dataform.S_mobile.value && (document.footerprd_dataform.S_mobile.value = document.footerprd_dataform.S_mobile.value.replace(/\s+/g, "")), document.footerprd_dataform.S_mobile.value = document.footerprd_dataform.S_mobile.value.replace(/^0+/, "");
    var e = "IN" == document.getElementById("txtCountry_footerprd").value ? /^((?![2-5])[0-9]{10})$/.test(document.footerprd_dataform.S_mobile.value) : /^[0-9]{1,30}$/.test(document.footerprd_dataform.S_mobile.value);
    return "Enter your number:" == document.footerprd_dataform.S_mobile.value ? (document.getElementById("m1_f").style.display = "block", document.getElementById("m1_f").innerHTML = "Please enter valid mobile number.", document.footerprd_dataform.S_mobile.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd c11_p", document.footerprd_dataform.S_cmobile.className = "cnty_isd bg10_p bdr2_p cn1_p mobile-number ft5_p", !1) : "" == document.footerprd_dataform.S_mobile.value ? (document.getElementById("S_mobile_footerprd").value = "Enter your number:", document.getElementById("m1_f").style.display = "block", document.getElementById("m1_f").innerHTML = "Please enter your mobile number.", document.footerprd_dataform.S_mobile.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd c11_p", !1) : e ? (document.getElementById("m1_f").style.display = "none", document.footerprd_dataform.S_mobile.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd", !0) : (document.getElementById("m1_f").style.display = "block", document.getElementById("m1_f").innerHTML = "Please enter valid mobile number.", document.footerprd_dataform.S_mobile.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd", !1)
}

function check_Description_footerprd2() {
    "" != document.footerprd_dataform.Description.value && "Describe your requirement in detail:" != document.footerprd_dataform.Description.value || (document.footerprd_dataform.Description.value = "Describe your requirement in detail:", document.footerprd_dataform.Description.className = "icon_ff icon1_ff clr7_p h1_p fnt_p icon16_p icon_datauri validate_footerprd Desc_err_footerprd c11_p")
}

function check_Email_footerprd2() {
    if ("none" == document.getElementById("emailfield_footerprd_dataform").style.display) return !0;
    var e = document.footerprd_dataform.S_email.value;
    return null == e || "" == e ? (document.getElementById("S_email_footerprd").value = "Enter your email:", document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid c11_p", !1) : void 0
}

function check_Fullname_footerprd2() {
    "" != document.footerprd_dataform.fullname.value && "Enter your name:" != document.footerprd_dataform.fullname.value || (document.getElementById("fullname_footerprd").value = "Enter your name:", document.footerprd_dataform.fullname.className = "m41_p icon_ff icon3_ff icon0_ff icon_datauri validate_footerprd req_footerprd chars_footerprd c11_p")
}

function check_Mobile_footerprd2() {
    if ("none" == document.getElementById("mobilefield_footerprd_dataform").style.display) return !0;
    "" != document.footerprd_dataform.S_mobile.value && "Enter your number:" != document.footerprd_dataform.S_mobile.value || (document.getElementById("S_mobile_footerprd").value = "Enter your number:", document.footerprd_dataform.S_mobile.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd c11_p")
}

function validate_bind_footerprd() {
    if (null != typeof jQuery) {
        var e = check_Description_footerprd(),
            o = check_Fullname_footerprd();
        "Describe your requirement in detail:" == document.footerprd_dataform.Description.value && (document.footerprd_dataform.Description.value = ""), "Enter your number:" == document.footerprd_dataform.S_mobile.value && (document.footerprd_dataform.S_mobile.value = ""), "Enter your email:" == document.footerprd_dataform.S_email.value && (document.footerprd_dataform.S_email.value = "");
        var r = check_Email_footerprd(),
            t = check_Mobile_footerprd();
        return document.footerprd_dataform.S_phone_country_code.value = document.getElementById("mobile-number_footerprd_dataform").value, e && r && o && t ? ("Enter your name:" == document.footerprd_dataform.fullname.value && (document.footerprd_dataform.fullname.value = ""), document.footerprd_dataform.S_mobile.value == getparamVal1(cookie1, "mb1") && "+91" != document.getElementById("mobile-number_footerprd_dataform").value && (document.footerprd_dataform.S_mobile.value = ""), document.footerprd_dataform.S_email.value == getparamVal1(cookie1, "em") && "+91" == document.getElementById("mobile-number_footerprd_dataform").value && (document.footerprd_dataform.S_email.value = ""), 0 == submitQuery_footerprd && (submitQuery_footerprd = 1, check_loginmode_fooetrprd(), $(".enqload_form").html("<img src='https://tdw.imimg.com/template-tdw/loading.gif' alt='Please wait'>"), $.post($(".footerprd_dataform").attr("action"), $(".footerprd_dataform").serialize(), function(e) {
            return "OK" == e.response && null != e.gluser_id && (document.footerprd_dataform.S_glusr_id.value = e.gluser_id), $(".enqload_form").html(""), "204" == e.error ? (e1_f = document.getElementById("e1_f"), e1_f.innerHTML = "Kindly choose correct country.", e1_f.style.display = "block", $(".enqload_getcall").html("")) : "OK" == e.response ? (setCartCookie1("querysent", "enter", 4), $(".error_notification_footerprd").html("").hide(), $("#footerprd_alert_display").show(), $("#footerprd_alert_display_alert").hide(), $("#page_head").hide(), clearValue_footerprd(), "function" == typeof sync_all_form && sync_all_form(), setCartCookie1("querysent", "enter", 4), _gaq.push(["b._trackEvent", "Body", "footerform/thankyou", "'" + PC_CLNT_TMPL_PATH + "'"])) : (msg = "* Some error has occured while submitting enquiry.Please try again!!!", $(".error_notification_footerprd").html(msg).show()), submitQuery_footerprd = 0, !1
        }, "json")), !1) : (0 == e ? $("#Description_footerprd").trigger("focus") : 0 == r ? $("#S_email_footerprd").trigger("focus") : 0 == o ? $("#fullname_footerprd").trigger("focus") : $("#S_mobile_footerprd").trigger("focus"), !1)
    }
    return !1
}

function fill_cookies_footerprd() {
    if ("function" == typeof im_getCookieValues && im_getCookieValues("footerprd_dataform", ZoomElementNamesHash_footerprd), popupopen = "footerprd_dataform", check_country_flag(), (cookie1 = getCartCookie("ImeshVisitor")) > "") {
        "" == getparamVal1(cookie1, "fn") && "" == getparamVal1(cookie1, "ln").trim() ? (document.footerprd_dataform.fullname.value = "Enter your name:", document.footerprd_dataform.fullname.className = "m41_p icon_ff icon3_ff icon0_ff icon_datauri validate_footerprd req_footerprd chars_footerprd c11_p") : setTimeout(function() {
            document.footerprd_dataform.fullname.value = getparamVal1(cookie1, "fn") + " " + getparamVal1(cookie1, "ln"), document.footerprd_dataform.fullname.className = "m41_p icon_ff icon3_ff icon0_ff icon_datauri validate_footerprd req_footerprd chars_footerprd"
        }, 1e3), "" == getparamVal1(cookie1, "em") ? ($("#S_email_footerprd").val("Enter your email:"), document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid c11_p") : setTimeout(function() {
            document.footerprd_dataform.S_email.value = getparamVal1(cookie1, "em"), document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid"
        }, 1e3), "" == getparamVal1(cookie1, "mb1") ? ($("#S_mobile_footerprd").val("Enter your number:"), document.footerprd_dataform.S_mobile.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd c11_p") : setTimeout(function() {
            document.footerprd_dataform.S_mobile.value = getparamVal1(cookie1, "mb1"), document.footerprd_dataform.S_mobile.className = "bdr2_p bg10_p ft5_p cn2_p validate_footerprd req_footerprd mobile_val_footerprd"
        }, 1e3);
        var e = document.footerprd_dataform.S_phone_country_code.value.replace("+", ""),
            o = document.footerprd_dataform.country.value.toLowerCase(),
            r = $(".country-list").find("li[data-country-code = " + o + "_ctry]").find("span").html();
        sync_country_flag("+" + e, o, r)
    }
}

function clearValue_footerprd() {
    document.footerprd_dataform && (document.footerprd_dataform.Description.value = "")
}

function product_style_footerprd() {
    setTimeout(function() {
        fill_cookies_footerprd()
    }, 2e3), "Enter your email:" != document.footerprd_dataform.S_email.value ? document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid" : (document.footerprd_dataform.S_email.value = "Enter your email:", document.footerprd_dataform.S_email.className = "bdr2_p bg10_p ft5_p validate_footerprd req_footerprd email_val_footerprd email_wid c11_p"), document.footerprd_dataform.Description.value = "Describe your requirement in detail:"
}
get_ip(), document.getElementById("Description_footerprd").value = "Describe your requirement in detail:";