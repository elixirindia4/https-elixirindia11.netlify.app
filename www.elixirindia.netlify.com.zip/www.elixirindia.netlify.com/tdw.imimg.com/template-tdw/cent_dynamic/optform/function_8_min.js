function tollfree() {
    "" == im_readCookie("iploc") ? $.when(get_ip()).then(function() {
        setTimeout(function() {
            fillpns()
        }, 1e3)
    }) : fillpns()
}

function fillpns() {
    var e = getCartCookie("iploc");
    if ("IN" == getparamVal1(e, "gcniso")) {
        if (pns_cnt_code = "0" + pns_no, "undefined" != typeof PC_CLNT_TMPL_PATH && "d0055" == PC_CLNT_TMPL_PATH) {
            var t = document.getElementById("show_sms_popup_ef"),
                n = document.createElement("span");
            n.id = "temp1", n.innerHTML = "<span onclick=\"imgset_zoom('sendSMS','Send_sms_email');_gaq.push(['b._trackEvent','Bottom','SendSms/1/" + pagenameqw + "','" + PC_CLNT_TMPL_PATH + '\'])" id="show_sms_popup2" class="cu_p m7 fr_p"><span class="eml1 sp ds1 m45_p vr4 m3"></span>Send SMS</span>', t.insertAdjacentElement("afterend", n);
            var o = document.getElementById("show_sms_popup2");
            t.insertAdjacentElement("afterend", o), document.getElementById("temp1").remove()
        }
    } else pns_cnt_code = "+91-" + pns_no;
    document.getElementById("tollfree") && (document.getElementById("tollfree").innerHTML = pns_cnt_code), document.getElementById("tollfree1") && (document.getElementById("tollfree1").innerHTML = pns_cnt_code), "" != document.getElementById("pns_details") && (document.getElementById("pns_details").innerHTML = "Call " + pns_cnt_code)
}

function searchCheck() {
    var e = document.frm.ss;
    if ("showroom.indiamart.com" == window.location.host) return !1;
    var t = "";
    if ("" == e.value || "Search Products/Services" == e.value || e.value.match(/^\s+$/)) return alert("Please enter some keyword to search."), setTimeout(function() {
        e.focus(), e.value = ""
    }, 1), !1;
    if (e.value.length < 3) return alert("Please Enter atleast 3 character"), setTimeout(function() {
        e.focus(), e.value = ""
    }, 1), !1;
    if (!e.value.match(/\w/)) return alert("Enter at least one alphanumeric characters for search."), setTimeout(function() {
        e.focus(), e.value = ""
    }, 1), !1;
    if (e.value) {
        t += "ss=" + e.value.replace(/^\s+/g, "").replace(/\s+$/g, "").replace(/\+/g, " ").replace(/\s+/g, "+").replace(/%/g, "%25");
        try {
            _gaq.push(["b._trackEvent", "Body", "Searchbutton", "" + PC_CLNT_TMPL_PATH])
        } catch (e) {}
        return window.location = PAID_SHOWROOM_URL + "search.html?" + t, !1
    }
}

function searchClear() {
    "Search Products/Services" == document.frm.ss.value && (document.frm.ss.value = "")
}

function settext() {
    "" == document.frm.ss.value && (document.frm.ss.value = "Search Products/Services")
}

function settextvalue() {
    document.frm.ss.value = "Search Products/Services"
}
if ("undefined" != typeof PC_CLNT_TMPL_PATH && "d0051" == PC_CLNT_TMPL_PATH) {
    function searchCheck1() {
        if ("showroom.indiamart.com" == window.location.host) return !1;
        var e = "";
        if ("" == document.frm1.ss1.value || "Search Products/Services" == document.frm1.ss1.value || document.frm1.ss1.value.match(/^\s+$/)) return alert("Please enter some keyword to search."), document.frm1.ss1.focus(), document.frm1.ss1.value = "", !1;
        if (document.frm1.ss1.value.length < 3) return alert("Please Enter atleast 3 character"), document.frm1.ss1.focus(), !1;
        if (!document.frm1.ss1.value.match(/\w/)) return alert("Enter at least one alphanumeric characters for search."), document.frm1.ss1.focus(), document.frm1.ss1.value = "", !1;
        if (document.frm1.ss1.value) {
            var t;
            t = document.frm1.ss1.value.replace(/^\s+/g, "").replace(/\s+$/g, ""), e += "ss=" + (t = (t = (t = encodeURIComponent(t)).replace(/\+/g, " ")).replace(/\s+/g, "+"));
            try {
                _gaq.push(["b._trackEvent", "Body", "Searchbutton", "" + PC_CLNT_TMPL_PATH])
            } catch (e) {}
            return window.location = PAID_SHOWROOM_URL + "search.html?" + e, !1
        }
    }

    function searchClear1() {
        "Search Products/Services" == document.frm1.ss1.value && (document.frm1.ss1.value = "")
    }

    function settext1() {
        "" == document.frm1.ss1.value && (document.frm1.ss1.value = "Search Products/Services")
    }

    function settextvalue1() {
        document.frm1.ss1.value = "Search Products/Services"
    }
}

function openchildts1(e) {
    var t, n, o, r;
    (browserName = navigator.appName, browserVer = parseInt(navigator.appVersion), condition = !(browserName.indexOf("Explorer") >= 0 && browserVer < 4 || browserName.indexOf("Netscape") >= 0 && browserVer < 2), 1 == condition ? CanAnimate = !0 : CanAnimate = !1, CanAnimate) ? (n = "Microsoft Internet Explorer" == browserName ? "550px" : "553px", t = .8 * screen.height * .85, o = .2 * screen.height * .8, r = .402 * screen.width, msgWindow = window.open("", "subwindow", "toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,menubar=no,resizable=yes,top=" + o + ",left=" + r + ",width=" + n + ",height=" + t), msgWindow.focus(), msgWindow.location.href = e) : msgWindow = window.open(e, "subwindow", "toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,menubar=no,resizable=yes,width=510,height=420")
}

function Windowheight() {
    var e = 0;
    return "number" == typeof window.innerWidth ? (window.innerWidth, e = window.innerHeight) : document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight) ? (document.documentElement.clientWidth, e = document.documentElement.clientHeight) : document.body && (document.body.clientWidth || document.body.clientHeight) && (document.body.clientWidth, e = document.body.clientHeight), e
}

function offsettop(e) {
    core_strundefined = "undefined";
    var t, n, o = {
            top: 0,
            left: 0
        },
        r = e,
        s = r && r.ownerDocument;
    if (s) return t = s.documentElement, typeof r.getBoundingClientRect !== core_strundefined && (o = r.getBoundingClientRect()), n = getWindow(s), {
        top: o.top + (n.pageYOffset || t.scrollTop) - (t.clientTop || 0),
        left: o.left + (n.pageXOffset || t.scrollLeft) - (t.clientLeft || 0)
    }
}

function getWindow(e) {
    return null != e && e == e.window ? e : 9 === e.nodeType && (e.defaultView || e.parentWindow)
}

function LoadImageinViewPort() {
    var e = null != window.pageYOffset ? window.pageYOffset : window.document.documentElement.scrollTop;
    jQuery("img[dataimg]").each(function() {
        parseInt(jQuery(this).offset().top) < parseInt(e) + parseInt(jQuery(window).height()) + 600 && parseInt(jQuery(this).offset().top) + parseInt(jQuery(this).height()) + 600 > parseInt(e) && "" != this.getAttribute("dataimg") && (this.src = this.getAttribute("dataimg"))
    }), jQuery("a[dataimg] img").each(function() {
        parseInt(jQuery(this).offset().top) < parseInt(e) + parseInt(jQuery(window).height()) + 600 && parseInt(jQuery(this).offset().top) + parseInt(jQuery(this).height()) + 600 > parseInt(e) && jQuery(this).attr("src", jQuery(this).parent("a[dataimg]").attr("dataimg"))
    }), window.addEventListener ? window.addEventListener("scroll", bindFunctionOnScroll, !1) : window.attachEvent ? window.attachEvent("onscroll", bindFunctionOnScroll) : window.onscroll = bindFunctionOnScroll
}
var timer, arr, str;

function bindFunctionOnScroll() {
    clearTimeout(timer), timer = setTimeout(LoadImageinViewPort, 150)
}

function finder(e, t) {
    for (var n = new Array, o = 0; o < e.length; o++) {
        new RegExp(t, "i").test(e[o]) && n.push({
            value: e[o],
            label: e[o]
        })
    }
    return n
}

function changeImages() {
    if (document.images) {
        document[changeImages.arguments[0]].src = changeImages.arguments[1], document[changeImages.arguments[0]].setAttribute("data-bimg", changeImages.arguments[2]), document[changeImages.arguments[0]].setAttribute("dataimg", changeImages.arguments[2]), "undefined" != typeof PC_CLNT_TMPL_PATH && "d0055" == PC_CLNT_TMPL_PATH && document[changeImages.arguments[0]].setAttribute("dataimg", changeImages.arguments[1])
    }
}

function siteurl() {
    var e, t = document.location.href;
    return e = (e = t.indexOf("://") > -1 ? t.split("/")[2] : t.split("/")[0]).replace(/^(www\.|m\.)/, "."), document.cookie = "mobile_site_cookie=2;path=/;domain=" + e, !0
}