function getCartCookie(e) {
    var t = e + "=";
    return document.cookie.length > 0 && (offset = document.cookie.indexOf(t), -1 != offset) ? (offset += t.length, end = document.cookie.indexOf(";", offset), -1 == end && (end = document.cookie.length), unescape(document.cookie.substring(offset, end))) : ""
}

function getparamVal1(e, t) {
    if (e > "") {
        var o = "|" + e + "|",
            a = new RegExp(".*?\\|" + t + "=([^|]*).*|.*");
        return o.replace(a, "$1")
    }
    return ""
}
var pagename = "",
    countes = "",
    display_desc_name = "",
    getIsq = 0,
    showotpflag = 1,
    trackType = "",
    foreignFlg = 0,
    usrCompName = "Not Present",
    usrWeb = "Not Present";

function page_name(e, t, o) {
    pagename = e, countes = t, display_desc_name = t, void 0 !== o && (window.selectedMultiImage = o)
}
var pagecount = "",
    name_of_page = "";

function page_counter(e, t, o) {
    pagecount = t, name_of_page = e, void 0 !== o && (window.selectedMultiImage = o)
}

function display_multi_img() {
    document.getElementById("arrow").style.display = "none", document.getElementById("multi_img_box").style.display = "block"
}
var zoomup_desc_placeholder = "",
    zoomup_desc_value = "";

function setCartCookie1(e, t, o) {
    expires = new Date, "ImeshVisitor" == e ? expires.setTime(expires.getTime() + 63072e6) : expires.setTime(expires.getTime() + 864e5), t.length > 0 && (document.cookie = e + "=" + escape(t) + ";expires=" + expires.toGMTString() + ";path=/")
}
var pv_cookie = parseInt(getCartCookie("page_view")) || 0;
pv_cookie += 1, setCartCookie1("page_view", "" + pv_cookie);
var inactivityTime = function() {
    var e;
    window.addEventListener("load", o, !0);

    function t() {
        (cookieVal = getCartCookie("page_view")) >= 2 && "isOpen" != sessionStorage.getItem("autozoomform") && "block" != document.getElementById("ffc_blow_up").style.display && ("homepage" == pagenameqw || "category" == pagenameqw || "search" == pagenameqw || "catindex" == pagenameqw || (cookie = getCartCookie("CART_SESSION")) > "" && "[[],{}]" != cookie) && (sessionStorage.setItem("autozoomform", "isOpen"), document.zoom_dataform.S_reference_text.value = "#autozoom/" + pagenameqw, trackType = "#2pv-zoomup", _gaq.push(["b._trackEvent", "Body", "AutoZoom/" + pagenameqw, "" + PC_CLNT_TMPL_PATH, 0, !0]), show_form())
    }

    function o() {
        clearTimeout(e), e = setTimeout(t, 1e4)
    }["mousedown", "mousemove", "keypress", "scroll", "click", "touchstart"].forEach(function(e) {
        document.addEventListener(e, o, !0)
    })
};

function show_form_onpage() {
    var Interval_id;
    Interval_id = setInterval(function() {
        if ((cookie = getCartCookie("CART_SESSION")) > "") {
            myCart = eval("(" + cookie + ")");
            var itemsArr = myCart[0][0];
            void 0 !== itemsArr && 0 != itemsArr.time && (timer = new Date(itemsArr.time), times = new Date, 60 * times.getHours() + times.getMinutes() - (60 * timer.getHours() + timer.getMinutes()) > 1.5 && (0 == display_form && (document.zoom_dataform.S_reference_text.value = "#auto-zoomup/" + pagenameqw, trackType = "#auto-zoomup", _gaq.push(["b._trackEvent", "Body", "AutoZoom/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), show_form()), cookie = cookie.replace(itemsArr.time, 0), setCartCookie1("CART_SESSION", cookie), clearInterval(Interval_id)))
        }
    }, 1e3)
}

function show_form() {
    if (popupopen = "zoom_dataform", show_form_flag = 1, form_type = "", smsEmailForm = "", $("#ipt_fld_head").html("Mobile Number"), $("#tnk_msg_other").show(), $("#tnk_msg_rcb").hide(), $("#productform").removeClass("tdw_w100"), document.getElementById("int_fd_err") && $("#int_fd_err").removeClass("tdw_err"), document.getElementById("int_fd_err1") && $("#int_fd_err1").removeClass("tdw_err"), (null != document.getElementById("form_blow") && "block" == document.getElementById("form_blow").style.display || null != document.getElementById("ffc_blow_up") && "block" == document.getElementById("ffc_blow_up").style.display || null != document.getElementById("ffc_blow_up_getcall") && "block" == document.getElementById("ffc_blow_up_getcall").style.display || null != document.getElementById("ffc_blow_up_sms") && "block" == document.getElementById("ffc_blow_up_sms").style.display || null != document.getElementById("light") && "block" == document.getElementById("light").style.display) && (show_form_flag = 0), $("#twostepenquiry").removeClass("tdw_pp_f2Nusr"), (cookie_enquiry = getCartCookie("querysent")) > "" || " srnt_p" == document.getElementById("searchnotfound").className || 0 == show_form_flag);
    else {
        if ($("html").css("overflow", "hidden"), (cookie = getCartCookie("CART_SESSION")) > "" && "[[],{}]" != cookie) {
            myCart = eval("(" + cookie + ")");
            var itemsArr = myCart[0];
            if (Selected_product.prd_id = itemsArr[0].item_id, Selected_product.prd_code = itemsArr[0].item_code, Selected_product.prd_name = itemsArr[0].item_name, Selected_product.prd_img = itemsArr[0].item_img, Selected_product.prd_dis_id = itemsArr[0].item_dis_id, Selected_product.prd_mcatid = itemsArr[0].item_mcatid, in_cart_exist = 1, pagecount = "", pagename = "", name_of_page = "", countes = "", document.zoom_dataform.modref_id) try {
                document.zoom_dataform.modref_type.value = 2, document.zoom_dataform.modref_id.value = Selected_product.prd_dis_id, document.zoom_dataform.modref_name.value = Selected_product.prd_name, document.zoom_dataform.mcat_id.value = Selected_product.prd_mcatid
            } catch (e) {}
            var div_isq = "";
            if (void 0 !== itemsArr[0].item_isq_det)
                for (var i = 0; i < Math.min(itemsArr[0].item_isq_det.length, 5); i++) div_isq += '<span class="tdw_pb7">' + itemsArr[0].item_isq_det[i].FK_IM_SPEC_MASTER_DESC + '-<span class="tdw_clr1">' + itemsArr[0].item_isq_det[i].SUPPLIER_RESPONSE_DETAIL + "</span></span><br>";
            void 0 !== div_isq && (document.getElementById("add_isq_det").innerHTML = div_isq), localStorage.setItem("Isq_set_prop", JSON.stringify(itemsArr[0].item_isq_det)), "" == itemsArr[0].item_img && "undefined" != typeof CompLogo_EnqForm && "" != CompLogo_EnqForm && (itemsArr[0].item_img = CompLogo_EnqForm), "undefined" != typeof CompLogo_EnqForm && "" != CompLogo_EnqForm ? document.getElementById("bimg_zoom_up_center").innerHTML = '<img src="' + itemsArr[0].item_img + '" alt="' + unescape(itemsArr[0].item_name) + '" name="imgBoxPopup">' : document.getElementById("bimg_zoom_up_center").innerHTML = '<span class="tdw_dflt_img sprite"></span>', document.getElementById("bimgname_zoom_title" + form_type).innerHTML = unescape(itemsArr[0].item_name), $(".cen2_p").css("background-color", ""), $("#default_icon,#3pv_desc,#txt_id_3pv").css("display", "none"), icode = "", "undefined" !== itemsArr[0].item_code && "" != itemsArr[0].item_code && itemsArr[0].item_code != itemsArr[0].item_id && (icode = "(" + itemsArr[0].item_code + ")"), zoomup_desc_value = "Send us quotation & details of '" + unescape(itemsArr[0].item_name) + icode + "'."
        } else if ("undefined" != typeof dataref1) {
            if (document.zoom_dataform.modref_id) try {
                document.zoom_dataform.modref_type.value = 2, document.zoom_dataform.modref_id.value = dataref1[0].prd_dis_id, document.zoom_dataform.modref_name.value = dataref1[0].prd_name, null == dataref1[0].prd_mcatid && (dataref1[0].prd_mcatid = ""), document.zoom_dataform.mcat_id.value = dataref1[0].prd_mcatid
            } catch (e) {}
            var div_isq = "";
            if (void 0 !== dataref1[0].isq_det_form)
                for (var i = 0; i < Math.min(dataref1[0].isq_det_form.length, 5); i++) div_isq += '<span class="tdw_pb7">' + dataref1[0].isq_det_form[i].FK_IM_SPEC_MASTER_DESC + '-<span class="tdw_clr1">' + dataref1[0].isq_det_form[i].SUPPLIER_RESPONSE_DETAIL + "</span></span><br>";
            void 0 !== div_isq && (document.getElementById("add_isq_det").innerHTML = div_isq), localStorage.setItem("Isq_set_prop", JSON.stringify(dataref1[0].isq_det_form)), document.getElementById("bimg_zoom_up_center").innerHTML = '<img src="' + dataref1[0].img_path + '" alt="' + unescape(dataref1[0].prd_name) + '" name="imgBoxPopup">', document.getElementById("bimgname_zoom_title" + form_type).innerHTML = unescape(dataref1[0].prd_name), dataref1[0].prd_price && (document.getElementById("bimgname_zoom_price" + form_type).innerHTML = unescape(dataref1[0].prd_price) + "<br>"), $(".cen2_p").css("background-color", ""), $("#default_icon,#3pv_desc,#txt_id_3pv").css("display", "none"), icode = "", "undefined" !== dataref1[0].prd_code && "" != dataref1[0].prd_code && dataref1[0].prd_code != dataref1[0].prd_id && (icode = "(" + dataref1[0].prd_code + ")"), zoomup_desc_value = "Send us quotation & details of '" + unescape(dataref1[0].prd_name) + icode + "'."
        } else "undefined" != typeof CompLogo_EnqForm && "" != CompLogo_EnqForm ? document.getElementById("bimg_zoom_up_center").innerHTML = '<img src="' + CompLogo_EnqForm + '" alt="' + unescape(CompanyName) + '" name="imgBoxPopup" id="showimg">' : (document.getElementById("default_icon").style.display = "block", $(".cen2_p").css("background-color", "#fff"), $("#imgbox").css("display", "none")), $("#bimgname_zoom_title" + form_type + ",#bg_zoom_title1").css("display", "none"), document.getElementById("3pv_desc").style.display = "block";
        var show = "prd_f",
            hide = "prd_f_imgform";
        $("#ffc_blow_up").removeClass("imgforms"), "_imgform" == form_type && ($("#ffc_blow_up").addClass("imgforms"), show = "prd_f_imgform", hide = "prd_f");
        for (var divsToShow = document.getElementsByClassName(show), i = 0; i < divsToShow.length; i++) divsToShow[i].style.display = "block";
        for (var divsToHide = document.getElementsByClassName(hide), i = 0; i < divsToHide.length; i++) divsToHide[i].style.display = "none";
        document.getElementById("prd_form").style.display = "none", document.getElementById("non_prd_form").style.display = "none", document.getElementById("auto_zoom_form").style.display = "block", $("#arrow,#contact_btn,#ask_price,#GetBestQuote,#GetLatestPrice,#ImgForm,#GetBestQuote_video,#contInfo,#Rcb_btn,#Sbt_sendSMS,#Sbt_sendEmail,#Sbt_CallUs").css("display", "none"), $("#ffc_blow_up,#fgb_blow,#closebtn,#contact_btn1,#dataform_alrt").css("display", "block"), zoomup_desc_placeholder = "To get Quotations and Details kindly describe your requirement for your products.", document.getElementById("tnkMsg").innerHTML = "<i>We will get in touch with you shortly.</i>", document.getElementById("dataform_alert_display") && "" == document.getElementById("dataform_alert_display").innerHTML && (document.getElementById("dataform_alert_display").innerHTML = '<p id="enqsent" class="fnt3_zoom bg_p"><span class="rght_p blow"></span><span class="fts_p">Thank you !</span><br>Your enquiry has been sent successfully.</p>'), document.getElementById("Description1").value = zoomup_desc_placeholder, document.zoom_dataform.Description1.className = "c11_p", "Enter your email" == document.zoom_dataform.S_email.value || (document.zoom_dataform.S_email.className = ""), (cookie1 = getCartCookie("ImeshVisitor")) > "" ? "" != getparamVal1(cookie1, "em") && "+91" != document.getElementById("mobile-number_zoom_dataform").value && $("#mobile-number_zoom_dataform").addClass("off_p") : get_ip()
    }
}

function empty_cart1() {
    var myCart;
    if ((cookie = getCartCookie("CART_SESSION")) > "") {
        myCart = eval("(" + cookie + ")");
        var itemsArr = myCart[0],
            itemsArr1 = myCart[1];
        for (x in itemsArr.splice(0, itemsArr.length), itemsArr1) delete itemsArr1[x];
        var myCartJSON = window.JSON ? JSON.stringify(myCart) : myCart.toJSONString();
        setCartCookie1("CART_SESSION", myCartJSON)
    }
    return !0
}

function cart_display(e) {}
inactivityTime();
var searchcheck = "";

function checkfunction(e) {
    searchcheck = e, setTimeout(function() {
        document.getElementById("searchnotfound").className = " srnt_p", document.getElementById("on250").className = "", document.getElementById("ffc_blow_up").style.display = "block", document.getElementById("ffc_blow_up").className += " ps11", document.getElementById("dataform_alrt").className += " m33", document.getElementById("ch_srch").className += " fl1", document.getElementById("searchnotfound1").style.display = "block", document.getElementById("contact_btn").style.display = "none", document.getElementById("searchnotfound2").style.display = "block", document.getElementById("Description1").style.display = "block", document.getElementById("Description1").setAttribute("placeholder", "Describe your requirement in detail:"), setTimeout(function() {
            $("#searchnotfound .email_wid").attr("style", "width: 90.8% !important")
        }, 1e3), document.zoom_dataform.S_reference_text.value = "#footerform_Searchnotfound/" + pagenameqw, "" != im_readCookie("ImeshVisitor") && "function" == typeof fill_cookies && fill_cookies()
    }, 1e3)
}
var pos_in_cart = 0;

function add_item_cart(iid, pcode, pname, pimg, psimg, referer, disid, mcatid) {
    var myCart, myCart = new Array(2);
    myCart[0] = new Array, myCart[1] = new Object;
    var item = new Object;
    item.item_id = iid, item.item_code = pcode, item.item_name = pname, item.item_img = pimg, item.item_simg = psimg, item.item_dis_id = disid, item.item_mcatid = mcatid, myCart[0][myCart[0].length] = item, pos_in_cart = myCart[0].length - 1, times = new Date, item.time = times, getCartCookie("querysent") > "" || show_form_onpage(), myCart[1].referer = eval(referer);
    var myCartJSON = window.JSON ? JSON.stringify(myCart) : myCart.toJSONString();
    return setCartCookie1("CART_SESSION", myCartJSON), imgset_zoom(pos_in_cart, "prd"), !0
}

function removeitem1(i, frm) {
    var myCart;
    if ((cookie = getCartCookie("CART_SESSION")) > "") {
        myCart = eval("(" + cookie + ")");
        var itemsArr = myCart[0];
        myCart[0].splice(i, 1), 0 == itemsArr.length && (myCart[1].message1 = "Your Enquiry Basket has been emptied");
        var myCartJSON = window.JSON ? JSON.stringify(myCart) : myCart.toJSONString();
        setCartCookie1("CART_SESSION", myCartJSON)
    }
    return !0
}

function ExpandCollapse(e) {
    "plus" == e ? (document.getElementById("plus").style.display = "block", document.getElementById("minus").style.display = "none") : (document.getElementById("minus").style.display = "block", document.getElementById("plus").style.display = "none")
}
popupopen = "";
var Selected_product = new Array,
    imgid_zoom = 0,
    display_form = 0;

function checkCntryFlag() {
    if ((cookie1 = getCartCookie("ImeshVisitor")) > "") foreignFlg = "IN" == getparamVal1(cookie1, "iso") ? 0 : 1;
    else if ("" != im_readCookie("iploc")) {
        var e = getparamVal1(getCartCookie("iploc"), "gcniso");
        foreignFlg = "IN" == e ? 0 : 1
    } else foreignFlg = "+91" != document.getElementById("mobile-number_zoom_dataform").value ? 1 : 0;
    return foreignFlg
}

function imgset_zoom(id, switchpr) {
    popupopen = "zoom_dataform";
    var form_type = "",
        smsEmailForm = "",
        countes_same = countes,
        tnkMsg = "";
    trackType = "", "count_callback" == countes ? ($("#tnk_msg_rcb").show(), $("#tnk_msg_other").hide()) : ($("#tnk_msg_other").show(), $("#tnk_msg_rcb").hide()), $("#imgf_head").html("Get customised quotes from us"), $("#Quan_unt").html(""), $("#isq_imgf select,#isq_imgf input").val(""), $("#isq_fields_imgf").css("display", "none"), $("#ipt_fld_head").html("Mobile Number"), $("#productform").removeClass("tdw_w100"), document.zoom_dataform.enqform_type.value = switchpr, document.zoom_dataform.enqform_cta.value = id, $("html").css("overflow", "hidden"), "Send_sms_email" == switchpr ? (document.zoom_dataform.S_reference_text.value = "#" + id + "/" + pagenameqw, document.zoom_dataform.Description.value = "sendEmail" == id ? "I am interested in your product and services. Please send us quotation & details" : "Please send us quotation & details quickly, as I am intertested in your product and services", smsEmailForm = "smsEmailform") : (smsEmailForm = "", "catindex" == name_of_page || "catindex" == pagename ? "count4" == countes ? document.zoom_dataform.S_reference_text.value = "#get-quotation" : "count5" == countes || "counter5" == pagecount ? document.zoom_dataform.S_reference_text.value = "#getBestQuote/" + pagenameqw : (document.zoom_dataform.S_reference_text.value = "#imagezoomup/" + pagenameqw, form_type = "_imgform") : "productpage" == name_of_page || "productpage" == pagename ? "counter2" == pagecount || "count2" == countes ? (document.zoom_dataform.S_reference_text.value = "#imagezoomup/" + pagenameqw, trackType = "#imagezoomup-product", form_type = "_imgform") : "count5" == countes || "counter5" == pagecount ? document.zoom_dataform.S_reference_text.value = "#getBestQuote/" + pagenameqw : "count_glp" == countes ? document.zoom_dataform.S_reference_text.value = "#getLatestPrice/" + pagenameqw : "count_glp_na" == countes ? document.zoom_dataform.S_reference_text.value = "#getLatestPrice_na/" + pagenameqw : "count_callback" == countes ? (document.zoom_dataform.S_reference_text.value = "#rcb/" + pagenameqw, trackType = "#rcb-product") : "countvid" == countes || "countvid" == pagecount ? document.zoom_dataform.S_reference_text.value = "#gbq_video/" + pagenameqw : "count_intrstd" == countes ? (document.zoom_dataform.S_reference_text.value = "#IMInterested/" + pagenameqw, trackType = "#IMInterested", form_type = "#IMInterested") : document.zoom_dataform.S_reference_text.value = "#askforprice/" + pagenameqw : "searchpage" == name_of_page || "searchpage" == pagename ? "counter3" == pagecount || "count3" == countes ? (document.zoom_dataform.S_reference_text.value = "#imagezoomup/" + pagenameqw, form_type = "_imgform") : "count5" == countes || "counter5" == pagecount ? document.zoom_dataform.S_reference_text.value = "#getBestQuote/" + pagenameqw : "count_glp" == countes ? document.zoom_dataform.S_reference_text.value = "#getLatestPrice/" + pagenameqw : "count_glp_na" == countes ? document.zoom_dataform.S_reference_text.value = "#getLatestPrice_na/" + pagenameqw : "count_callback" == countes ? (document.zoom_dataform.S_reference_text.value = "#rcb/" + pagenameqw, trackType = "#rcb-product") : "count_intrstd" == countes ? (document.zoom_dataform.S_reference_text.value = "#IMInterested/" + pagenameqw, trackType = "#IMInterested", form_type = "#IMInterested") : document.zoom_dataform.S_reference_text.value = "countvid" == countes || "countvid" == pagecount ? "#gbq_video/" + pagenameqw : "#askforprice/" + pagenameqw : "index" == pagename || "index" == name_of_page ? "countvid" == countes ? (document.zoom_dataform.S_reference_text.value = "#gbq_video/" + pagenameqw, trackType = "#gbq_homepage") : "count5" == countes || "counter5" == pagecount ? document.zoom_dataform.S_reference_text.value = "#getBestQuote/" + pagenameqw : (document.zoom_dataform.S_reference_text.value = "#imagezoomup/" + pagenameqw, form_type = "_imgform") : "corporatevideopage" == pagename ? (document.zoom_dataform.S_reference_text.value = "#gbq_video/" + pagenameqw, trackType = "#gbq_homepage") : "productpageslider" == name_of_page && (document.zoom_dataform.S_reference_text.value = "#gbq_slider", name_of_page = "productpage"), "index" == pagename && "countvid" == countes || "productpage" == pagename && "count5" == countes || "searchpage" == pagename && "count5" == countes || "productpage" == name_of_page && "counter5" == pagecount || "catindex" == pagename && "count5" == countes || "index" == pagename && "count5" == countes || "corporatevideopage" == pagename && "countvid" == countes || "productpage" == pagename && "countvid" == countes ? document.getElementById("txt_id").innerHTML = "Get Best Quote" : "productpage" == pagename && "count_glp" == countes || "searchpage" == pagename && "count_glp" == countes ? document.getElementById("txt_id").innerHTML = "Get Best Price" : "productpage" == pagename && "count_callback" == countes || "searchpage" == pagename && "count_callback" == countes ? (document.getElementById("txt_id").innerHTML = "Get CALLBACK", document.getElementById("S_name_zoom_dataform").style.display = "block") : document.getElementById("txt_id").innerHTML = "productpage" == pagename && "count2" != countes || "searchpage" == pagename && "count3" != countes || "productpage" == name_of_page && "counter6" == pagecount ? "Ask Price" : "Contact Us"), "count_glp_na" == countes && (countes = "count_glp"), document.getElementById("int_fd_err") && $("#int_fd_err").removeClass("tdw_err"), document.getElementById("int_fd_err1") && $("#int_fd_err1").removeClass("tdw_err"), tnkMsg = "counter2" == pagecount || "counter3" == pagecount || "index" == pagename && "Send_sms_email" != countes ? "<i>We will share the Quotations & Details with you soon.</i>" : "count3" == countes || "count2" == countes || "count5" == countes || "countvid" == countes || "count_glp" == countes || "category" == name_of_page || "category" == pagename || "Send_sms_email" == countes ? "<i>We will contact you on this number.</i>" : "count_callback" == countes ? "<i>We will contact you soon for better understanding of your requirement & specification.</i>" : "<i>We will contact you on this number.</i>", $("#emailfield_zoom_dataform").is(":visible") && "count_callback" == countes && (tnkMsg = "We will contact you on this email"), document.getElementById("tnkMsg").innerHTML = tnkMsg;
    var in_cart_exist = 0;
    document.getElementById("default_icon").style.display = "none", $(".cen2_p").css("background-color", ""), document.getElementById("3pv_desc").style.display = "none", document.getElementById("closebtn").style.display = "block", document.getElementById("bimgname_zoom_title" + form_type) && (document.getElementById("bimgname_zoom_title" + form_type).style.display = "block"), document.getElementById("bimgname_zoom_price" + form_type) && "Send_sms_email" != countes && (document.getElementById("bimgname_zoom_price" + form_type).style.display = "block"), document.getElementById("contact_btn").style.display = "block", $("#contact_btn1,#ask_price,#GetLatestPrice,#ImgForm,#GetBestQuote,#GetBestQuote_video,#Rcb_btn,#dataform_alert_display,#showVdoimg,#showVdoimg1,#Sbt_sendSMS,#Sbt_sendEmail,#Sbt_getInTouch,#Sbt_CallUs,#Imgf_iden_usr").css("display", "none");
    var pic = document.getElementById("bimg_zoom_up_center");
    if ("Send_sms_email" != switchpr) {
        var cart_index = 0,
            itemBigImage = "";
        for (temp2 in dataref1)
            if (dataref1[temp2].img_id == id) {
                var myCart, referer = window.location.href,
                    myCart = new Array(2);
                myCart[0] = new Array, myCart[1] = new Object;
                var item = new Object;
                item.item_id = dataref1[temp2].img_id, item.item_code = dataref1[temp2].prd_code, item.item_name = dataref1[temp2].prd_name, item.item_img = dataref1[temp2].img_path, item.item_simg = dataref1[temp2].img_path1, item.item_dis_id = dataref1[temp2].prd_dis_id, item.item_mcatid = dataref1[temp2].prd_mcatid, item.item_price = dataref1[temp2].prd_price, item.item_isq_det = dataref1[temp2].isq_det_form, myCart[0][myCart[0].length] = item, pos_in_cart = myCart[0].length - 1, times = new Date, item.time = times;
                var div_isq = "";
                dataref1[temp2].isq_det_form && null != dataref1[temp2].isq_det_form || (dataref1[temp2].isq_det_form = "");
                for (var i = 0; i < Math.min(dataref1[temp2].isq_det_form.length, 5); i++) div_isq += '<span class="tdw_pb7">' + dataref1[temp2].isq_det_form[i].FK_IM_SPEC_MASTER_DESC + '-<span class="tdw_clr1">' + dataref1[temp2].isq_det_form[i].SUPPLIER_RESPONSE_DETAIL + "</span></span><br>";
                localStorage.setItem("Isq_set_prop", JSON.stringify(dataref1[temp2].isq_det_form)), void 0 !== div_isq && (document.getElementById("add_isq_det").innerHTML = div_isq), getCartCookie("querysent") > "" || show_form_onpage(), myCart[1].referer = referer;
                var myCartJSON = window.JSON ? JSON.stringify(myCart) : myCart.toJSONString();
                setCartCookie1("CART_SESSION", myCartJSON), ("productpage" == pagename && "count2" != countes || "searchpage" == pagename && "count3" != countes) && (document.getElementById("ask_price").style.display = "block", document.getElementById("contact_btn").style.display = "none"), "productpage" != pagename && "index" != pagename && "catindex" != pagename || "count5" != countes || (document.getElementById("GetBestQuote").style.display = "block", document.getElementById("contact_btn").style.display = "none", document.getElementById("ask_price").style.display = "none"), "productpage" == pagename && "count_glp" == countes && (document.getElementById("GetLatestPrice").style.display = "block", document.getElementById("contact_btn").style.display = "none", document.getElementById("ask_price").style.display = "none"), "productpage" == pagename && "count2" == countes && (document.getElementById("ImgForm").style.display = "block", document.getElementById("contact_btn").style.display = "none", document.getElementById("ask_price").style.display = "none"), "productpage" == pagename && "count_callback" == countes && (document.getElementById("Rcb_btn").style.display = "block", document.getElementById("contact_btn").style.display = "none", document.getElementById("ask_price").style.display = "none"), "index" == pagename && "countvid" == countes && (document.getElementById("GetBestQuote_video").style.display = "block", document.getElementById("contact_btn").style.display = "none", document.getElementById("ask_price").style.display = "none")
            }
        var mainDivId = id;
        if ((cookie = getCartCookie("CART_SESSION")) > "") {
            myCart = eval("(" + cookie + ")");
            var itemsArr = myCart[0],
                itemBigImage = "",
                itemImage = "",
                multi_div = "",
                multi_div_vdocode = "";
            if (id = 0, document.getElementById("multi_img_box") && (document.getElementById("multi_img_box").innerHTML = ""), document.getElementById("bimgname_zoom_price" + form_type) && (document.getElementById("bimgname_zoom_price" + form_type).innerHTML = ""), document.getElementById("arrw1") && (document.getElementById("arrw1").style.display = "none"), document.getElementById("arrw2") && (document.getElementById("arrw2").style.display = "none"), "" != itemsArr[id].item_img)
                if ("search" == pagename || "search" == name_of_page || "index" == pagename || "catindex" == name_of_page) pic.innerHTML = '<img src="' + itemsArr[id].item_img + '" alt="' + unescape(itemsArr[id].item_name) + '">';
                else {
                    itemBigImage = void 0 !== window.selectedMultiImage && void 0 !== document[window.selectedMultiImage] ? document[window.selectedMultiImage].getAttribute("data-bimg") : itemsArr[id].item_simg, multi_div = void 0 !== window.selectedMultiImage && void 0 !== document[window.selectedMultiImage] ? document[window.selectedMultiImage].getAttribute("data-multiimg") : "", multi_div_vdocode = void 0 !== window.selectedMultiImage && void 0 !== document[window.selectedMultiImage] ? document[window.selectedMultiImage].getAttribute("data-vdocode") : "";
                    var divContent = "";
                    if ("" != multi_div) {
                        var arr_multi_div = multi_div.split(",");
                        for (var x in multi_div.split(",")) divContent += "" != multi_div_vdocode && 1 == x ? '<li class="tdw_pp_mb10 tdw_pos_rel"><p class="hcVdo_BVdoI pa bg4 zi2 tl50P" style="width:36px;height:24px;" onclick="playVideo(\'' + multi_div_vdocode + '\')"></p><span href="#" class="tdw_pp_df tdw_pp_ai tdw_pp_jc tdw_pp_cp"><img src="' + arr_multi_div[x] + '" style="width:60px;height:60px;" onmouseover="changeImages(\'vdoBoxPopup\',\' ' + arr_multi_div[x] + "',this);on_formvideo_mouseover('vdo');return true;\" onclick=\"playVideo('" + multi_div_vdocode + "')\"></span></li>" : '<li class="tdw_pp_mb10 tdw_pos_rel"><span href="#" class="tdw_pp_df tdw_pp_ai tdw_pp_jc tdw_pp_cp"><img src="' + arr_multi_div[x] + '" style="width:60px;height:60px;" onmouseover="changeImages(\'imgBoxPopup\',\' ' + arr_multi_div[x] + "',this);on_formvideo_mouseover('img');return true;\"></span></li>";
                        var arrwup = '<div class="arw16_p"></div>',
                            arrwdown = '<div class="arw16_p"></div>',
                            sdcls1 = "sd17_p",
                            sdcls2 = "sd16_p";
                        arr_multi_div.length > 4 && (arrwup = "<div class=\"smlr_p arw16_p arw17_p cu_p mo_p\" onclick=\"return slide('thumbnail-containerpop','up');\"></div>", arrwdown = "<div class=\"smlr_p arw16_p arw18_p cu_p mo_p\" onclick=\"return slide('thumbnail-containerpop','down');\"></div>"), arr_multi_div.length >= 4 ? (sdcls1 = "sd13_p", sdcls2 = "sd11_p") : 3 == arr_multi_div.length && (sdcls1 = "sd15_p", sdcls2 = "sd14_p"), divContent = '<ul id="thumbnail-containerpop" class="tdw_pp_tn">' + divContent + "</ul>", document.getElementById("multi_img_box").innerHTML = divContent, arr_multi_div.length >= 7 && (document.getElementById("arrw1").style.display = "block", document.getElementById("arrw2").style.display = "block")
                    }
                    itemImage = void 0 !== window.selectedMultiImage && void 0 !== document[window.selectedMultiImage] ? document[window.selectedMultiImage].src : itemsArr[id].item_simg;
                    var vdoDivId = "pvdo" + mainDivId;
                    "undefined" != document.getElementById(vdoDivId) && "none" != document.getElementById(vdoDivId).style.display && "" != multi_div_vdocode && null != document.getElementById("showVdoimg") && "none" == document.getElementById("showVdoimg").style.display ? (pic.innerHTML = '<img src="' + itemBigImage + '" alt="' + unescape(itemsArr[id].item_name) + '" name="imgBoxPopup" id="showimg" style="display:none;"><p class="hcVdo_BVdoI pa bg4 zi2 tl50P tdw_pp_cp" id="showVdoimg1" style="display:block;" onclick="playVideo(\'' + multi_div_vdocode + '\');"></p><img src="' + itemBigImage + '" alt="' + unescape(itemsArr[id].item_name) + '" name="vdoBoxPopup" id="showVdoimg" onclick="playVideo(\'' + multi_div_vdocode + '\');" style="display:block;">', $(".enqload_blow").html("")) : (pic.innerHTML = '<img src="' + itemBigImage + '" alt="' + unescape(itemsArr[id].item_name) + '" name="imgBoxPopup" id="showimg"><p class="hcVdo_BVdoI pa bg4 zi2 tl50P tdw_pp_cp" id="showVdoimg1" style="display:none;" onclick="playVideo(\'' + multi_div_vdocode + '\');"></p><img src="' + itemBigImage + '" alt="' + unescape(itemsArr[id].item_name) + '" name="vdoBoxPopup" id="showVdoimg" onclick="playVideo(\'' + multi_div_vdocode + '\');" style="display:none;" class="tdw_pp_cp">', $(".enqload_blow").html(""))
                }
            else "undefined" != typeof CompLogo_EnqForm && "" != CompLogo_EnqForm ? pic.innerHTML = '<img src="' + CompLogo_EnqForm + '" alt="' + unescape(CompanyName) + '" name="imgBoxPopup" id="showimg">' : pic.innerHTML = '<span class="tdw_dflt_img sprite"></span>';
            if (document.getElementById("bimgname_zoom_title_imgform") && (document.getElementById("bimgname_zoom_title_imgform").innerHTML = unescape(itemsArr[id].item_name)), document.getElementById("bimgname_zoom_title") && (document.getElementById("bimgname_zoom_title").innerHTML = unescape(itemsArr[id].item_name)), itemsArr[id].item_price && (document.getElementById("bimgname_zoom_price_imgform") && (document.getElementById("bimgname_zoom_price_imgform").innerHTML = unescape(itemsArr[id].item_price) + "<br>"), document.getElementById("bimgname_zoom_price") && (document.getElementById("bimgname_zoom_price").innerHTML = unescape(itemsArr[id].item_price) + "<br>")), zoomup_desc_placeholder = "category" == name_of_page && "counter1" == pagecount ? "Please send details of product in category '" + unescape(itemsArr[id].item_name) + "'." : "productpage" == pagename && "count5" == countes || "searchpage" == pagename && "count5" == countes || "productpage" == name_of_page && "counter5" == pagecount ? "To get Best Quote kindly describe your requirement for '" + unescape(itemsArr[id].item_name) + "'." : "productpage" == pagename && "count2" != countes || "searchpage" == pagename && "count3" != countes || "productpage" == name_of_page && "counter6" == pagecount ? "To get Best Price kindly describe your requirement for '" + unescape(itemsArr[id].item_name) + "'." : "To get Quotations and Details kindly describe your requirement for '" + unescape(itemsArr[id].item_name) + "'.", icode = "", "undefined" !== itemsArr[id].item_code && "" != itemsArr[id].item_code && itemsArr[id].item_code != itemsArr[id].item_id && (icode = "(" + itemsArr[id].item_code + ")"), zoomup_desc_value = "Send us quotation & details of '" + unescape(itemsArr[id].item_name) + icode + "'.", "count_glp" == countes_same && "productpage" == pagename && (zoomup_desc_value = "Send us the best price & quotation of '" + unescape(itemsArr[id].item_name) + icode + "'."), "count_callback" == countes_same && (zoomup_desc_value = "Need to discuss about my requirements for '" + unescape(itemsArr[id].item_name) + icode + "'.Please call me at number shared with you."), document.getElementById("Description1").value = zoomup_desc_placeholder, document.zoom_dataform.Description1.className = "c11_p", "index" == pagename && "countvid" != countes && "count5" != countes && (document.getElementById("txt_id").innerHTML = "Contact Us"), Selected_product.prd_id = itemsArr[id].item_id, Selected_product.prd_code = itemsArr[id].item_code, Selected_product.prd_name = itemsArr[id].item_name, Selected_product.prd_img = itemsArr[id].item_img, Selected_product.prd_dis_id = itemsArr[id].item_dis_id, Selected_product.prd_mcatid = itemsArr[id].item_mcatid, in_cart_exist = 1, pagecount = "", pagename = "", name_of_page = "", countes = "", document.zoom_dataform.modref_id) try {
                document.zoom_dataform.modref_type.value = 2, document.zoom_dataform.modref_id.value = Selected_product.prd_dis_id, document.zoom_dataform.modref_name.value = Selected_product.prd_name, document.zoom_dataform.mcat_id.value = Selected_product.prd_mcatid
            } catch (e) {}
            for (temp1 in dataref1)
                if (dataref1[temp1].prd_id == itemsArr[id].item_id) {
                    cart_index = dataref1[temp1].img_id;
                    break
                }
        }
        imgid_zoom = parseInt(cart_index)
    } else document.getElementById("Sbt_" + id) && (document.getElementById("Sbt_" + id).style.display = "block", document.getElementById("contact_btn").style.display = "none");
    var show = "prd_f",
        hide = "prd_f_imgform";
    $("#ffc_blow_up").removeClass("imgforms"), "_imgform" == form_type && ($("#ffc_blow_up").addClass("imgforms"), show = "prd_f_imgform", hide = "prd_f");
    for (var divsToShow = document.getElementsByClassName(show), i = 0; i < divsToShow.length; i++) divsToShow[i].style.display = "block";
    for (var divsToHide = document.getElementsByClassName(hide), i = 0; i < divsToHide.length; i++) divsToHide[i].style.display = "none";
    document.getElementById("compdiv").style.display = "smsEmailform" == smsEmailForm || "_imgform" == form_type ? "none" : "block", document.getElementById("prd_form").style.display = "block", document.getElementById("non_prd_form").style.display = "none", document.getElementById("auto_zoom_form").style.display = "none", "Send_sms_email" == switchpr && (document.getElementById("bimgname_zoom_title").innerHTML = CompanyName, document.getElementById("bimgname_zoom_price").style.display = "none", document.getElementById("add_isq_det").style.display = "none", document.getElementById("non_prd_form").style.display = "block", document.getElementById("prd_form").style.display = "none", "undefined" != typeof CompLogo_EnqForm && "" != CompLogo_EnqForm ? document.getElementById("bimg_zoom_up_center").innerHTML = '<img src="' + CompLogo_EnqForm + '" alt="' + CompanyName + '" name="imgBoxPopup">' : document.getElementById("bimg_zoom_up_center").innerHTML = '<span class="tdw_dflt_img sprite"></span>'), void 0 !== form_type && "#IMInterested" == form_type && (document.getElementById("non_prd_form").style.display = "block", document.getElementById("prd_form").style.display = "none"), $("#dataform_alert_display").hide(), $("#imgbox").show(), $("#productform").show();
    var full_name = "";
    if ((cookie1 = getCartCookie("ImeshVisitor")) > "" && "count2" != countes_same && "count3" != countes_same ? ("" != getparamVal1(cookie1, "mb1") && (document.zoom_dataform.S_mobile.value = getparamVal1(cookie1, "mb1")), "" != getparamVal1(cookie1, "em") ? (document.zoom_dataform.S_email.value = getparamVal1(cookie1, "em"), document.zoom_dataform.S_email.className = "") : document.zoom_dataform.S_email.value = "", $("#dataform_alrt").hide(), $("#form_load").show()) : $("#dataform_alrt").show(), document.getElementById("ffc_blow_up").style.display = "block", (cookie1 = getCartCookie("ImeshVisitor")) > "" && "count_callback" == countes_same && ($("#infocus_div").hide(), $("#imgbox").hide(), _gaq.push(["b._trackEvent", "Body", "RCB/2-auto/" + pagenameqw, "" + PC_CLNT_TMPL_PATH])), display_form = 1, $("#ffc_blow_up").removeClass("ps11"), $(".f_w7_p").removeClass("fl1"), $("#dataform_alrt").removeClass("m33"), "" == im_readCookie("ImeshVisitor") ? (document.getElementById("S_email").value = "", document.getElementById("S_mobile2").value = "", get_ip(), $("#S_email").trigger("focus")) : "function" == typeof fill_cookies && fill_cookies(), product_style(), in_cart_exist ? $("#add_cart_icon").addClass("prd_exst") : $("#add_cart_icon").removeClass("prd_exst"), $("#emailfield_zoom_dataform").is(":visible") && $("#ipt_fld_head").html("Email ID"), document.zoom_dataform.Description.className = "c11_p", document.getElementById("d1").style.display = "none", document.getElementById("d1").innerHTML = "", primary_biz.match(/Service Provider/gi) ? $("#purpse").hide() : $("#purpse").show(), "count_callback" != countes_same && 0 == getIsq && (getIsq = 1, $.getScript("https://tdw.imimg.com/template-tdw/cent_dynamic/dyn_isq/otponly_dyn_isq.js")), foreignFlg = checkCntryFlag(), 1 == foreignFlg && getMiniDetails(), "count2" != countes_same && "count3" != countes_same) {
        var mobilevalue_with_cookie = check_Mobile(),
            emailvalue_with_cookie = check_Email();
        if (mobilevalue_with_cookie && emailvalue_with_cookie) {
            if ("count5" == countes_same && _gaq.push(["b._trackEvent", "Body", "GetBestQuote_S1/2-auto/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count_glp" == countes_same && _gaq.push(["b._trackEvent", "Body", "GetLatestPrice_S1/2-auto/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count_askpr" == countes_same && _gaq.push(["b._trackEvent", "Body", "AskForPrice_S1/2-auto/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count2" == countes_same && _gaq.push(["b._trackEvent", "Body", "ProductImage_S1/2-auto/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "countvid" == countes_same && _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S1/2-auto/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count_intrstd" == countes_same && _gaq.push(["b._trackEvent", "Body", "IMInterested_S1/2-auto/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "Send_sms_email" == switchpr && _gaq.push(["b._trackEvent", "Body", id + "_S1/2-auto/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "Send_sms_email" != switchpr && (document.zoom_dataform.Description.value = zoomup_desc_value), document.zoom_dataform.twostep.value = "twostep", "Enter your email" == document.zoom_dataform.S_email.value && (document.zoom_dataform.S_email.value = ""), document.zoom_dataform.S_mobile.value == getparamVal1(cookie1, "mb1") && "IN" != document.getElementById("txtCountry1").value && (document.zoom_dataform.S_mobile.value = ""), document.zoom_dataform.S_email.value == getparamVal1(cookie1, "em") && "IN" == document.getElementById("txtCountry1").value && (document.zoom_dataform.S_email.value = ""), "" != document.getElementById("multi_img_box").innerHTML && document.getElementById("thumbnail-containerpop") && "Send_sms_email" != switchpr) {
                var img_cha_div = $("#thumbnail-containerpop")[0].childNodes[0].childNodes[0].childNodes[0],
                    img_cha_src = $("#thumbnail-containerpop")[0].childNodes[0].childNodes[0].childNodes[0].src;
                img_cha_div && img_cha_src && (changeImages("imgBoxPopup", img_cha_src, img_cha_div), document.getElementById("showVdoimg") && (document.getElementById("showVdoimg").style.display = "none"), document.getElementById("showVdoimg1") && (document.getElementById("showVdoimg1").style.display = "none"), document.getElementById("showimg") && (document.getElementById("showimg").style.display = "block"))
            }
            $.post($(".zoom_dataform").attr("action"), $(".zoom_dataform").serialize(), function(e) {
                if ("OK" == e.response)
                    if ("count5" == countes_same && _gaq.push(["b._trackEvent", "Body", "GetBestQuote_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count_glp" == countes_same && _gaq.push(["b._trackEvent", "Body", "GetLatestPrice_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count_askpr" == countes_same && _gaq.push(["b._trackEvent", "Body", "AskForPrice_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count2" == countes_same && _gaq.push(["b._trackEvent", "Body", "ProductImage_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "countvid" == countes_same && _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count_intrstd" == countes_same && _gaq.push(["b._trackEvent", "Body", "IMInterested_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "Send_sms_email" == switchpr && _gaq.push(["b._trackEvent", "Body", id + "_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "count_callback" == countes_same) $("#infocus_div").hide(), $("#form_load").hide(), $("#imgbox").hide(), $("#contInfo").hide(), $("#twostepenquiry").hide(), $("#dataform_alert_display").show(), $("#productform").addClass("tdw_w100"), _gaq.push(["b._trackEvent", "Body", "RCB/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), setTimeout(function() {
                        fg_hideform_zoom()
                    }, 4e3);
                    else if ("" === document.getElementById("twostepenquiry").innerHTML) $.ajax({
                    type: "POST",
                    url: "/cgi/dyn_isq/twostep_dyn_isq_1.php",
                    data: {
                        tmpl_path: PC_CLNT_TMPL_PATH,
                        switchpr: switchpr
                    },
                    success: function(t) {
                        if ($("#twostepenquiry").html(t), $('input[name="ISQ_DESC"],input[name="ISQ_ID"],input[name="OPTION_DESC"],input[name="OPTION_ID"],input[name="mcatid"]').val(""), $('input[name="mcatid"]').val(Selected_product.prd_mcatid), $("#isq_fields").html(""), "Send_sms_email" != switchpr)
                            if ($("#form_head").html("<b>" + $("#txt_id").text() + "</b> by adding a few details of your<br> requirement"), null != dyn_isq_obj[Selected_product.prd_mcatid] && "" != dyn_isq_obj[Selected_product.prd_mcatid]) {
                                var o = dyn_isq_obj[Selected_product.prd_mcatid];
                                localStorage.setItem("ISQ", JSON.stringify(o)), cons_isq_fields(), twostep_show(e)
                            } else $.ajax({
                                type: "POST",
                                url: "/cgi/dyn_isq/get_dyn_isq_1.php",
                                data: {
                                    tmpl_path: PC_CLNT_TMPL_PATH,
                                    mcatid: Selected_product.prd_mcatid,
                                    set_isq_prop: item.item_isq_det,
                                    foreign_flag: foreignFlg
                                },
                                success: function(t) {
                                    var o = t,
                                        a = o.indexOf("{"),
                                        m = o.lastIndexOf("}") + 1;
                                    o = o.slice(a, m), localStorage.setItem("ISQ", o), o = JSON.parse(o), "" != Selected_product.prd_mcatid && null != Selected_product.prd_mcatid && (dyn_isq_obj[Selected_product.prd_mcatid] = o), cons_isq_fields(), twostep_show(e)
                                }
                            });
                        else twostep_show(e)
                    }
                });
                else if ($('input[name="ISQ_DESC"],input[name="ISQ_ID"],input[name="OPTION_DESC"],input[name="OPTION_ID"],input[name="mcatid"]').val(""), $('input[name="mcatid"]').val(Selected_product.prd_mcatid), $("#isq_fields").html(""), "Send_sms_email" != switchpr)
                    if ($("#form_head").html("<b>" + $("#txt_id").text() + "</b> by adding a few details of your <br>requirement"), null != dyn_isq_obj[Selected_product.prd_mcatid] && "" != dyn_isq_obj[Selected_product.prd_mcatid]) {
                        var t = dyn_isq_obj[Selected_product.prd_mcatid];
                        localStorage.setItem("ISQ", JSON.stringify(t)), cons_isq_fields(), twostep_show(e)
                    } else $.ajax({
                        type: "POST",
                        url: "/cgi/dyn_isq/get_dyn_isq_1.php",
                        data: {
                            tmpl_path: PC_CLNT_TMPL_PATH,
                            mcatid: Selected_product.prd_mcatid,
                            foreign_flag: foreignFlg
                        },
                        success: function(t) {
                            var o = t,
                                a = o.indexOf("{"),
                                m = o.lastIndexOf("}") + 1;
                            o = o.slice(a, m), localStorage.setItem("ISQ", o), o = JSON.parse(o), "" != Selected_product.prd_mcatid && null != Selected_product.prd_mcatid && (dyn_isq_obj[Selected_product.prd_mcatid] = o), cons_isq_fields(), twostep_show(e)
                        }
                    });
                else twostep_show(e);
                else $("#dataform_alrt").show(), $("#form_load,#twostepenquiry,#contInfo").hide()
            }, "json")
        }
        document.getElementById("m1").style.display = "none", document.getElementById("m2").style.display = "none", document.getElementById("e1_pop").style.display = "none", $("#S_email").removeClass("active_error2"), document.getElementById("int_fd_err") && $("#int_fd_err").removeClass("tdw_err"), document.getElementById("int_fd_err1") && $("#int_fd_err1").removeClass("tdw_err")
    } else if ("_imgform" == form_type && "" != im_readCookie("ImeshVisitor")) {
        var mobilevalue_with_cookie = check_Mobile(),
            emailvalue_with_cookie = check_Email();
        if (mobilevalue_with_cookie && emailvalue_with_cookie)
            if ($("#dataform_alrt").hide(), null != dyn_isq_obj[Selected_product.prd_mcatid] && "" != dyn_isq_obj[Selected_product.prd_mcatid]) {
                isq = dyn_isq_obj[Selected_product.prd_mcatid], $("#S_name_zoom_dataform,#tnkMsg,#int_fd_err,#int_fd_err1,#ImgForm").css("display", "none"), $("#Imgf_iden_usr").css("display", "block"), $("#Imgf_iden_usr input").val("Contact Us");
                var showobj = document.getElementById("Quan_unt"),
                    hideobj = document.getElementById("cust_qunt_val");
                if (toggleField(hideobj, showobj), "200" == isq.CODE && null != isq.DATA && isq.DATA[0].length > 0 && "Quantity" == isq.DATA[0][0].IM_SPEC_MASTER_DESC && "Quantity Unit" == isq.DATA[0][1].IM_SPEC_MASTER_DESC) {
                    $("#S_name_zoom_dataform,#tnkMsg,#int_fd_err,#int_fd_err1,#ImgForm").css("display", "none");
                    for (var optionsDesc = isq.DATA[0][1].IM_SPEC_OPTIONS_DESC, options = optionsDesc.split("##"), j = 0; j < options.length; j++) {
                        var isqTypeOption = document.createElement("option");
                        isqTypeOption.setAttribute("value", options[j]), isqTypeOption.textContent = options[j], $("#Quan_unt").append(isqTypeOption)
                    }
                    $("#isq_fields_imgf,#Imgf_iden_usr").css("display", "block"), $("#imgf_head").html("Enter required quantity to Get Best Price")
                } else itemsArr[id].item_price ? $("#imgf_head").html("") : $("#imgf_head").html("Interested ? Get Best Price here"), $("#Imgf_iden_usr input").val("Contact Now");
                $("#dataform_alrt").show()
            } else $.ajax({
                type: "POST",
                url: "/cgi/dyn_isq/get_dyn_isq_1.php",
                data: {
                    tmpl_path: PC_CLNT_TMPL_PATH,
                    mcatid: Selected_product.prd_mcatid,
                    foreign_flag: foreignFlg
                },
                success: function(e) {
                    var t = e,
                        o = t.indexOf("{"),
                        a = t.lastIndexOf("}") + 1;
                    if (t = t.slice(o, a), localStorage.setItem("ISQ", t), t = JSON.parse(t), "" != Selected_product.prd_mcatid && null != Selected_product.prd_mcatid && (dyn_isq_obj[Selected_product.prd_mcatid] = t), $("#S_name_zoom_dataform,#tnkMsg,#int_fd_err,#int_fd_err1,#ImgForm").css("display", "none"), $("#Imgf_iden_usr").css("display", "block"), $("#Imgf_iden_usr input").val("Contact Us"), "200" == t.CODE && null != t.DATA && t.DATA[0].length > 0 && "Quantity" == t.DATA[0][0].IM_SPEC_MASTER_DESC && "Quantity Unit" == t.DATA[0][1].IM_SPEC_MASTER_DESC) {
                        $("#S_name_zoom_dataform,#tnkMsg,#int_fd_err,#int_fd_err1,#ImgForm").css("display", "none");
                        for (var m = t.DATA[0][1].IM_SPEC_OPTIONS_DESC.split("##"), n = 0; n < m.length; n++) {
                            var d = document.createElement("option");
                            d.setAttribute("value", m[n]), d.textContent = m[n], $("#Quan_unt").append(d)
                        }
                        $("#isq_fields_imgf,#Imgf_iden_usr").css("display", "block"), $("#imgf_head").html("Enter required quantity to Get Best Price")
                    } else itemsArr[id].item_price ? $("#imgf_head").html("") : $("#imgf_head").html("Interested ? Get Best Price here"), $("#Imgf_iden_usr input").val("Contact Now");
                    $("#dataform_alrt").show()
                }
            })
    }
}

function fg_hideform_zoom() {
    if (display_form = 0, "#2pv-zoomup" == trackType ? _gaq.push(["b._trackEvent", "Body", "2pv-autozoomup-close", "" + PC_CLNT_TMPL_PATH]) : "#auto-zoomup" == trackType ? _gaq.push(["b._trackEvent", "Body", "autozoomup-close", "" + PC_CLNT_TMPL_PATH]) : "none" != document.getElementById("otpverification").style.display && _gaq.push(["b._trackEvent", "Body", "verify-close", "" + PC_CLNT_TMPL_PATH]), trackType = "", null != $("#qid").val() && "" != $("#qid").val() && "none" != $("#twostepenquiry").css("display")) {
        $("#dyn_isq_dtl").is(":visible") && "Send_sms_email" != document.zoom_dataform.enqform_type.value && check_qunt_isq() && fillOpt_det();
        var e = document.getElementById("ISQ_DESC") ? $("#ISQ_DESC").val() : "",
            t = document.getElementById("ISQ_ID") ? $("#ISQ_ID").val() : "",
            o = document.getElementById("OPTION_DESC") ? $("#OPTION_DESC").val() : "",
            a = document.getElementById("OPTION_ID") ? $("#OPTION_ID").val() : "",
            m = document.getElementById("mcatid") ? document.getElementById("mcatid").value : "",
            n = document.zoom_dataform.enqform_type.value,
            d = document.getElementById("query_destination") ? document.getElementById("query_destination").value : "";
        $.ajax({
            type: "POST",
            url: "/cgi/dyn_isq/autotdw_enquiry_pop_dyn_isq2.php",
            data: {
                finishEnq: "true",
                qid: $("#qid").val(),
                query_destination: d,
                ISQ_DESC: e,
                ISQ_ID: t,
                OPTION_DESC: o,
                OPTION_ID: a,
                enqform_type: n,
                mcatid: m
            },
            success: function(e) {}
        })
    }
    $("html").css("overflow", ""), attempts = 0, $("#ffc_blow_up,#fgb_blow,#twostepenquiry,#otpverification,#d1,#e1,#m1,#m2,#e1_t,#m1_t,#e1_pop,#f1,#f1_t,#contInfo").css("display", "none"), "" == im_readCookie("ImeshVisitor") ? (document.getElementById("S_email").value = "", document.getElementById("S_mobile2").value = "", get_ip()) : "function" == typeof fill_cookies && (fill_cookies(), "function" == typeof sync_all_form && sync_all_form()), document.zoom_dataform.S_email.className = "", document.zoom_dataform.S_mobile.className = "", "+91" == document.zoom_dataform.S_cmobile.value ? document.zoom_dataform.S_cmobile.className = "cnty_isd" : document.zoom_dataform.S_cmobile.className = "cnty_isd off_p"
}
var submitQuery = 0,
    enquirysent = 1;

function check_Email_focus(e, t) {
    "Enter your email" == e.value && (e.value = ""), e.className = "", null != t && 13 == t.keyCode && document.getElementById("SubmitEnq") && document.getElementById("SubmitEnq").focus(), document.zoom_dataform && (document.zoom_dataform.S_mobile.value = ""), document.twostep_dataform && (document.twostep_dataform.S_mobile.value = ""), document.getElementById("e1_pop").style.display = "none", $("#int_fd_err").removeClass("tdw_err")
}

function check_Mobile_focus(e) {
    "Enter your mobile" == e.value && (e.value = ""), e.className = "", document.zoom_dataform.S_cmobile.className = "cnty_isd", document.getElementById("m1").style.display = "none", $("#int_fd_err").removeClass("tdw_err")
}

function check_Phone_focus(e) {
    "Enter your phone number" == e.value && (e.value = ""), e.className = "", document.zoom_dataform.S_cmobile.className = "cnty_isd", document.getElementById("m2").style.display = "none", $("#int_fd_err1").removeClass("tdw_err"), $("#int_fd_err").removeClass("tdw_err")
}

function check_Description_focus(e) {
    e.value == zoomup_desc_placeholder && (e.value = ""), e.className = "", document.getElementById("d1").style.display = "none"
}

function check_Fullname_focus(e) {
    "Enter your name" == e.value && (e.value = ""), e.focus(), e.className = "", document.getElementById("f1").style.display = "none"
}

function check_Fullname() {
    return foreign = 0, "+91" != document.getElementById("mobile-number_zoom_dataform").value ? foreign = 1 : foreign = 0, "none" == document.getElementById("fullnamefs").style.display || (document.zoom_dataform.fullname.value = document.zoom_dataform.fullname.value.replace(/^\s+/, ""), 1 != foreign || "" != document.zoom_dataform.fullname.value && "Enter your name" != document.zoom_dataform.fullname.value ? "Enter your name" == document.zoom_dataform.fullname.value ? (document.zoom_dataform.fullname.className = "c11_p", document.getElementById("f1").style.display = "none", !0) : "" == document.zoom_dataform.fullname.value || /^\s+$/.test(document.zoom_dataform.fullname.value) || /^[A-z][A-z. ]{0,42}$/.test(document.zoom_dataform.fullname.value) ? ("" == document.getElementById("fullnamefs").value ? (document.getElementById("fullnamefs").value = "Enter your name", document.zoom_dataform.fullname.className = "c11_p", document.getElementById("f1").style.display = "none") : (document.zoom_dataform.fullname.className = "", document.getElementById("f1").style.display = "none"), !0) : (document.getElementById("f1").style.display = "block", document.getElementById("f1").innerHTML = "Please enter valid name.", document.zoom_dataform.fullname.className = "", !1) : (document.getElementById("fullnamefs").value = "Enter your name", document.getElementById("f1").style.display = "block", document.getElementById("f1").innerHTML = "Please enter your name.", document.zoom_dataform.fullname.className = "c11_p", !1))
}

function check_Description() {
    if ("" == document.zoom_dataform.Description1.value) {
        if (document.zoom_dataform.Description1.value = zoomup_desc_placeholder, document.zoom_dataform.Description1.className = "c11_p", "searchpl" == searchcheck) return document.getElementById("d1").style.display = "block", document.getElementById("d1").innerHTML = "Kindly Describe Your Requirement.", !1
    } else document.getElementById("d1").style.display = "none";
    return !0
}

function check_Email() {
    if ($("#int_fd_err").removeClass("tdw_err"), "none" == document.getElementById("emailfield_zoom_dataform").style.display) return !0;
    document.zoom_dataform.S_email.value = document.zoom_dataform.S_email.value.replace(/^\s+|\s+$/g, "");
    var e = document.zoom_dataform.S_email.value;
    return null == e || "" == e ? ($("#int_fd_err").addClass("tdw_err"), document.getElementById("e1_pop").style.display = "block", document.getElementById("e1_pop").innerHTML = "Please enter your email.", document.getElementById("e1_pop").innerHTML = "Please enter your email.", !1) : /^[A-z0-9][_.A-z0-9-]+@[a-zA-Z0-9]+[\.\-\_]{0,1}[a-zA-Z0-9]+\.[a-zA-Z]{2,6}\.?[a-zA-Z]{0,4}$/.test(document.zoom_dataform.S_email.value) ? (document.getElementById("e1_pop").style.display = "none", !0) : (document.getElementById("e1_pop").style.display = "block", "Enter your email" == document.zoom_dataform.S_email.value ? document.getElementById("e1_pop").innerHTML = "Please enter your email." : ($("#int_fd_err").addClass("tdw_err"), document.zoom_dataform.S_email.className = "", document.getElementById("e1_pop").innerHTML = "Please enter valid email."), !1)
}

function check_Mobile() {
    document.getElementById("int_fd_err") && $("#int_fd_err").removeClass("tdw_err"), document.getElementById("int_fd_err1") && $("#int_fd_err1").removeClass("tdw_err");
    var e = "";
    if ("IN" != document.getElementById("txtCountry1").value) {
        if (e = /^[0-9]{1,30}$/.test(document.zoom_dataform.S_mobile1.value), "Enter your phone number" == document.zoom_dataform.S_mobile1.value || "" == document.zoom_dataform.S_mobile1.value) return !0;
        if (!e) return document.getElementById("m2").style.display = "block", document.getElementById("m2").innerHTML = "Please enter valid phone number.", $("#int_fd_err1").addClass("tdw_err"), document.zoom_dataform.S_mobile1.className = "", document.zoom_dataform.S_cmobile.className = "cnty_isd", !1
    } else {
        if ("none" == document.getElementById("mobilefield_zoom_dataform").style.display) return !0;
        if ("Enter your mobile" != document.zoom_dataform.S_mobile.value && (document.zoom_dataform.S_mobile.value = document.zoom_dataform.S_mobile.value.replace(/\s+/g, "")), document.zoom_dataform.S_mobile.value = document.zoom_dataform.S_mobile.value.replace(/^0+/, ""), e = "IN" == document.getElementById("txtCountry1").value ? /^((?![2-5])[0-9]{10})$/.test(document.zoom_dataform.S_mobile.value) : /^[0-9]{1,30}$/.test(document.zoom_dataform.S_mobile1.value), "Enter your mobile" == document.zoom_dataform.S_mobile.value || "" == document.zoom_dataform.S_mobile.value) return document.getElementById("m1").style.display = "block", document.getElementById("m1").innerHTML = "Please enter your mobile number.", $("#int_fd_err").addClass("tdw_err"), document.zoom_dataform.S_cmobile.className = "cnty_isd", !1;
        if (!e) return document.getElementById("m1").style.display = "block", document.getElementById("m1").innerHTML = "Please enter valid mobile number.", $("#int_fd_err").addClass("tdw_err"), document.zoom_dataform.S_mobile.className = "", document.zoom_dataform.S_cmobile.className = "cnty_isd", !1;
        document.getElementById("m1").style.display = "none", document.zoom_dataform.S_mobile.className = "", document.zoom_dataform.S_cmobile.className = "cnty_isd"
    }
    return !0
}

function check_Description2() {
    "" == document.zoom_dataform.Description1.value && (document.zoom_dataform.Description1.value = zoomup_desc_placeholder, document.zoom_dataform.Description1.className = "c11_p")
}

function check_Email2() {}

function check_Mobile2() {
    if ("none" == document.getElementById("mobilefield_zoom_dataform").style.display) return !0;
    x = document.zoom_dataform.S_mobile.value, "Enter your mobile" != x && "" != x || $("#S_mobile2").trigger("focus")
}

function check_Fullname2() {
    if ("none" == document.getElementById("fullnamefs").style.display) return !0;
    "Enter your name" != document.zoom_dataform.fullname.value && "" != document.getElementById("fullnamefs").value || (document.getElementById("fullnamefs").value = "Enter your name", document.zoom_dataform.fullname.className = "c11_p")
}

function product_style() {
    "Enter your email" != document.zoom_dataform.S_email.value && (document.zoom_dataform.S_email.className = "")
}

function validate_bind_zoom_popup() {
    var e = document.zoom_dataform.enqform_type.value,
        t = document.zoom_dataform.enqform_cta.value;
    if ("Send_sms_email" == e && "" == document.zoom_dataform.Description.value && (document.zoom_dataform.Description.value = "Send SMS/Email"), null != typeof jQuery) {
        "Enter your mobile" == document.zoom_dataform.S_mobile.value && (document.zoom_dataform.S_mobile.value = ""), "Enter your email" == document.zoom_dataform.S_email.value && (document.zoom_dataform.S_email.value = ""), "Product/Service" == document.zoom_dataform.ss_frm.value && (document.zoom_dataform.ss_frm.value = ""), "Enter your name" == document.zoom_dataform.fullname.value && (document.zoom_dataform.fullname.value = "");
        var o = document.zoom_dataform.S_reference_text.value,
            a = check_Description(),
            m = check_Mobile(),
            n = check_Email(),
            d = check_ss_frm(),
            i = check_Fullname();
        if ("#rcb-product" != trackType && 0 == getIsq && (getIsq = 1, $.getScript("https://tdw.imimg.com/template-tdw/cent_dynamic/dyn_isq/otponly_dyn_isq.js")), 1 == (foreignFlg = checkCntryFlag()) && getMiniDetails(), a && n && m && i && d) {
            $("#int_fd_err").removeClass("tdw_err"), "Enter your name" == document.zoom_dataform.fullname.value && (document.zoom_dataform.fullname.value = ""), "Send_sms_email" != e && (document.zoom_dataform.Description1.value == zoomup_desc_placeholder ? document.zoom_dataform.Description.value = zoomup_desc_value : document.zoom_dataform.Description.value = document.zoom_dataform.Description1.value, "block" == document.getElementById("3pv_desc").style.display && (document.zoom_dataform.Description.value = "Send us quotation & details of " + document.zoom_dataform.ss_frm.value + " products.")), document.zoom_dataform.S_mobile.value == getparamVal1(cookie1, "mb1") && "IN" != document.getElementById("txtCountry1").value && (document.zoom_dataform.S_mobile.value = ""), document.zoom_dataform.S_email.value == getparamVal1(cookie1, "em") && "IN" == document.getElementById("txtCountry1").value && (document.zoom_dataform.S_email.value = ""), "" != document.zoom_dataform.modref_id.value && "undefined" != document.zoom_dataform.modref_id.value || (document.zoom_dataform.modref_id.value = 7857336865, document.zoom_dataform.modref_type.value = 1), document.zoom_dataform.twostep.value = "twostep";
            Selected_product.prd_id;
            return 0 == submitQuery && (o == "#getBestQuote/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#getLatestPrice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetLatestPrice_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#askforprice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "AskForPrice_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#IMInterested/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "IMInterested_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#gbq_video/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#gbq_homepage" == trackType ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#imagezoomup-product" == trackType ? _gaq.push(["b._trackEvent", "Body", "ProductImage_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "Send_sms_email" == e ? _gaq.push(["b._trackEvent", "Body", t + "_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#2pv-zoomup" == trackType || "#auto-zoomup" == trackType ? _gaq.push(["b._trackEvent", "Body", "AutoZoom_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#rcb-product" == trackType && _gaq.push(["b._trackEvent", "Body", "RCB/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), submitQuery = 1, $(".enqload").html("<img  src='https://tdw.imimg.com/template-tdw/loading.gif' alt='Please wait'>"), check_loginmode(), $.post($(".zoom_dataform").attr("action"), $(".zoom_dataform").serialize(), function(a) {
                if ($(".enqload").html(""), "204" == a.error) document.getElementById("int_fd_err") && $("#int_fd_err").addClass("tdw_err"), e1_pop = document.getElementById("e1_pop"), e1_pop.innerHTML = "Kindly choose correct country.", e1_pop.style.display = "block";
                else if ("OK" == a.response) {
                    if (o == "#getBestQuote/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#getLatestPrice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetLatestPrice_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#askforprice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "AskForPrice_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#IMInterested/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "IMInterested_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#gbq_video/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#gbq_homepage" == trackType ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "Send_sms_email" == e ? _gaq.push(["b._trackEvent", "Body", t + "_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#imagezoomup-product" == trackType ? _gaq.push(["b._trackEvent", "Body", "ProductImage_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#2pv-zoomup" != trackType && "#auto-zoomup" != trackType || _gaq.push(["b._trackEvent", "Body", "AutoZoom_S1/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), "block" == document.getElementById("infocus_div").style.display && document.getElementById("thumbnail-containerpop") && "Send_sms_email" != e) {
                        var m = $("#thumbnail-containerpop")[0].childNodes[0].childNodes[0].childNodes[0],
                            n = $("#thumbnail-containerpop")[0].childNodes[0].childNodes[0].childNodes[0].src;
                        m && n && (changeImages("imgBoxPopup", n, m), document.getElementById("showVdoimg").style.display = "none", document.getElementById("showVdoimg1").style.display = "none", document.getElementById("showimg").style.display = "block")
                    }
                    if ($(".error_notification").html("").hide(), $("#dataform_alrt").hide(), "searchpl" != searchcheck) {
                        if ("" != a.queryid)
                            if ("#rcb-product" == trackType) $("#infocus_div").hide(), $("#imgbox").hide(), $("#contInfo").hide(), $("#twostepenquiry").hide(), $("#dataform_alert_display").show(), $("#productform").addClass("tdw_w100"), _gaq.push(["b._trackEvent", "Body", "RCB/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), setTimeout(function() {
                                fg_hideform_zoom()
                            }, 4e3);
                            else {
                                var d = "" != Selected_product.prd_mcatid && null != Selected_product.prd_mcatid ? Selected_product.prd_mcatid : document.zoom_dataform.mcat_id.value;
                                if ($("#form_load").show(), "" === document.getElementById("twostepenquiry").innerHTML) $.ajax({
                                    type: "POST",
                                    url: "/cgi/dyn_isq/twostep_dyn_isq_1.php",
                                    data: {
                                        tmpl_path: PC_CLNT_TMPL_PATH,
                                        switchpr: e
                                    },
                                    success: function(t) {
                                        if ($("#twostepenquiry").html(t), $('input[name="ISQ_DESC"],input[name="ISQ_ID"],input[name="OPTION_DESC"],input[name="OPTION_ID"],input[name="mcatid"]').val(""), $('input[name="mcatid"]').val(d), $("#isq_fields").html(""), "Send_sms_email" != e)
                                            if ($("#form_head").html("Adding a few details of your requirement can get you quick response from the supplier"), null != dyn_isq_obj[d] && "" != dyn_isq_obj[d]) {
                                                var o = dyn_isq_obj[d];
                                                localStorage.setItem("ISQ", JSON.stringify(o)), cons_isq_fields(), "function" == typeof im_getCookieValues && im_getCookieValues("twostep_dataform", ZoomElementNamesHash_two), twostep_show(a)
                                            } else $.ajax({
                                                type: "POST",
                                                url: "/cgi/dyn_isq/get_dyn_isq_1.php",
                                                data: {
                                                    tmpl_path: PC_CLNT_TMPL_PATH,
                                                    mcatid: d,
                                                    foreign_flag: foreignFlg
                                                },
                                                success: function(e) {
                                                    var t = e,
                                                        o = t.indexOf("{"),
                                                        m = t.lastIndexOf("}") + 1;
                                                    t = t.slice(o, m), localStorage.setItem("ISQ", t), t = JSON.parse(t), "" != d && null != d && (dyn_isq_obj[d] = t), cons_isq_fields(), "function" == typeof im_getCookieValues && im_getCookieValues("twostep_dataform", ZoomElementNamesHash_two), twostep_show(a)
                                                }
                                            });
                                        else twostep_show(a)
                                    }
                                });
                                else if ($('input[name="ISQ_DESC"],input[name="ISQ_ID"],input[name="OPTION_DESC"],input[name="OPTION_ID"],input[name="mcatid"]').val(""), $('input[name="mcatid"]').val(d), $("#isq_fields").html(""), "Send_sms_email" != e)
                                    if ($("#form_head").html("Adding a few details of your requirement can get you quick response from the supplier"), null != dyn_isq_obj[d] && "" != dyn_isq_obj[d]) {
                                        var i = dyn_isq_obj[d];
                                        localStorage.setItem("ISQ", JSON.stringify(i)), cons_isq_fields(), twostep_show(a)
                                    } else $.ajax({
                                        type: "POST",
                                        url: "/cgi/dyn_isq/get_dyn_isq_1.php",
                                        data: {
                                            tmpl_path: PC_CLNT_TMPL_PATH,
                                            mcatid: d,
                                            foreign_flag: foreignFlg
                                        },
                                        success: function(e) {
                                            var t = e,
                                                o = t.indexOf("{"),
                                                m = t.lastIndexOf("}") + 1;
                                            t = t.slice(o, m), localStorage.setItem("ISQ", t), t = JSON.parse(t), "" != d && null != d && (dyn_isq_obj[d] = t), cons_isq_fields(), twostep_show(a)
                                        }
                                    });
                                else twostep_show(a)
                            }
                        else $("#infocus_div").hide(), $("#imgbox").hide(), $("#twostepenquiry").hide(), $("#closebtn").hide(), $("#contInfo").hide(), $("#dataform_alert_display").show(), setTimeout(function() {
                            fg_hideform_zoom()
                        }, 4e3);
                        Selected_product.prd_name = ""
                    } else $("#dataform_alert_display_search").show();
                    $("#ffc_blow_up").removeClass("imgforms");
                    for (var _ = document.getElementsByClassName("prd_f"), r = document.getElementsByClassName("prd_f_imgform"), s = 0; s < _.length; s++) _[s].style.display = "block";
                    for (s = 0; s < r.length; s++) r[s].style.display = "none"
                } else msg = "* Some error has occured while submitting enquiry.Please try again!!!", $(".error_notification").html(msg).show();
                return submitQuery = 0, !1
            }, "json")), !1
        }
        return o == "#getBestQuote/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#getLatestPrice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetLatestPrice_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#askforprice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "AskForPrice_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#gbq_video/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#gbq_homepage" == trackType ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : o == "#IMInterested/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "IMInterested_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#imagezoomup-product" == trackType ? _gaq.push(["b._trackEvent", "Body", "ProductImage_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "Send_sms_email" == e ? _gaq.push(["b._trackEvent", "Body", t + "_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#2pv-zoomup" == trackType || "#auto-zoomup" == trackType ? _gaq.push(["b._trackEvent", "Body", "AutoZoom_S1/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : "#rcb-product" == trackType && _gaq.push(["b._trackEvent", "Body", "RCB/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]), 0 == a ? $("#Description1").trigger("focus") : 0 == d ? $("#ss_frm").trigger("focus") : 0 == n ? ($("#S_email").trigger("focus"), $("#int_fd_err").addClass("tdw_err")) : 0 == m ? ($("#S_mobile2").trigger("focus"), $("#int_fd_err").addClass("tdw_err")) : 0 == i && $("#fullname").trigger("focus"), !1
    }
    return !1
}

function loadFormcss() {
    var e = document.createElement("link");
    e.href = central_path + "cent_dynamic/dyn_isq/enqforms_dyn_isq2_min.css", e.type = "text/css", e.rel = "stylesheet", $("head").append(e), window.clk = 1
}

function check_loginmode() {
    "" != im_readCookie("v4iilex") && "" != im_readCookie("ImeshVisitor") ? $("#usr_login_mode").val(1) : "" != im_readCookie("ImeshVisitor") ? $("#usr_login_mode").val(2) : $("#usr_login_mode").val(3)
}

function check_loginmode_fooetrprd() {
    "" != im_readCookie("v4iilex") && "" != im_readCookie("ImeshVisitor") ? $("#usr_login_mode_footerprd").val(1) : "" != im_readCookie("ImeshVisitor") ? $("#usr_login_mode_footerprd").val(2) : $("#usr_login_mode_footerprd").val(3)
}
var Selected_product = new Array;

function zoom_up_img(e, t, o, a, m) {
    Selected_product.prd_id = t, Selected_product.prd_code = o, Selected_product.prd_name = a, Selected_product.prd_img = m, imgset_zoom(e, "dataref")
}

function clearValue() {
    document.zoom_dataform && (document.zoom_dataform.Description.value = "")
}

function check_country_flag() {
    $("#m1").hide(), $("#m2").hide(), $("#e1_pop").hide(), $("#int_fd_err").removeClass("tdw_err");
    var prefix = popupopen;
    null != document.getElementById("mobile-number_" + prefix) && ("+91" != document.getElementById("mobile-number_" + prefix).value ? (document.getElementById("mobilefield_" + prefix).style.display = "none", "zoom_dataform" == prefix ? document.getElementById("m1").style.display = "none" : "zoom_dataform_sms" == prefix && (document.getElementById("m_s").style.display = "none"), document.getElementById("emailfield_" + prefix).style.display = "block", document.getElementById("int_fd_err1") && (document.getElementById("int_fd_err1").style.display = "block"), "zoom_dataform" == prefix ? (eval("document." + prefix + ".S_email").value = "", "Enter your email" == eval("document." + prefix + ".S_email").value && $("#S_email").trigger("focus")) : "zoom_dataform_sms" == prefix && (null != document.getElementById("flname_sms") && "none" == document.getElementById("flname_sms").style.display && (document.getElementById("flname_sms").style.display = "block"), eval("document." + prefix + ".S_email_ask").value = "Enter your email", eval("document." + prefix + ".S_email_ask").classList.add("c11_p"), eval("document." + prefix + ".fullname_smspopup").value = "Enter your name", eval("document." + prefix + ".fullname_smspopup").classList.add("c11_p")), $("#mobile-number_" + prefix).addClass("off_p"), "" == eval("document." + prefix + ".S_email").value && PC_CLNT_TMPL_PATH, eval("document." + prefix + ".S_mobile").value = "", "zoom_dataform" == prefix && (document.getElementById("S_name_zoom_dataform").style.display = "block", eval("document." + prefix + ".fullnamefs").value = "Enter your name", eval("document." + prefix + ".fullnamefs").classList.add("c11_p")), "twostep_dataform" == prefix && (document.twostep_dataform.S_mobile.value = ""), $("#ipt_fld_head").html("Email ID"), $("#tnkMsg").html("We will contact you on this email")) : (document.getElementById("mobilefield_" + prefix).style.display = "block", document.getElementById("emailfield_" + prefix).style.display = "none", document.getElementById("int_fd_err1") && (document.getElementById("int_fd_err1").style.display = "none"), "zoom_dataform" == prefix ? (document.getElementById("e1_pop").style.display = "none", document.getElementById("f1").style.display = "none", "Enter your mobile" != eval("document." + prefix + ".S_mobile2").value && "" != eval("document." + prefix + ".S_mobile2").value || $("#S_mobile2").trigger("focus")) : "zoom_dataform_sms" == prefix && (document.getElementById("e1").style.display = "none", document.getElementById("f_s").style.display = "none", eval("document." + prefix + ".fullname_smspopup").value = "Enter your name", eval("document." + prefix + ".fullname_smspopup").classList.add("c11_p"), eval("document." + prefix + ".S_mobile3").value = "Enter your mobile", eval("document." + prefix + ".S_mobile3").classList.add("c11_p")), $("#mobile-number_" + prefix).removeClass("off_p"), "" == eval("document." + prefix + ".S_mobile").value && PC_CLNT_TMPL_PATH, eval("document." + prefix + ".S_email").value = "", "zoom_dataform" == prefix && (document.getElementById("S_name_zoom_dataform").style.display = "none"), "twostep_dataform" == prefix && (document.twostep_dataform.S_email.value = ""), $("#ipt_fld_head").html("Mobile Number"), $("#tnkMsg").html("We will contact you on this number"))), null != document.getElementsByClassName("cnty_iso")[0] && $(".cnty_iso").trigger("onchange")
}

function get_ip() {
    "" == im_readCookie("iploc") ? $.get("/cgi/getIp.php", function(e) {
        "" == im_readCookie("ImeshVisitor") && fillck()
    }, "json") : "" == im_readCookie("ImeshVisitor") && "" != im_readCookie("iploc") && fillck()
}

function fillck() {
    "" != im_readCookie("iploc") && (scountry = getparamVal1(getCartCookie("iploc"), "gcnnm").replace(/\+/g, " "), sphonecode = scmob = getparamVal1(getCartCookie("iploc"), "gcode"), countryiso = contry = getparamVal1(getCartCookie("iploc"), "gcniso"), "undefined" != typeof sync_country_flag ? sync_country_flag(sphonecode, countryiso, scountry) : setTimeout(function() {
        sync_country_flag(sphonecode, countryiso, scountry)
    }, 1e3))
}

function check_ss_frm() {
    return "none" == document.getElementById("3pv_desc").style.display || ("" == document.zoom_dataform.ss_frm.value ? (document.zoom_dataform.ss_frm.value = "Product/Service", document.zoom_dataform.ss_frm.classList.add("c11_p"), document.getElementById("s1").style.display = "block", document.getElementById("s1").innerHTML = "Kindly Describe Your Requirement.", !1) : (document.getElementById("s1").style.display = "none", !0))
}

function hide_validation() {
    $(".inline_dataform").each(function() {
        this.getElementsByClassName("error_inln_frm")[0].style.display = "none", this.getElementsByClassName("error_inln_frm")[1].style.display = "none", "IN" != document.getElementById("country_iso_in").value ? "Enter your email" == this.getElementsByClassName("e_inline inp_inline")[0].value ? this.getElementsByClassName("e_inline inp_inline")[0].style.color = "#bcc7cf" : this.getElementsByClassName("e_inline inp_inline")[0].style.color = "#20272c" : "Enter your mobile" == this.getElementsByClassName("m_inline inp_inline")[0].value ? this.getElementsByClassName("m_inline inp_inline")[0].style.color = "#bcc7cf" : this.getElementsByClassName("m_inline inp_inline")[0].style.color = "#20272c"
    })
}

function check_ss_frm2() {
    if ("none" == document.getElementById("3pv_desc").style.display) return !0;
    "" == document.zoom_dataform.ss_frm.value && (document.zoom_dataform.ss_frm.value = "Product/Service", document.zoom_dataform.ss_frm.classList.add("c11_p"))
}

function searchClear_frm() {
    "Product/Service" == document.zoom_dataform.ss_frm.value && (document.zoom_dataform.ss_frm.value = "", $("#ss_frm").removeClass("c11_p"), document.getElementById("s1").style.display = "none")
}

function on_formvideo_mouseover(e) {
    "vdo" == e ? ($("#showVdoimg1").show(), $("#showVdoimg").show(), $("#showimg").hide()) : ($("#showimg").show(), $("#showVdoimg").hide(), $("#showVdoimg1").hide())
}

function getMiniDetails() {
    var e = "";
    (cookie1 = getCartCookie("ImeshVisitor")) > "" && "" != getparamVal1(cookie1, "glid") && (e = getparamVal1(cookie1, "glid")), void 0 !== e && "" != e && $.ajax({
        type: "POST",
        url: "/cgi/dyn_isq/miniDetails.php",
        data: {
            s_glusrid: e
        },
        success: function(e) {
            var t = JSON.parse(e);
            void 0 !== t.Response.Data.glusr_usr_companyname && "" != t.Response.Data.glusr_usr_companyname && (usrCompName = "Is Present"), void 0 !== t.Response.Data.IS_URL_AVAILABLE && 1 == t.Response.Data.IS_URL_AVAILABLE && (usrWeb = "Is Present")
        }
    })
}