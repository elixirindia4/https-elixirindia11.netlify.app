var isFirefox = typeof InstallTrigger !== "undefined";
if (PC_CLNT_TMPL_PATH == "d0055" || PC_CLNT_TMPL_PATH == "d0056" || PC_CLNT_TMPL_PATH == "d0057") {
    if (isFirefox) {
        if (window.location.pathname != "/") {
            var a = document.referrer;
            var homeurl = window.location.protocol + "//" + window.location.hostname + "/";
            if ((a == "" || a.indexOf(homeurl) == -1) && (window.performance.navigation.type == 0)) {
                history.pushState("", "", window.location.href)
            }
            window.onpopstate = function() {
                if ((a == "" || a.indexOf(homeurl) == -1) && history.state != "") {
                    history.replaceState("", "", homeurl);
                    window.location.replace(homeurl)
                }
            }
        }
    } else {
        if (window.location.pathname != "/") {
            var a = document.referrer;
            var homeurl = window.location.protocol + "//" + window.location.hostname + "/";
            if ((a == "" || a.indexOf(homeurl) == -1) && (window.performance.navigation.type == 0)) {
                history.pushState("", "", window.location.href)
            }
            window.onpopstate = function() {
                if ((a == "" || a.indexOf(homeurl) == -1) && history.state != "") {
                    window.location.replace(homeurl)
                }
            }
        }
    }
} else {
    if (isFirefox) {
        if (window.location.pathname != "/") {
            var a = document.referrer;
            var homeurl = window.location.protocol + "//" + window.location.hostname + "/";
            if ((a == "" || a.indexOf(homeurl) == -1) && (window.performance.navigation.type == 0) && location.href.indexOf("#") == -1) {
                history.pushState("", "", window.location.href)
            }
            window.onpopstate = function() {
                if (location.href.indexOf("#") == -1 && (a == "" || a.indexOf(homeurl) == -1) && history.state != "") {
                    history.replaceState("", "", homeurl);
                    window.location.replace(homeurl)
                }
            }
        }
    } else {
        if (window.location.pathname != "/") {
            var a = document.referrer;
            var homeurl = window.location.protocol + "//" + window.location.hostname + "/";
            if ((a == "" || a.indexOf(homeurl) == -1) && (window.performance.navigation.type == 0) && location.href.indexOf("#") == -1) {
                history.pushState("", "", window.location.href)
            }
            window.onpopstate = function() {
                if (location.href.indexOf("#") == -1 && (a == "" || a.indexOf(homeurl) == -1) && history.state != "") {
                    window.location.replace(homeurl)
                }
            }
        }
    }
}

function getCartCookie(b) {
    var c = b + "=";
    if (document.cookie.length > 0) {
        offset = document.cookie.indexOf(c);
        if (offset != -1) {
            offset += c.length;
            end = document.cookie.indexOf(";", offset);
            if (end == -1) {
                end = document.cookie.length
            }
            return unescape(document.cookie.substring(offset, end))
        }
    }
    return ""
}

function getparamVal1(b, c) {
    if (b > "") {
        var e = "|" + b + "|";
        var d = new RegExp(".*?\\|" + c + "=([^|]*).*|.*");
        return e.replace(d, "$1")
    } else {
        return ""
    }
}

function sync_all_form() {
    $("form").each(function() {
        if (this.name != "frm") {
            inlinename = this.name;
            if ((cookie1 = getCartCookie("ImeshVisitor")) > "") {
                var c = im_getparamVal(cookie1, "phcc");
                var d = im_getparamVal(cookie1, "iso").toLowerCase();
                var b = $(".country-list").find("li[data-country-code=" + d + "_ctry]").find("span").html();
                sync_country_flag(c, d, b);
                var e = new im_elementHash("S_name", "S_name", "S_lname", "S_lname", "S_email", "S_email", "S_cmobile", "S_cmobile", "S_phone_country_code", "S_phone_country_code", "S_country", "S_country", "country", "country", "S_mobile", "S_mobile", "S_fullname", "fullname", "S_glusr_id", "S_glusr_id");
                im_getCookieValues(inlinename, e);
                if (typeof(document.footerprd_dataform) != "undefined" && inlinename == "footerprd_dataform") {
                    if (getparamVal1(cookie1, "phcc") != "91" && typeof open_email == "function") {
                        open_email()
                    }
                }
            }
        }
    });
    hide_validation()
}

function getparamVal1(b, c) {
    if (b > "") {
        var e = "|" + b + "|";
        var d = new RegExp(".*?\\|" + c + "=([^|]*).*|.*");
        return e.replace(d, "$1")
    } else {
        return ""
    }
};