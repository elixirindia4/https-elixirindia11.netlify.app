var count_no_clicks = 0,
    prev_head_val = $("#form_head").html();

function cons_isq_fields() {
    var e = localStorage.getItem("ISQ");
    e = JSON.parse(e);
    $("#form_head").html();
    var t = document.getElementById("isq_fields");
    if (document.getElementById("twostepenquiry").style.paddingTop = "0px", $(".tdw_qnt_err").hide(), "200" == e.CODE && null != e.DATA) {
        var a = {};
        if (null != localStorage.getItem("Isq_set_prop") && null != localStorage.getItem("Isq_set_prop"))
            for (var n = JSON.parse(localStorage.getItem("Isq_set_prop")), s = 0; s < n.length; s++) val_isq_prop = n[s].FK_IM_SPEC_MASTER_DESC, val_isq_desc = n[s].SUPPLIER_RESPONSE_DETAIL, a[val_isq_prop] = val_isq_desc;
        for (s = 0; s < e.DATA.length; s++) {
            if (s % 3 == 0)(m = document.createElement("div")).setAttribute("id", "isq" + s / 3), t.appendChild(m);
            if (null != e.DATA[s].IM_SPEC_MASTER_DESC && "" != e.DATA[s].IM_SPEC_MASTER_DESC) {
                if ((d = document.createElement("label")).textContent = e.DATA[s].IM_SPEC_MASTER_DESC + ": ", d.setAttribute("class", "tdw_db"), document.getElementById("isq" + parseInt(s / 3)).appendChild(d), null != e.DATA[s].IM_SPEC_OPTIONS_DESC && "" != e.DATA[s].IM_SPEC_OPTIONS_DESC && null != e.DATA[s].IM_SPEC_MASTER_TYPE && "" != e.DATA[s].IM_SPEC_MASTER_TYPE) switch (e.DATA[s].IM_SPEC_MASTER_TYPE) {
                    case "1":
                        createTextInput(e.DATA[s].IM_SPEC_MASTER_DESC, e.DATA[s].IM_SPEC_MASTER_ID, e.DATA[s].IM_SPEC_OPTIONS_ID, parseInt(s / 3), a);
                        break;
                    case "2":
                        createRadioInput(e.DATA[s].IM_SPEC_MASTER_DESC, e.DATA[s].IM_SPEC_MASTER_ID, e.DATA[s].IM_SPEC_OPTIONS_DESC, e.DATA[s].IM_SPEC_OPTIONS_ID, parseInt(s / 3), a);
                        break;
                    case "3":
                        createSelectInput(e.DATA[s].IM_SPEC_MASTER_DESC, e.DATA[s].IM_SPEC_MASTER_ID, e.DATA[s].IM_SPEC_OPTIONS_DESC, e.DATA[s].IM_SPEC_OPTIONS_ID, parseInt(s / 3), a);
                        break;
                    case "4":
                        createCheckboxInput(e.DATA[s].IM_SPEC_MASTER_DESC, e.DATA[s].IM_SPEC_MASTER_ID, e.DATA[s].IM_SPEC_OPTIONS_DESC, e.DATA[s].IM_SPEC_OPTIONS_ID, parseInt(s / 3), a)
                }
            } else if (e.DATA[s].length > 0)
                for (var o = 0; o < e.DATA[s].length; o++)
                    if (null != e.DATA[s][o].IM_SPEC_MASTER_DESC && "" != e.DATA[s][o].IM_SPEC_MASTER_DESC) {
                        if ("Quantity Unit" != e.DATA[s][o].IM_SPEC_MASTER_DESC) {
                            if ("Quantity" == e.DATA[s][o].IM_SPEC_MASTER_DESC) {
                                var l = document.createElement("div");
                                l.textContent = "Quantity must be numeric", l.setAttribute("class", "tdw_qnt_err tdw_pp_fs14"), l.setAttribute("style", "display: none;color:#f35252"), document.getElementById("isq" + parseInt(s / 3)).appendChild(l)
                            }
                            var d;
                            (d = document.createElement("label")).textContent = e.DATA[s][o].IM_SPEC_MASTER_DESC + ": ", d.setAttribute("class", "tdw_db"), document.getElementById("isq" + parseInt(s / 3)).appendChild(d)
                        }
                        if (null != e.DATA[s][o].IM_SPEC_OPTIONS_DESC && "" != e.DATA[s][o].IM_SPEC_OPTIONS_DESC && null != e.DATA[s][o].IM_SPEC_MASTER_TYPE && "" != e.DATA[s][o].IM_SPEC_MASTER_TYPE) switch (e.DATA[s][o].IM_SPEC_MASTER_TYPE) {
                            case "1":
                                createTextInput(e.DATA[s][o].IM_SPEC_MASTER_DESC, e.DATA[s][o].IM_SPEC_MASTER_ID, e.DATA[s][o].IM_SPEC_OPTIONS_ID, parseInt(s / 3), a);
                                break;
                            case "2":
                                createRadioInput(e.DATA[s][o].IM_SPEC_MASTER_DESC, e.DATA[s][o].IM_SPEC_MASTER_ID, e.DATA[s][o].IM_SPEC_OPTIONS_DESC, e.DATA[s][o].IM_SPEC_OPTIONS_ID, parseInt(s / 3), a);
                                break;
                            case "3":
                                createSelectInput(e.DATA[s][o].IM_SPEC_MASTER_DESC, e.DATA[s][o].IM_SPEC_MASTER_ID, e.DATA[s][o].IM_SPEC_OPTIONS_DESC, e.DATA[s][o].IM_SPEC_OPTIONS_ID, parseInt(s / 3), a);
                                break;
                            case "4":
                                createCheckboxInput(e.DATA[s][o].IM_SPEC_MASTER_DESC, e.DATA[s][o].IM_SPEC_MASTER_ID, e.DATA[s][o].IM_SPEC_OPTIONS_DESC, e.DATA[s][o].IM_SPEC_OPTIONS_ID, parseInt(s / 3), a)
                        }
                    }
        }
        if (e.DATA.length % 3 == 0)(m = document.createElement("div")).setAttribute("id", "isq" + s / 3), m.innerHTML = '<div id="ext_des_div" class="tdw_ext_des tdw_w390" data-role=""><label class="tdw_db">Requirement Details: </label><textarea class="c11_p" name="usage" id="Descriptiontwostep" tabindex="19" style="min-height: 70px;margin-top: 10px;" placeholder="Describe your requirement in detail:" onfocus="javascript:twostepusage_focus(this);" onblur="javascript:twostepusage();"></textarea></div>', t.appendChild(m), document.getElementById("isq" + s / 3).style.display = "none";
        else document.getElementById("isq" + parseInt(s / 3)).innerHTML += '<div id="ext_des_div" class="tdw_ext_des tdw_w390" data-role=""><label class="tdw_db">Requirement Details: </label><textarea class="c11_p" name="usage" id="Descriptiontwostep" tabindex="19" style="min-height: 70px;margin-top: 10px;" placeholder="Describe your requirement in detail:" onfocus="javascript:twostepusage_focus(this);" onblur="javascript:twostepusage();"></textarea></div>';
        count_no_clicks = 0;
        var _ = e.DATA.length + 1,
            u = _ % 3 == 0 ? parseInt(_ / 3) : parseInt(_ / 3) + 1;
        document.getElementById("isq0").style.display = "block";
        for (var i = 1; i < u; i++) document.getElementById("isq" + i).style.display = "none";
        0 == count_no_clicks && (document.getElementById("prev_btn").style.display = "none"), document.getElementById("secstepsub").innerHTML = _ <= 3 ? "Submit" : "Next", $(".tdw_pp_rbs .tdw_pp_ai.tdw_pp_df").click(function() {
            var e = this.childNodes[0].name;
            if ("radio" == this.childNodes[0].type && $('input:text[name="' + e + '"]').val(""), "text" != this.childNodes[0].type)
                if ("true" == this.childNodes[0].waschecked) this.childNodes[0].checked = !1, $(this).css("border-color", ""), this.childNodes[0].waschecked = "false";
                else {
                    e = this.childNodes[0].name;
                    $('input:radio[name="' + e + '"]').parent().each(function() {
                        $(this).css("border-color", ""), this.childNodes[0].checked = !1, this.childNodes[0].waschecked = "false"
                    }), this.childNodes[0].checked = !0, $(this).css("border-color", "#2f3292"), this.childNodes[0].waschecked = "true"
                }
            else $('input:radio[name="' + e + '"]').each(function() {
                $(this).prop("checked", !1), $(this).prop("waschecked", "false"), $(this).parent().css("border-color", "")
            })
        }), $(".isq_qunt").on("input", function(e) {
            var t = $(this).val();
            $.isNumeric(t) || "" == t ? ($(".tdw_qnt_err").hide(), $(".isq_qunt").css("border-color", "")) : ($(".tdw_qnt_err").show(), $(".isq_qunt").css("border-color", "#f35252"))
        }), $(".isq_qunt").on("click", function(e) {
            $(".tdw_qnt_err").hide()
        })
    } else {
        var m;
        (m = document.createElement("div")).setAttribute("id", "isq0"), m.innerHTML = '<div id="ext_des_div" class="tdw_ext_des tdw_w390" data-role=""><label class="tdw_db">Requirement Details: </label><textarea class="c11_p" name="usage" id="Descriptiontwostep" tabindex="19" style="min-height: 70px;margin-top: 10px;" placeholder="Describe your requirement in detail:" onfocus="javascript:twostepusage_focus(this);" onblur="javascript:twostepusage();"></textarea></div>', t.appendChild(m), document.getElementById("isq0").style.display = "block", document.getElementById("prev_btn").style.display = "none"
    }
}

function btn_onclick() {
    var e = localStorage.getItem("ISQ");
    e = JSON.parse(e);
    var t = document.getElementById("enqform_type").value;
    if ($("#fill_per_dtl").is(":visible")) {
        _gaq.push(["b._trackEvent", "Body", "per_details/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]);
        var a = check_Fullname_twostep(),
            n = check_Email_twostep(),
            s = check_Moblie_twostep();
        a && n && s ? (document.getElementById("fill_per_dtl").style.display = "none", count_no_clicks = 0, "Send_sms_email" == t ? (document.getElementById("non_prd_desc").style.display = "block", document.getElementById("form_head").innerHTML = "Send a quick message to the seller for more information.", $("#non_prd_desc").html('<label class="tdw_db">Write your message here:</label><textarea class="c11_p" name="usage" id="Descriptiontwostep" tabindex="19" style="min-height: 70px;margin-top: 10px;" placeholder="Describe your requirement in detail:" onfocus="javascript:twostepusage_focus(this);" onblur="javascript:twostepusage();"></textarea><span id="d_s2" class="error_notification2" style="display: none;">Kindly describe your requirement.</span>')) : "200" == e.CODE && null != e.DATA ? (document.getElementById("dyn_isq_dtl").style.display = "block", document.getElementById("form_head").innerHTML = "Adding a few details of your requirement can get you quick response from the supplier", e.DATA.length <= 3 ? document.getElementById("secstepsub").innerHTML = "Submit" : document.getElementById("secstepsub").innerHTML = "Next", document.getElementById("isq0").style.display = "block") : (document.getElementById("dyn_isq_dtl").style.display = "block", document.getElementById("form_head").innerHTML = "Adding a few details of your requirement can get you quick response from the supplier", document.getElementById("secstepsub").innerHTML = "Submit", document.getElementById("isq0").style.display = "block", document.getElementById("prev_btn").style.display = "none")) : 0 == a ? $("#fullname").trigger("focus") : 0 == s ? $("#S_mob_twostep").trigger("focus") : 0 == n && $("#S_email_twostep").trigger("focus")
    } else {
        if ("Send_sms_email" != t) {
            if (null != $("#isq_fields").children("div") && $("#isq_fields").children("div").each(function() {
                    "block" == this.style.display && _gaq.push(["b._trackEvent", "Body", this.id + "/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH])
                }), check_qunt_isq())
                if ("200" == e.CODE && null != e.DATA) {
                    count_no_clicks++;
                    var o = e.DATA.length + 1,
                        l = o % 3 == 0 ? parseInt(o / 3) : parseInt(o / 3) + 1;
                    if ("Submit" == document.getElementById("secstepsub").innerHTML) fillOpt_det(), validate_twostep_popup();
                    else if (l > count_no_clicks + 1) {
                        prev_head_val = $("#form_head").html(), document.getElementById("prev_btn").style.display = "block", document.getElementById("secstepsub").innerHTML = "Next";
                        var d = count_no_clicks - 1;
                        document.getElementById("isq" + count_no_clicks).style.display = "block", document.getElementById("isq" + d).style.display = "none"
                    } else if (l == count_no_clicks + 1) {
                        document.getElementById("prev_btn").style.display = "block", document.getElementById("secstepsub").innerHTML = "Submit", prev_head_val = $("#form_head").html(), document.getElementById("form_head").innerHTML = "Almost done!";
                        d = count_no_clicks - 1;
                        document.getElementById("isq" + count_no_clicks).style.display = "block", document.getElementById("isq" + d).style.display = "none"
                    }
                } else validate_twostep_popup()
        } else validate_twostep_popup()
    }
}

function prev_div() {
    document.getElementById("form_head").innerHTML = prev_head_val, document.getElementById("isq" + count_no_clicks).style.display = "none", document.getElementById("secstepsub").innerHTML = "Next", count_no_clicks--, document.getElementById("isq" + count_no_clicks).style.display = "block", 0 == count_no_clicks && (document.getElementById("prev_btn").style.display = "none")
}

function check_qunt_isq() {
    if ($(".isq_qunt").length) {
        var e = $(".isq_qunt").val();
        return !(!$.isNumeric(e) && "" != e)
    }
    return !0
}

function createTextInput(e, t, a, n, s) {
    var o = document.createElement("input");
    o.setAttribute("type", "text"), o.setAttribute("class", "tdw_pp_rbs tdw_pp_fs14"), o.setAttribute("name", e), o.setAttribute("id", a), o.setAttribute("masterDesc", e), o.setAttribute("masterID", t), "Quantity" == e && o.setAttribute("class", "tdw_pp_rbs isq_qunt tdw_pp_fs14"), null != s[e] && "" != s[e] && o.setAttribute("value", s[e]), "Quantity" == e && $("#isq_imgf input").val() && o.setAttribute("value", $("#isq_imgf input").val()), document.getElementById("isq" + n).appendChild(o)
}

function createRadioInput(e, t, a, n, s, o) {
    var l = document.createElement("div");
    l.setAttribute("class", "tdw_pp_ai tdw_pp_rbs tdw_pp_df tdw_pp_cp");
    for (var d = 0, _ = a.split("##"), u = n.split("##"), i = 0; i < _.length; i++) {
        var m = document.createElement("div"),
            r = document.createElement("input");
        if ("OTHERS" == _[i].toUpperCase() || "OTHER" == _[i].toUpperCase() ? (m.setAttribute("class", "tdw_pp_ai tdw_pp_df tdw_other_opt"), r.setAttribute("type", "text"), r.setAttribute("opt_type", "other"), r.setAttribute("placeholder", "Other Option"), null != o[e] && 0 == d && r.setAttribute("value", o[e])) : (m.setAttribute("class", "tdw_pp_ai tdw_pp_df"), r.setAttribute("value", _[i]), r.setAttribute("type", "radio"), r.setAttribute("waschecked", "false")), r.setAttribute("name", e), r.setAttribute("id", u[i]), r.setAttribute("masterDesc", e), r.setAttribute("masterID", t), null != o[e] && o[e] == _[i] && (r.setAttribute("checked", !0), r.setAttribute("waschecked", "false"), d = 1, m.setAttribute("style", "border-color:#2f3292")), m.appendChild(r), "OTHERS" != _[i].toUpperCase() && "OTHER" != _[i].toUpperCase()) {
            var c = document.createElement("label");
            c.setAttribute("for", _[i]), c.textContent = _[i] + " ", m.appendChild(c)
        }
        l.appendChild(m)
    }
    document.getElementById("isq" + s).appendChild(l)
}

function createSelectInput(e, t, a, n, s, o) {
    var l = a.split("##"),
        d = n.split("##"),
        _ = document.createElement("select"),
        u = "";
    (_.setAttribute("class", "tdw_pp_qstn tdw_pp_mb10 tdw_pp_fs14"), _.setAttribute("style", "color:#777;"), _.setAttribute("name", e), _.setAttribute("onChange", "changeSelectField(this)"), "Quantity Unit" == e) ? (_.setAttribute("class", "tdw_pp_qstn tdw_pp_mb10 tdw_pp_fs14 isq_quntu"), _.setAttribute("style", "")) : ((m = document.createElement("option")).setAttribute("value", "Select a value"), m.textContent = "Select a value", m.setAttribute("class", "tdw_pp_clr1"), _.appendChild(m));
    for (var i = 0; i < l.length; i++) {
        var m;
        (m = document.createElement("option")).setAttribute("id", d[i]), m.setAttribute("masterDesc", e), m.setAttribute("masterID", t), m.setAttribute("value", l[i]), m.setAttribute("class", "tdw_clr1"), "Quantity Unit" == e && ($("#isq_imgf select").val() && l[i] == $("#isq_imgf select").val() && m.setAttribute("selected", !0), "OTHER" == l[i].toUpperCase() && ((u = document.createElement("input")).setAttribute("name", e), u.setAttribute("style", "display:none;height:35px"), u.setAttribute("class", "isq_quntu"), u.setAttribute("placeholder", "Enter custom unit"), u.setAttribute("id", d[i]), u.setAttribute("masterDesc", e), u.setAttribute("masterID", t), u.setAttribute("onblur", "inp_sel_blr(this)"), u.setAttribute("disabled", ""), u.setAttribute("autocomplete", "off"))), m.textContent = l[i], _.appendChild(m)
    }
    "Quantity Unit" == e && $("#cust_qunt_val").val() && null != $("#cust_qunt_val").val() && "" != $("#cust_qunt_val").val() && (_.setAttribute("disabled", !0), _.setAttribute("style", "display:none;"), u.removeAttribute("disabled"), u.setAttribute("style", "display:inline;height:35px"), u.setAttribute("value", $("#cust_qunt_val").val())), document.getElementById("isq" + s).appendChild(_), "" != u && document.getElementById("isq" + s).appendChild(u)
}

function changeSelectField(e) {
    "Quantity Unit" != e.name && "Qunt_Unt_imgf" != e.name ? 0 == e.selectedIndex ? e.style.color = "#777" : e.style.color = "#111" : "Other" == e.options[e.selectedIndex].value && (toggleField(e, e.nextSibling), e.selectedIndex = "0")
}

function inp_sel_blr(e) {
    "" == e.value && toggleField(e, e.previousSibling)
}

function toggleField(e, t) {
    e.disabled = !0, e.style.display = "none", t.disabled = !1, t.style.display = "inline", t.focus()
}

function createCheckboxInput(e, t, a, n, s, o) {
    var l = document.createElement("div");
    l.setAttribute("class", "tdw_pp_ai tdw_pp_rbs tdw_pp_df");
    for (var d = 0, _ = a.split("##"), u = n.split("##"), i = 0; i < _.length; i++) {
        var m = document.createElement("div"),
            r = document.createElement("input");
        if ("OTHERS" == _[i].toUpperCase() || "OTHER" == _[i].toUpperCase() ? (m.setAttribute("class", "tdw_pp_ai tdw_pp_df tdw_other_opt"), r.setAttribute("type", "text"), r.setAttribute("placeholder", "Other Option"), null != o[e] && 0 == d && r.setAttribute("value", o[e])) : (m.setAttribute("class", "tdw_pp_ai tdw_pp_df tdw_checkb tdw_pp_cp"), r.setAttribute("value", _[i]), r.setAttribute("type", "checkbox")), r.setAttribute("name", e), r.setAttribute("masterDesc", e), r.setAttribute("masterID", t), r.setAttribute("id", u[i]), null != o[e] && o[e] == _[i] && (r.setAttribute("checked", !0), d = 1, m.setAttribute("style", "border-color:#2f3292")), m.appendChild(r), "OTHERS" != _[i].toUpperCase() && "OTHER" != _[i].toUpperCase()) {
            var c = document.createElement("label");
            c.setAttribute("for", _[i]), c.textContent = _[i] + " ", m.appendChild(c)
        }
        l.appendChild(m)
    }
    document.getElementById("isq" + s).appendChild(l)
}

function twostepestimated_focus(e) {
    "Estimated Quantity" == e.value && (e.value = ""), e.className = ""
}

function twostepApproximate_focus(e) {
    "Total Order Value" == e.value && (e.value = ""), e.className = ""
}

function twostepEstimated() {
    var e = document.twostep_dataform.estimatedquantity,
        t = document.getElementById("es1_t");
    return "" != e.value && "Estimated Quantity" != e.value || "" == document.getElementById("estimatedoptions").value ? "" == e.value || "Estimated Quantity" == e.value ? (e.value = "Estimated Quantity", e.classList.add("c11_p"), t.style.display = "none", !0) : (e.classList.remove("c11_p"), t.style.display = "none", !0) : (t.style.display = "block", t.innerHTML = "Please enter Quantity", !1)
}

function twostepEstimated2() {
    var e = document.twostep_dataform.estimatedquantity,
        t = document.getElementById("es1_t");
    return "" == e.value || "Estimated Quantity" == e.value ? (e.value = "Estimated Quantity", e.classList.add("c11_p"), t.style.display = "none", !0) : (e.classList.remove("c11_p"), t.style.display = "none", !0)
}

function twostepEstimatedOptn() {
    var e = document.twostep_dataform.estimatedquantity,
        t = document.getElementById("eo1_t");
    return "" != e.value && "Estimated Quantity" != e.value && "" == document.getElementById("estimatedoptions").value ? (t.style.display = "block", t.innerHTML = "Please enter Quantity Unit", !1) : (t.style.display = "none", !0)
}

function twostepApproximate() {
    var e = document.twostep_dataform.approxvalue,
        t = document.getElementById("av1_t");
    return "" != e.value && "Total Order Value" != e.value || "" == document.getElementById("approxoptions").value ? "" == e.value || "Total Order Value" == e.value ? (e.value = "Total Order Value", e.classList.add("c11_p"), t.style.display = "none", !0) : (e.classList.remove("c11_p"), t.style.display = "none", !0) : (t.style.display = "block", t.innerHTML = "Please enter Value", !1)
}

function twostepApproximate2() {
    var e = document.twostep_dataform.approxvalue,
        t = document.getElementById("av1_t");
    return "" == e.value || "Total Order Value" == e.value ? (e.value = "Total Order Value", e.classList.add("c11_p"), t.style.display = "none", !0) : (e.classList.remove("c11_p"), t.style.display = "none", !0)
}

function twostepApproxOptn() {
    var e = document.twostep_dataform.approxvalue,
        t = document.getElementById("ao1_t");
    return "" != e.value && "Total Order Value" != e.value && "" == document.getElementById("approxoptions").value ? (t.style.display = "block", t.innerHTML = "Please enter Currency", !1) : (t.style.display = "none", !0)
}

function twostepusage_focus(e) {
    "Describe your requirement in detail:" == e.value && (e.value = ""), document.getElementById("d_s2") && (document.getElementById("d_s2").style.display = "none"), e.className = ""
}

function twostepusage() {
    "" == document.twostep_dataform.usage.value ? document.twostep_dataform.usage.className = "c11_p" : document.twostep_dataform.usage.className = ""
}

function check_Fullname_twostep() {
    return foreign = 0, "+91" != document.getElementById("mobile-number_zoom_dataform").value ? foreign = 1 : foreign = 0, "none" == document.getElementById("S_name_twostep").style.display || (document.twostep_dataform.fullname.value = document.twostep_dataform.fullname.value.replace(/^\s+/, ""), 1 != foreign || "" != document.twostep_dataform.fullname.value && "Enter your name" != document.twostep_dataform.fullname.value ? "Enter your name" == document.twostep_dataform.fullname.value ? (document.twostep_dataform.fullname.className = "c11_p", document.getElementById("f1_t").style.display = "none", !0) : "" == document.twostep_dataform.fullname.value || /^\s+$/.test(document.twostep_dataform.fullname.value) || /^[A-z][A-z. ]{0,42}$/.test(document.twostep_dataform.fullname.value) ? ("" == document.getElementById("fullname").value ? (document.getElementById("fullname").value = "Enter your name", document.twostep_dataform.fullname.className = "c11_p", document.getElementById("f1_t").style.display = "none") : (document.twostep_dataform.fullname.className = "", document.getElementById("f1_t").style.display = "none"), !0) : (document.getElementById("f1_t").style.display = "block", document.getElementById("f1_t").innerHTML = "Please enter valid name.", document.twostep_dataform.fullname.className = "", !1) : (document.getElementById("f1_t").style.display = "block", document.getElementById("f1_t").innerHTML = "Please enter your name.", document.twostep_dataform.fullname.className = "c11_p", !1))
}

function check_Moblie_twostep() {
    if ("none" == document.getElementById("mob_twostep").style.display) return !0;
    "Enter your phone number" != document.twostep_dataform.S_mobile.value && (document.twostep_dataform.S_mobile.value = document.twostep_dataform.S_mobile.value.replace(/\s+/g, "")), document.twostep_dataform.S_mobile.value = document.twostep_dataform.S_mobile.value.replace(/^0+/, "");
    var e = /^[0-9]{1,30}$/.test(document.twostep_dataform.S_mobile.value);
    if ("" == document.twostep_dataform.S_mobile.value || "Enter your phone number" == document.twostep_dataform.S_mobile.value) document.twostep_dataform.S_mobile.value = "Enter your phone number", document.twostep_dataform.S_mobile.className = "c11_p", document.getElementById("m1_t").style.display = "none";
    else {
        if (!e) return document.getElementById("m1_t").style.display = "block", document.getElementById("m1_t").innerHTML = "Please enter valid phone number.", document.twostep_dataform.S_mobile.className = "", $(".tdw_pp_f1,.tdw_pp_f2,.tdw_pp_f2Nusr").addClass("tdw_err"), !1;
        document.getElementById("m1_t").style.display = "none", document.twostep_dataform.S_mobile.className = ""
    }
    return !0
}

function check_Email_twostep() {
    if ("none" == document.getElementById("email_twostep").style.display) return !0;
    if ("Enter your email" == document.twostep_dataform.S_email.value) document.twostep_dataform.S_email.className = "c11_p", document.getElementById("e1_t").style.display = "none";
    else {
        if ("" != document.twostep_dataform.S_email.value && !/^[A-z0-9][_.A-z0-9-]+@[a-zA-Z0-9]+[\.\-\_]{0,1}[a-zA-Z0-9]+\.[a-zA-Z]{2,6}\.?[a-zA-Z]{0,4}$/.test(document.twostep_dataform.S_email.value)) return document.getElementById("e1_t").style.display = "block", document.getElementById("e1_t").innerHTML = "Please enter valid email.", $(".tdw_pp_f1,.tdw_pp_f2,.tdw_pp_f2Nusr").addClass("tdw_err"), document.twostep_dataform.S_email.className = "", !1;
        "" == document.getElementById("S_email_twostep").value ? (document.getElementById("S_email_twostep").value = "Enter your email", document.twostep_dataform.S_email.className = "c11_p", document.getElementById("e1_t").style.display = "none") : (document.twostep_dataform.S_email.className = "", document.getElementById("e1_t").style.display = "none")
    }
    return !0
}

function check_Fullname_twostep2() {
    if ("none" == document.getElementById("fullname").style.display) return !0;
    "Enter your name" != document.twostep_dataform.fullname.value && "" != document.getElementById("fullname").value || (document.getElementById("fullname").value = "Enter your name", document.twostep_dataform.fullname.className = "c11_p")
}

function check_Compname_twostep2() {
    if ("none" == document.getElementById("S_comp_twostep").style.display) return !0;
    "Company / Business Name" != document.twostep_dataform.S_comp_twostep.value && "" != document.getElementById("S_comp_twostep").value || (document.getElementById("S_comp_twostep").value = "Company / Business Name", document.twostep_dataform.S_comp_twostep.className = "c11_p")
}

function check_Website_twostep2() {
    if ("none" == document.getElementById("S_web_twostep").style.display) return !0;
    "Website URL" != document.twostep_dataform.S_web_twostep.value && "" != document.getElementById("S_web_twostep").value || (document.getElementById("S_web_twostep").value = "Website URL", document.twostep_dataform.S_web_twostep.className = "c11_p")
}

function check_Moblie_twostep2() {
    x = document.twostep_dataform.S_mobile.value, "" != x && "Enter your phone number" != x || (document.twostep_dataform.S_mobile.value = "Enter your phone number", document.twostep_dataform.S_mobile.className = "c11_p")
}

function check_Email_twostep2() {
    if ("none" == document.getElementById("S_email_twostep").style.display) return !0;
    x = document.twostep_dataform.S_email.value, "Enter your email" != x && "" != x || (document.getElementById("S_email_twostep").value = "Enter your email", document.twostep_dataform.S_email.className = "c11_p")
}

function check_Fullname_focus_twostep(e) {
    "Enter your name" == e.value && (e.value = ""), e.className = "", document.getElementById("f1_t").style.display = "none"
}

function check_Compname_focus_twostep(e) {
    "Company / Business Name" == e.value && (e.value = ""), e.className = "", document.getElementById("f2_t").style.display = "none"
}

function check_website_focus_twostep(e) {
    "Website URL" == e.value && (e.value = ""), e.className = "", document.getElementById("f3_t").style.display = "none"
}

function check_Description_twostep() {
    var e = document.twostep_dataform.usage.placeholder;
    return document.twostep_dataform.usage.value = document.twostep_dataform.usage.value.replace(/^\s+/g, ""), "" == document.twostep_dataform.usage.value || document.twostep_dataform.usage.value == e ? (document.getElementById("d_s2").style.display = "block", document.getElementById("d_s2").innerHTML = "Kindly describe your requirement.", !1) : (document.twostep_dataform.usage.className = "Desc_err_sms", document.getElementById("d_s2").style.display = "none", !0)
}

function check_mobile_focus_twostep(e) {
    "Enter your phone number" == e.value && (e.value = "", e.className = ""), document.getElementById("m1_t").style.display = "none", $(".tdw_pp_f1,.tdw_pp_f2,.tdw_pp_f2Nusr").removeClass("tdw_err")
}

function check_Email_focus_twostep(e) {
    "Enter your email" == e.value && (e.value = ""), e.className = "", document.getElementById("e1_t").style.display = "none", $(".tdw_pp_f1,.tdw_pp_f2,.tdw_pp_f2Nusr").removeClass("tdw_err")
}

function validate_twostep_popup() {
    if (null != typeof jQuery) {
        var e = document.zoom_dataform.enqform_type.value,
            t = document.zoom_dataform.enqform_cta.value;
        "Send_sms_email" == e ? _gaq.push(["b._trackEvent", "Body", t + "_S2/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#autozoom/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "AutoZoom_S2/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#getBestQuote/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_S2/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#getLatestPrice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetLatestPrice_S2/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#gbq_video/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S2/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#imagezoomup/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "ProductImage_S2/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#IMInterested/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "IMInterested_S2/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#askforprice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "AskForPrice_S2/2/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : _gaq.push(["b._trackEvent", "Body", "additionaldetail/thankyou", "" + PC_CLNT_TMPL_PATH]);
        var a = check_Fullname_twostep(),
            n = check_Email_twostep(),
            s = check_Moblie_twostep(),
            o = "Send_sms_email" != e || check_Description_twostep();
        return "Send_sms_email" != e && a && n && s || "Send_sms_email" == e && s && n && a && o ? ("Enter your email" == document.twostep_dataform.S_email.value && (document.twostep_dataform.S_email.value = ""), "Enter your name" == document.twostep_dataform.fullname.value && (document.twostep_dataform.fullname.value = ""), "Enter your mobile" == document.twostep_dataform.S_mobile.value && (document.twostep_dataform.S_mobile.value = ""), $(".enqload").html("<img  src='https://tdw.imimg.com/template-tdw/loading.gif' alt='Please wait'>"), $.post($("#gbq").attr("action"), $("#gbq").serialize(), function(a) {
            return $(".enqload").html(""), "enter" == a && ("Send_sms_email" == e ? _gaq.push(["b._trackEvent", "Body", t + "_S2/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#autozoom/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "AutoZoom_S2/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#getBestQuote/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_S2/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#getLatestPrice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetLatestPrice_S2/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#imagezoomup/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "ProductImage_S2/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#gbq_video/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "GetBestQuote_video_S2/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#IMInterested/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "IMInterested_S2/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : document.zoom_dataform.S_reference_text.value == "#askforprice/" + pagenameqw ? _gaq.push(["b._trackEvent", "Body", "AskForPrice_S2/3/" + pagenameqw, "" + PC_CLNT_TMPL_PATH]) : _gaq.push(["b._trackEvent", "Body", "additionaldetail/thankyou", "" + PC_CLNT_TMPL_PATH]), $("#twostepenquiry").hide(), (cookie1 = getCartCookie("ImeshVisitor")) > "" && ("" == getparamVal1(cookie1, "uv") && "IN" == getparamVal1(cookie1, "iso") && 1 == showotpflag ? callthridstep() : ($("#infocus_div").hide(), $("#imgbox").hide(), $("#contInfo").hide(), $("#productform").addClass("tdw_w100"), $("#dataform_alert_display").show(), setTimeout(function() {
                fg_hideform_zoom()
            }, 4e3)))), !1
        }), !1) : (0 == a ? $("#fullname").trigger("focus") : 0 == s ? $("#S_mob_twostep").trigger("focus") : 0 == n ? $("#S_email_twostep").trigger("focus") : 0 == o && "Send_sms_email" == e && $("#non_prd_desc").trigger("focus"), !1)
    }
    return !1
}

function fillOpt_det() {
    var e = localStorage.getItem("ISQ");
    e = JSON.parse(e);
    var t = document.getElementById("gbq"),
        a = document.getElementById("OPTION_DESC"),
        n = document.getElementById("OPTION_ID"),
        s = document.getElementById("ISQ_DESC"),
        o = document.getElementById("ISQ_ID");
    a.value = "", n.value = "", s.value = "", o.value = "";
    for (var l = 0; l < t.length; l++) "fullname" != t[l].id && "S_email_twostep" != t[l].id && "S_mob_twostep" != t[l].id && "twostep_mobile-number_zoom_dataform" != t[l].id && "S_comp_twostep" != t[l].id && "S_web_twostep" != t[l].id && ("INPUT" == t[l].tagName ? "text" == t[l].type ? "" != t[l].value && (t[l].value = t[l].value.replace(/##/g, ""), a.value += t[l].value + "##", n.value += t[l].id + "##", s.value += t[l].getAttribute("masterdesc") + "##", o.value += t[l].getAttribute("masterid") + "##") : t[l].checked && (t[l].value = t[l].value.replace(/##/g, ""), a.value += t[l].value + "##", n.value += t[l].id + "##", s.value += t[l].getAttribute("masterdesc") + "##", o.value += t[l].getAttribute("masterid") + "##") : "select-one" == t[l].type && "Select a value" != t[l].value && t[l][t[l].selectedIndex] && (null != $('input[name="' + t[l].name + '"]').val() && "" != $('input[name="' + t[l].name + '"]').val() || (t[l][t[l].selectedIndex].value = t[l][t[l].selectedIndex].value.replace(/##/g, ""), a.value += t[l][t[l].selectedIndex].value + "##", n.value += t[l][t[l].selectedIndex].id + "##", s.value += t[l][t[l].selectedIndex].getAttribute("masterdesc") + "##", o.value += t[l][t[l].selectedIndex].getAttribute("masterid") + "##")));
    var d = a.value;
    "" != d && ("##" == d.slice(-2) && (d = d.slice(0, -2)), a.value = d), "" != (d = n.value) && ("##" == d.slice(-2) && (d = d.slice(0, -2)), n.value = d), "" != (d = s.value) && ("##" == d.slice(-2) && (d = d.slice(0, -2)), s.value = d), "" != (d = o.value) && ("##" == d.slice(-2) && (d = d.slice(0, -2)), o.value = d)
}