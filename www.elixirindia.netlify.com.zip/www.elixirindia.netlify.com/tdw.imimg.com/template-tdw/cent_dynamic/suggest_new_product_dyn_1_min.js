var ZoomElementNamesHash = new im_elementHash("S_name", "S_name", "S_lname", "S_lname", "S_email", "S_email", "S_cmobile", "S_cmobile", "S_phone_country_code", "S_phone_country_code", "S_organization", "S_organization", "S_country", "S_country", "country", "country", "S_mobile", "S_mobile", "S_glusr_id", "S_glusr_id", "S_fullname", "fullname"),
    ZoomElementNamesHash_two = new im_elementHash("S_name", "S_name", "S_lname", "S_lname", "S_email", "S_email", "S_cmobile", "S_cmobile", "S_phone_country_code", "S_phone_country_code", "S_country", "S_country", "country", "country", "S_mobile", "S_mobile", "S_fullname", "fullname", "S_glusr_id", "S_glusr_id");

function fill_cookies() {
    document.getElementById("dataform_alert_display").style.display = "none", "function" == typeof im_getCookieValues && im_getCookieValues("zoom_dataform", ZoomElementNamesHash);
    var o = document.zoom_dataform.S_phone_country_code.value.replace("+", ""),
        e = document.zoom_dataform.country.value.toLowerCase(),
        a = $(".country-list").find("li[data-country-code=" + e + "_ctry]").find("span").html();
    sync_country_flag("+" + o, e, a), document.zoom_dataform.country_iso.value = document.zoom_dataform.country.value, (cookie1 = getCartCookie("ImeshVisitor")) > "" && ("" != getparamVal1(cookie1, "mb1") && (document.zoom_dataform.S_mobile.value = getparamVal1(cookie1, "mb1"), document.zoom_dataform.S_mobile.className = ""), "" != getparamVal1(cookie1, "em") ? (document.zoom_dataform.S_email.value = getparamVal1(cookie1, "em"), document.zoom_dataform.S_email.className = "") : (document.zoom_dataform.S_email.value = "Enter your email", document.zoom_dataform.S_email.className = "c11_p"), "" != getparamVal1(cookie1, "fn") ? (document.zoom_dataform.fullname.value = getparamVal1(cookie1, "fn"), document.zoom_dataform.fullname.classList.remove("c11_p")) : (document.zoom_dataform.fullname.value = "Enter your name", document.zoom_dataform.fullname.classList.add("c11_p")))
}
$(document).ready(function() {
    $(".validate_pop.req_pop").keypress(function(o) {
        if (13 == o.keyCode) return $(this).trigger("blur"), $("#SubmitEnq").trigger("click"), !0
    }), $(".submit_form_pop").click(function() {
        $("form[name=zoom_dataform]").trigger("submit")
    }), $(".submit_twostep").click(function() {
        $("form[name=twostep_dataform]").trigger("submit")
    }), "function" == typeof fill_cookies ? fill_cookies() : setTimeout(function() {
        fill_cookies()
    }, 1e3), $(".open_form1").click(function() {
        document.getElementById("dataform_alert_display").style.display = "none", "function" == typeof im_getCookieValues && im_getCookieValues("zoom_dataform", ZoomElementNamesHash)
    }), $(".open_form").click(function() {
        document.getElementById("dataform_alrt").style.display = "block"
    }), $(document).keydown(function(o) {
        return 27 == o.keyCode && fg_hideform_zoom(), !0
    })
}), $(window).load(function() {
    $.ajaxSetup({
        cache: !0
    }), "function" == typeof getCookieValues1 && getCookieValues1()
}), $("#fullname, #fullnamefs").change(function() {
    var o = $(this).val().split(" ");
    $("#firstname, #firstnamefs").val(o[0]), o.shift(), o.join(" ") ? $("#lastname", "#lastnamefs").val(o.join(" ")) : $("#lastname, #lastnamefs").val(" ")
});
var country_fetched = 0;

function ipcheck() {
    if (1 == country_fetched) return !0;
    "" != im_readCookie("ImeshVisitor") && (!1, fill_cookies()), get_ip(), country_fetched = 1
}