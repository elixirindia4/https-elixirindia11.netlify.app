var launchnew = 0;
var launch = 1;

function nextlan() {
    launch++;
    if (document.getElementById('launch' + launch)) {
        document.getElementById('launch' + launch).className = "don";
        var launchnew = launch - 1;
        document.getElementById('launch' + launchnew).className = "doff";
    } else {
        launch--;
    }
}

function prelan() {
    if (document.getElementById('launch' + launch) && launch > 1) {
        launch--;
        document.getElementById('launch' + launch).className = "don";
        var launchnew = launch + 1;
        document.getElementById('launch' + launchnew).className = "doff";
    }
}