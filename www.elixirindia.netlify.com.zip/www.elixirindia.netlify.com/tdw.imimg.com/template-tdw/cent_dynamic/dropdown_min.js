var ver = "3.0.1D",
    m1 = new Object;
m1.name = "m1", m1.fnm = "so-", (!window.lastm || window.lastm < 1) && (lastm = 1), m1.v17 = null, m1.v17Timeout = "";
var maxZ = 3e3;
m1.v18, m1.targetFrame;
var docLoaded = !1;

function openNewWindow() {
    window.open(drop_pdf_url, "_blank");
    try {
        _gaq.push(["b._trackEvent", "Top", "download_brochure", "" + PC_CLNT_TMPL_PATH])
    } catch (e) {}
}

function openPaywithim() {
    window.open(drop_paylink, "_blank");
    try {
        _gaq.push(["b._trackEvent", "Top", "paywithim", "" + PC_CLNT_TMPL_PATH])
    } catch (e) {}
}
m1.bIncBorder = !0, m1.v29 = null, m1.v29Str = "", m1.v55 = 50, m1.scrollStep = 10, m1.fadingSteps = 2, m1.itemOverDelay = 0, m1.transTLO = 0, m1.fixSB = 0, m1.v21 = ".", m1.maxlev = 2, m1.v22 = 0, m1.sepH = 10, m1.bHlNL = 1, m1.showA = 1, m1.bVarWidth = 0, m1.bShowDel = 50, m1.scrDel = 0, m1.v23 = 246, "undefined" != typeof PC_CLNT_TMPL_PATH && "d0055" == PC_CLNT_TMPL_PATH ? m1.v23 = 224 : "undefined" != typeof PC_CLNT_TMPL_PATH && "d0050" == PC_CLNT_TMPL_PATH ? m1.v23 = 200 : "undefined" != typeof PC_CLNT_TMPL_PATH && "d0005" == PC_CLNT_TMPL_PATH ? m1.v23 = 160 : "undefined" != typeof PC_CLNT_TMPL_PATH && "d0051" == PC_CLNT_TMPL_PATH && (m1.v23 = 194), m1.levelOffset = -1, m1.levelOffsety = 2, m1.bord = 1, m1.vertSpace = 8, m1.sep = 1, m1.v19 = !1, m1.bkv = 0, m1.rev = 0, m1.shs = 0, m1.xOff = 0, m1.yOff = 0, m1.v20 = !1, m1.cntFrame = "", m1.menuFrame = "", m1.v24 = "", m1.mout = !0, m1.iconSize = 8, m1.closeDelay = 1e3, m1.tlmOrigBg = "#000000", m1.tlmOrigCol = "Black", m1.v25 = !1, m1.v52 = !1, m1.v60 = 0, m1.v11 = !1, m1.v10 = 0, m1.ppLeftPad = 5, m1.opacity = .5, m1.v54 = 0, m1.v01 = 2, m1.tlmHlBg = "#F4F4F4", m1.tlmHlCol = "White", m1.menuHorizontal = !0, m1.scrollHeight = 6, m1mn1 = drop_product, m1mn3 = drop_profile, absPath = "", m1.v19 && !m1.v20 && (window.location.href.lastIndexOf("\\") > window.location.href.lastIndexOf("/") ? sepCh = "\\" : sepCh = "/", absPath = window.location.href.substring(0, window.location.href.lastIndexOf(sepCh) + 1)), m1.v61 = 0, m1.v02 = m1.v23;
var drop_down_arr = {
    2376: {
        drpwid: "17px",
        drpclr1: "#262626",
        drpfont: "Roboto Condensed,Helvetica,sans-serif",
        drpclr2: "#be2a11",
        drpbrdclr: "#6d6b6b"
    },
    2381: {
        drpwid: "17px",
        drpclr1: "#262626",
        drpfont: "Roboto Condensed,Helvetica,sans-serif",
        drpclr2: "#2980b9",
        drpbrdclr: "#6d6b6b"
    },
    2382: {
        drpwid: "17px",
        drpclr1: "#262626",
        drpfont: "Roboto Condensed,Helvetica,sans-serif",
        drpclr2: "#309e40",
        drpbrdclr: "#6d6b6b"
    },
    2383: {
        drpwid: "17px",
        drpclr1: "#262626",
        drpfont: "Roboto Condensed,Helvetica,sans-serif",
        drpclr2: "#e6ae03",
        drpbrdclr: "#6d6b6b"
    },
    2384: {
        drpwid: "19px",
        drpclr1: "#050505",
        drpfont: "Open Sans,sans-seriff",
        drpclr2: drop_color,
        drpbrdclr: "#4b4542"
    },
    2367: {
        drpwid: "14px",
        drpclr1: "#262626",
        drpfont: "Arial,Helvetica,sans-serif",
        drpclr2: "#0c7c5e",
        drpbrdclr: "#2c2c2c"
    },
    1155: {
        drpwid: "11px",
        drpclr1: "#c1a400",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#FAE882",
        drpbrdclr: "#cfb93b"
    },
    1156: {
        drpwid: "11px",
        drpclr1: "#6d0000",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#d85901",
        drpbrdclr: "#a42626"
    },
    1157: {
        drpwid: "11px",
        drpclr1: "#404040",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#F8AD00",
        drpbrdclr: "#595959"
    },
    1158: {
        drpwid: "11px",
        drpclr1: "#859b2b",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#C94C00",
        drpbrdclr: "#6c801c"
    },
    1159: {
        drpwid: "11px",
        drpclr1: "#EA9B03",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#D3D3D3",
        drpbrdclr: "#D88F02"
    },
    1160: {
        drpwid: "11px",
        drpclr1: "#424242",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#F7631B",
        drpbrdclr: "#5F5F5F"
    },
    1161: {
        drpwid: "11px",
        drpclr1: "#925A22",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#E36A1A",
        drpbrdclr: "#B47646"
    },
    1163: {
        drpwid: "11px",
        drpclr1: "#2F2E2F",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#FE9600",
        drpbrdclr: "#666566"
    },
    1164: {
        drpwid: "11px",
        drpclr1: "#c1a400",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#FAE882",
        drpbrdclr: "#cfb93b"
    },
    1165: {
        drpwid: "11px",
        drpclr1: "#5B422A",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#D95C02",
        drpbrdclr: "#795F46"
    },
    1166: {
        drpwid: "11px",
        drpclr1: "#ca4065",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#c1234e",
        drpbrdclr: "#f1618a"
    },
    1167: {
        drpwid: "11px",
        drpclr1: "#A62500",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#D36402",
        drpbrdclr: "#B55136"
    },
    1169: {
        drpwid: "11px",
        drpclr1: "#466500",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#F69200",
        drpbrdclr: "#6E8D27"
    },
    1170: {
        drpwid: "11px",
        drpclr1: "#424242",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#F6DC5F",
        drpbrdclr: "#5F5F5F"
    },
    1171: {
        drpwid: "11px",
        drpclr1: "#ea4e01",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#ffe23a",
        drpbrdclr: "#f47333"
    },
    1173: {
        drpwid: "11px",
        drpclr1: "#2F2E2F",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#AA3209",
        drpbrdclr: "#5A595A"
    },
    1174: {
        drpwid: "11px",
        drpclr1: "#5B422A",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#D95C02",
        drpbrdclr: "#795F46"
    },
    1192: {
        drpwid: "11px",
        drpclr1: "#405563",
        drpfont: "verdana,Arial,Helvetica",
        drpclr2: "#C69915",
        drpbrdclr: "#8A98A3"
    },
    2369: {
        drpwid: "14px",
        drpclr1: "#262626",
        drpfont: "Open Sans, sans-serif",
        drpclr2: "#ab0f0f",
        drpbrdclr: "#6d6b6b"
    }
};
for (key in drop_down_arr)
    if (PC_CLNT_STYLE_ID == key)
        for (skey in drop_down_arr[key]) "drpwid" == skey && (drpwid = drop_down_arr[key][skey]), "drpclr1" == skey && (drpclr1 = drop_down_arr[key][skey]), "drpfont" == skey && (drpfont = drop_down_arr[key][skey]), "drpclr2" == skey && (drpclr2 = drop_down_arr[key][skey]), "drpbrdclr" == skey && (drpbrdclr = drop_down_arr[key][skey]);

function zz(e, t) {
    return e ? e.document.getElementById(t) : document.getElementById(t)
}

function f33(e) {
    return e && -1 == e.indexOf(":/") && -1 == e.indexOf(":\\") && 0 != e.indexOf("/") ? unescape(absPath) + e : e
}

function addLoadHandler(e) {
    e && (document.loadHandlers ? (document.lastLoadHandler++, document.loadHandlers[document.lastLoadHandler] = e) : (document.loadHandlers = new Array, document.loadHandlers[0] = e, document.lastLoadHandler = 0))
}

function f32() {
    return !0
}

function f01(e, t, r, n, d, o) {
    (e || o) && (n && (t.style.MozOpacity = r && 100 != e ? e / 100 : "0.999"), d && (t.style.filter = r ? "alpha(opacity=" + e + ")" : ""))
}

function f02(e, t, r) {
    var n = zz(e.v18, t);
    if (n && !(e.transTLO && n.level > 0)) {
        var d = zz(e.v18, t + "bgWnd"),
            o = e.v60 ? e.v60 : 100;
        f01((e.fadingSteps - r) * o / e.fadingSteps, n, 1, 1, 1, 1), d && f01(100, d, 0, 0, e.v11, 1), r <= 0 || setTimeout("f02(" + e.name + ",'" + t + "'," + (r - 1) + ")", e.bShowDel / e.fadingSteps)
    }
}

function f04(e, t, r) {
    e.style.width = t - r + "px", e.offsetWidth > t - r && (e.style.width = t - parseInt(e.style.paddingLeft) - parseInt(e.style.paddingRight) + "px")
}

function f56(e, t) {
    if (!e) return "";
    var r = t ? e.indexOf(t + ":") : -2;
    if (-1 != r) {
        var n = e.indexOf(";", r + 2);
        return -1 == n && (n = e.length), e.substring(r + 2, n)
    }
    return ""
}

function f05(q, v12, level, v04, nsi) {
    var ppName = v12 + "pp",
        pp = zz(q.v18, ppName);
    if (pp) return pp;
    q.v17 && q.v17.id == ppName && (q.v17 = null);
    var v09 = q.attr;
    level > 0 && (q.v02 = q.v23);
    var oldv02 = q.v02;
    pp = q.v18.document.createElement("DIV"), pp.style.opacity = "0.9", "undefined" == typeof PC_CLNT_TMPL_PATH || "d0055" != PC_CLNT_TMPL_PATH && "d0051" != PC_CLNT_TMPL_PATH && "d0005" != PC_CLNT_TMPL_PATH && "d0050" != PC_CLNT_TMPL_PATH || (pp.style.opacity = "1"), q.v18.document.body.appendChild(pp), pp.id = ppName, pp.v04 = v04, pp.level = level, pp.v05 = v09[5], "m1mn2" == v12 && (pp.v05 = "#f0f0f0"), pp.v06 = v09[3], "m1mn2" == v12 && (pp.v06 = "#000000");
    var c1 = v09[4];
    "m1mn2" == v12 && (c1 = "#BFD2EA");
    var prop = eval("document." + v12 + "prop");
    if (prop) {
        var pw = f56(prop, "w");
        pw && (q.v02 = parseInt(pw));
        var bc = f56(prop, "p");
        bc && (c1 = bc)
    }
    with(pp.v07 = v09[7], "m1mn2" == v12 && (pp.v07 = "#6070B1"), pp.v08 = c1, pp.scrVis = !1, pp.style) zIndex = maxZ, position = "absolute", overflow = "hidden", width = q.v02 + "px", q.v11 ? backgroundColor = "" : (borderColor = q.borderCol, "m1mn2" == v12 && (borderColor = "#ffffff", q.borderCol = "#ffffff"), backgroundColor = c1, borderWidth = "0px", borderStyle = "solid");
    pp.q = q, f30(pp, "mouseout", f15, !1), f30(pp, "mouseover", f14, !1);
    var v31 = 0,
        bgWnd = q.v18.document.createElement("DIV");
    pp.appendChild(bgWnd), bgWnd.id = pp.id + "bgWnd", bgWnd.style.position = "absolute", bgWnd.style.top = q.v10 + "px", bgWnd.style.width = q.v02 - 2 * q.bord + "px", bgWnd.innerHTML = "<font size='1'>&nbsp;</font>", bgWnd.style.backgroundColor = c1, q.v55 && f03(q, pp, pp.id + "scrollUp", "javascript:scrollUp(" + q.name + ",'" + pp.id + "');", "(^1)", null, v09, !0, v31, bgWnd);
    var array = eval(v12),
        v13;
    for (v13 = 0; v13 < array.length / 5; v13++) {
        var fold = array[5 * v13 + 2],
            v30 = fold ? v12 + "_" + parseInt(v13 + 1) : null,
            options = array[5 * v13 + 4];
        v31 += f03(q, pp, null, array[5 * v13 + 1], array[5 * v13], v30, v09, v13 == array.length / 5 - 1, v31, bgWnd, array[5 * v13 + 3], options)
    }
    q.v55 && f03(q, pp, pp.id + "scrollDown", "javascript:scrollDown(" + q.name + ",'" + pp.id + "');", "(^2)", null, v09, !0, v31, bgWnd);
    var v28 = 0;
    return pp.style.height = v31 + 2 * q.bord + v28 + "px", pp.maxHeight = v31 + 2 * q.bord, bgWnd.style.height = v31 - q.v10 - v28 + "px", pp.offsetHeight > v31 + 2 * q.bord + v28 && (pp.style.height = v31 + "px", q.bIncBorder = !1, pp.maxHeight = v31), q.v02 = oldv02, pp
}

function f03(q, pp, id, v27, v26, v30, v09, bLast, v31, parent, target, opt) {
    if ("-" == v26) return q.sepH;
    var itemType = 0;
    v26 && -1 != v26.indexOf("(^1)") && (itemType = 1), v26 && -1 != v26.indexOf("(^2)") && (itemType = 2);
    var itemWnd = q.v18.document.createElement("DIV");
    if (pp.appendChild(itemWnd), mac) {
        var brWnd = q.v18.document.createElement("BR");
        pp.appendChild(brWnd)
    }
    with(f30(itemWnd, "mouseover", f22, !1), f30(itemWnd, "mouseout", f23, !1), f30(itemWnd, "click", f20, !1), f30(itemWnd, "dblclick", f20, !1), itemWnd.owner = pp, itemWnd.id = id, itemWnd.style) position = "absolute", top = 2 == itemType ? v31 - q.scrollHeight + "px" : v31 + "px", cursor = v27 ? !IE4 || version >= 7 ? "pointer" : "hand" : "default", color || (color = v09[3]), q.v11 ? left = q.ppLeftPad + q.vertSpace + "px" : bLast || (borderBottomColor = q.borderCol, borderBottomWidth = q.sep + "px", borderBottomStyle = "dashed", "undefined" == typeof PC_CLNT_TMPL_PATH || "d0055" != PC_CLNT_TMPL_PATH && "d0050" != PC_CLNT_TMPL_PATH && "d0051" != PC_CLNT_TMPL_PATH && "d0005" != PC_CLNT_TMPL_PATH || (borderBottomStyle = "solid")), itemType || (padding = q.vertSpace + "px"), paddingLeft = q.ppLeftPad + q.vertSpace + q.v54 + "px", paddingRight = (q.v01 < q.iconSize ? q.iconSize : q.v01) + q.vertSpace + "px", fontSize = v09[0], fontWeight = v09[1] ? "bold" : "300", fontStyle = v09[2] ? "italic" : "normal", fontFamily = v09[6], textAlign = 1 == q.v22 ? "center" : 2 == q.v22 ? "right" : "left", f04(itemWnd, q.v11 ? q.v02 - q.ppLeftPad - q.v01 - 2 * q.vertSpace : q.v02, 2 * q.bord);
    if (v30 && (itemWnd.v30 = v30), itemType > 0) {
        var arrow = q.v18.document.createElement("IMG");
        itemWnd.appendChild(arrow);
        var arrowSrc = f33(q.v21);
        arrow.src = 1 == itemType ? "https://tdw.imimg.com/template-tdw/so-sup.gif" : "https://tdw.imimg.com/template-tdw/so-sdown.gif", arrow.setAttribute("HEIGHT", "6", "WIDTH", "5"), arrow.className = 1 == itemType ? "up" : "down", itemWnd.style.textAlign = "center", itemWnd.style.display = "block"
    } else itemWnd.innerHTML = v26;
    if (q.v56 && 0 == v27.indexOf(q.v56) ? itemWnd.url = q.v57 + v27.substring(q.v56.length) : itemWnd.url = f33(v27), itemWnd.f54 = v26, itemWnd.target = target, v30 && q.showA) {
        var expandArrow = q.v18.document.createElement("IMG");
        itemWnd.appendChild(expandArrow);
        var v03 = f33(q.v21);
        with(expandArrow.src = "ts/" + q.fnm + "ia.gif", expandArrow.style) {
            width = q.iconSize + "px", height = q.iconSize + "px", position = "absolute-bottom; padding-top:500px;";
            var itemRect = f19(q, itemWnd);
            top = (itemRect.bottom - itemRect.top) / 2 - q.iconSize / 2 + "px", left = itemWnd.offsetWidth - q.iconSize - 1 + "px"
        }
    }
    if (opt) {
        itemWnd.customBg = f56(opt, "b"), itemWnd.customCl = f56(opt, "c"), itemWnd.status = f56(opt, "s");
        var h = f56(opt, "h");
        h && (itemWnd.style.fontWeight = h);
        var i = f56(opt, "i");
        i && (itemWnd.style.fontStyle = i)
    }
    return itemWnd.status || -1 == itemWnd.url.indexOf("<root>") || (itemWnd.status = itemWnd.url.replace("<root>", "/")), itemWnd.offsetHeight
}

function f35(e, t) {
    for (var r = 1;;) {
        var n = "HideItem";
        r > 1 && (n += r);
        var d = zz(e, n);
        if (!d) break;
        d.style.visibility = t ? "visible" : "hidden", r++
    }
}

function f06(e, t, r) {
    -1 == t.indexOf("_") && (f35(e.v18, 1), e.actm && r && chgBg(e, e.actm, 0, 1)), e.v29 && (e.v29Str = null, clearTimeout(e.v29));
    var n = zz(e.v18, t);
    n && (n.v14 && f06(e, n.v14.id), n.v04 && (n.v04.v14 = null), IE4 && version >= 6 && e.v11 ? n.style.clip = "rect(0,-1,-1,0)" : (n.style.visibility = "hidden", n.style.opacity = .9, "undefined" == typeof PC_CLNT_TMPL_PATH || "d0055" != PC_CLNT_TMPL_PATH && "d0050" != PC_CLNT_TMPL_PATH && "d0051" != PC_CLNT_TMPL_PATH && "d0005" != PC_CLNT_TMPL_PATH || (n.style.opacity = "1"), n.style.display = "none")), e.v17 && e.v17.id == t && (e.v17 = null)
}

function f07(e, t, r) {
    return new rct(e.left - t, e.top - r, e.right - t, e.bottom - r)
}

function f34(e, t, r) {
    for (var n = t.getElementsByTagName("DIV"), d = 0; d < n.length; d++) r == n[d] || n[d].id && -1 != n[d].id.indexOf("scroll") || (n[d].style.backgroundColor = t.q.v11 ? "transparent" : n[d].customBg ? n[d].customBg : t.v08, n[d].style.color = n[d].customCl ? n[d].customCl : t.v06)
}

function f08(e, t, r, n, d, o) {
    if (-1 == t.id.indexOf("_") && f35(e.v18, 0), !e.v17 || e.v17.id != t.id) {
        t.style.left = r + "px";
        var i = 0;
        "number" == typeof window.innerWidth ? (window.innerWidth, i = window.innerHeight) : document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight) ? (document.documentElement.clientWidth, i = document.documentElement.clientHeight) : document.body && (document.body.clientWidth || document.body.clientHeight) && (document.body.clientWidth, i = document.body.clientHeight);
        var l = t.style.height;
        abcnew = l.replace("1px", "");
        var a = i + (window.pageYOffset || document.body.scrollTop || document.documentElement.scrollTop),
            p = parseInt(n) + parseInt(abcnew),
            c = n - abcnew,
            v = a - n;
        t.style.top = p >= a && n > v ? c + "px" : n + "px", IE4 && version >= 6 && e.v11 ? t.style.clip = "rect(auto,auto,auto,auto)" : (t.style.display = "", t.style.visibility = "visible");
        var f = f19(e, t),
            m = f17(e.v18),
            s = t.offsetHeight < t.maxHeight;
        f.right > m.right && (o && o.id && -1 == o.id.indexOf("tlm") ? t.style.left = Math.max(0, o.offsetLeft - t.offsetWidth + e.levelOffset) + "px" : t.style.left = m.right - t.offsetWidth - 5 + "px");
        var u = zz(e.v18, t.id + "scrollDown"),
            b = zz(e.v18, t.id + "scrollUp"),
            h = mac ? 15 : e.bIncBorder ? 3 : 20;
        if ((f.bottom > m.bottom || s) && !NS60) {
            var y = m.bottom - t.offsetHeight - h;
            if (e.menuHorizontal || (d = !1), e.v55 && (y < 0 || d || s)) {
                var T = Math.min(t.maxHeight, m.bottom - t.offsetTop - h - (e.bIncBorder ? 0 : 2 * e.bord));
                T > 50 ? (t.scrVis = T != t.maxHeight, f09(e, t, m.top, T)) : t.style.top = n + "px"
            } else t.style.top = y + "px"
        }
        e.v55 && (u.style.display = t.scrVis ? "" : "none", b.style.display = t.scrVis ? "" : "none"), e.bShowDel && !mac && f02(e, t.id, e.fadingSteps), f34(e, t, null)
    }
}

function f09(e, t, r, n) {
    var d = zz(e.v18, t.id + "scrollDown"),
        o = zz(e.v18, t.id + "scrollUp"),
        i = zz(e.v18, t.id + "bgWnd");
    e.v55 && (d.style.zIndex = maxZ + 1, o.style.zIndex = maxZ + 1), t.style.height = n + "px", i.style.height = n - e.v10 - 2 * e.bord - 0 + "px", e.v55 && (d.style.top = n - 0 - e.scrollHeight - (e.bIncBorder ? 2 * e.bord : 0) - 10 + "px", f10(e, t.id, 0))
}

function f10(e, t, r) {
    var n = zz(e.v18, t),
        d = f19(e, n),
        o = n.getElementsByTagName("DIV"),
        i = r > 0 ? 0 : o.length - 1,
        l = r > 0 ? 1 : -1,
        a = !0,
        p = r * e.scrollStep;
    if (n.scrVis) try {
        d.top += e.scrollHeight, d.bottom -= e.scrollHeight
    } catch (e) {}
    try {
        d.bottom -= 2 * e.bord
    } catch (e) {}
    for (; i < o.length && i >= 0; i += l) {
        var c = o[i];
        if (!c.id || -1 == c.id.indexOf("scroll") && -1 == c.id.indexOf("bgWnd")) {
            var v = f19(e, c);
            a && 0 == r && (p = n.maxHeight - (c.offsetTop + c.offsetHeight) + (n.scrVis ? e.scrollHeight : 0) - (e.bIncBorder ? 2 * e.bord : 0) - 0);
            var f = f07(d, v.left, v.top + p);
            if (r > 0 && f.top < -e.scrollHeight && a) return;
            if (r < 0 && v.bottom < d.bottom - 0 && a) return;
            0 != p && (c.style.top = c.offsetTop + p + "px"), mac || (c.style.clip = "rect(" + f.top + "," + f.right + "," + f.bottom + "," + f.left + ")"), f.bottom < 0 || f.top > c.offsetHeight ? c.style.visibility = "hidden" : c.style.visibility = "visible", a = !1
        }
    }
    n.scrPos ? n.scrPos += p : n.scrPos = p
}

function scrollUp(e, t) {
    f10(e, t, 1)
}

function scrollDown(e, t) {
    f10(e, t, -1)
}

function f13(e, t) {
    for (var r = e.v17; r;) {
        if (r.id == t.id) return !0;
        r = r.v14
    }
    return !1
}

function f14() {
    var e = this.q;
    e.v17 && e.v58 && f13(e, this) && clearTimeout(e.v58)
}

function f15() {
    f15Impl(this.q, this)
}

function f15Impl(e, t, r) {
    t || r || (t = e.v17), t || (t = zz(e.v18, r + "pp")), t && e.mout && e.v17 && f13(e, t) && (e.v58 && clearTimeout(e.v58), e.v58 = setTimeout("f06(" + e.name + ",'" + e.v17.id + "',1);", 500))
}

function rct(e, t, r, n) {
    this.left = e, this.top = t, this.right = r, this.bottom = n
}

function f17(e) {
    var t, r, n = 0,
        d = 0;
    return e.pageXOffset ? n = e.pageXOffset : e.document.documentElement.scrollLeft ? n = e.document.documentElement.scrollLeft : e.document.body.scrollLeft && (n = e.document.body.scrollLeft), e.pageYOffset ? d = e.pageYOffset : e.document.documentElement.scrollTop ? d = e.document.documentElement.scrollTop : e.document.body.scrollTop && (d = e.document.body.scrollTop), e.innerWidth ? t = n + e.innerWidth : e.document.documentElement.clientWidth ? t = n + e.document.documentElement.clientWidth : e.document.body.clientWidth && (t = n + e.document.body.clientWidth), e.innerHeight ? r = d + e.innerHeight : e.document.documentElement.clientHeight ? r = d + e.document.documentElement.clientHeight : e.document.body.clientHeight && (r = d + e.document.body.clientHeight), r > 300 && e.name && (r = 300), new rct(n, d, t, r)
}

function f18(e, t) {
    var r = e ? e.v18.document : document,
        n = mac ? parseInt(r.body.leftMargin) : 0,
        d = mac ? parseInt(r.body.topMargin) : 0,
        o = t,
        i = r.documentElement;
    for (i || (i = r.body); o && (n += parseInt(o.offsetLeft), d += parseInt(o.offsetTop), o.offsetParent != o && o.offsetParent != i);) o = o.offsetParent;
    return new rct(n, d, n + parseInt(t.offsetWidth), d + parseInt(t.offsetHeight))
}

function f19(e, t) {
    return (mac || DOM || Opera7) && t.getBoundingClientRect ? t.getBoundingClientRect() : f18(e, t)
}

function f53(e, t) {
    if (e.frames) {
        if (e.frames[t]) return e.frames[t];
        for (var r = 0; r < e.frames.length; r++) try {
            if (e.frames[r].name == t) return e.frames[r];
            var n = f53(e.frames[r], t);
            if (n) return n
        } catch (e) {}
    }
    return null
}

function f20() {
    var e = this.f54.indexOf("\x3c!--");
    if (-1 != e) this.f54.indexOf("--\x3e", e);
    else {
        this.owner.q.cntFrame ? " in frame " + this.owner.q.cntFrame : "in current window/frame."
    }
    window.location = this.url
}

function f21(q) {
    q.v29Str && (eval(q.v29Str), q.v29 && clearTimeout(q.v29), q.v29 = setTimeout("f21(" + q.name + ")", q.v55))
}

function f22() {
    var e = this.owner.q;
    if (this.id && -1 != this.id.indexOf("scroll")) {
        e.v29Str = this.url;
        var t = e.v29Str.indexOf("javascript:");
        return -1 != t && (e.v29Str = e.v29Str.substring(t)), void f21(e)
    }
    f34(e, this.owner, this), (e.bHlNL || this.url || this.v30) && (this.style.color = this.owner.v05, this.style.backgroundColor = !this.owner.v07 && e.v11 ? "transparent" : this.owner.v07), e.itemOverDelay ? (e.v59 && clearTimeout(e.v59), e.itemOverObj = this, e.v59 = setTimeout("f222 (" + e.name + ",null)", e.itemOverDelay)) : f222(e, this)
}

function f222(e, t) {
    var r = t || e.itemOverObj;
    if (r) {
        var n = 0;
        if (r.owner.v14 && (r.v30 && r.v30 + "pp" == r.owner.v14.id && (n = 1), n || f06(e, r.owner.v14.id)), r.status ? window.status = r.status : r.url && -1 == r.url.indexOf("javascript:") ? window.status = r.url : window.status = "", r.v30 && !n) {
            var d = f19(e, r),
                o = d.right - e.levelOffset,
                i = d.top - e.levelOffsety,
                l = f05(e, r.v30, r.owner.level + 1, r.owner);
            r.owner.v14 = l, f08(e, l, o, i + 2, !1, r.owner)
        }
    }
}

function f23() {
    var e = this.owner.q;
    e.v29 && (e.v29Str = null, clearTimeout(e.v29)), this.id && -1 != this.id.indexOf("scroll") || (window.status = "")
}

function exM(e, t, r, n, d, o, i, l) {
    if (docLoaded) {
        if ("none" == t) return !e.itemOverDelay && e.v17 ? f06(e, e.v17.id) : f15Impl(e), void(e.v58 && clearTimeout(e.v58));
        var a, p, c;
        e.v19 && e.v20;
        "coords" == r ? ((a = f18(e, zz(0, e.name + "tl"))).left = a.left + d, a.top = a.top + o, a.right = a.left + i, a.bottom = a.top + l) : a = f18(e, zz(0, r)), e.bVarWidth && !e.v11 && (e.v02 = a.right - a.left + (IE4 ? 2 * e.bord : 0)), p = a.left - e.bord, c = a.bottom + e.v61, e.itemOverDelay ? (e.v59 && clearTimeout(e.v59), e.v59 = setTimeout("exM2 (" + e.name + ",'" + t + "','" + r + "'," + p + "," + c + ")", e.itemOverDelay)) : exM2(e, t, r, p, c)
    }
}

function exM1(e, t, r, n, d, o, i, l) {
    if (docLoaded) {
        if ("none" == t) return !e.itemOverDelay && e.v17 ? f06(e, e.v17.id) : f15Impl(e), void(e.v58 && clearTimeout(e.v58));
        var a, p, c;
        e.v19 && e.v20;
        "coords" == r ? ((a = f18(e, zz(0, e.name + "tl"))).left = a.left + d, a.top = a.top + o, a.right = a.left + i, a.bottom = a.top + l) : a = f18(e, zz(0, r)), e.bVarWidth && !e.v11 && (e.v02 = a.right - a.left + (IE4 ? 2 * e.bord : 0)), p = a.right - e.bord, c = a.top + e.v61, e.itemOverDelay ? (e.v59 && clearTimeout(e.v59), e.v59 = setTimeout("exM2 (" + e.name + ",'" + t + "','" + r + "'," + p + "," + c + ")", e.itemOverDelay)) : exM2(e, t, r, p, c)
    }
}

function exM2(e, t, r, n, d) {
    e.v58 && clearTimeout(e.v58), e.v17 && e.v17.id != t + "pp" && f06(e, e.v17.id);
    var o = f05(e, t, 0, null, r);
    f08(e, o, n + e.xOff, d + e.yOff, !0, null), e.v17 = o
}

function coM(e, t) {
    docLoaded && (clearTimeout(e.v59), f15Impl(e))
}

function f28() {
    var nmn;
    for (nmn = 1; nmn <= lastm; nmn++) {
        var q = eval("window.m" + nmn);
        q && q.v17 && f06(q, q.v17.id, 1)
    }
}

function f29() {
    if (!docLoaded) {
        var nmn;
        for (nmn = 1; nmn <= lastm; nmn++) {
            var q = eval("window.m" + nmn);
            q && (q.v18 = q.v19 && !q.v20 ? f53(window.top, q.v24) : window, q.targetFrame = q.v19 ? f53(window.top, q.cntFrame) : window, q.mout || f30(q.v18.document, "mousedown", f28, !1))
        }
        docLoaded = !0
    }
}

function f30(obj, event, fun, bubble) {
    obj.addEventListener ? obj.addEventListener(event, fun, bubble) : eval("obj.on" + event + "=" + fun)
}

function chgBg(e, t, r, n) {
    if ((IE4 || DOM || Opera7) && !e.v52) {
        var d = zz(0, t),
            o = zz(0, t + "a"),
            i = d.bgc ? d.bgc : e.tlmOrigBg,
            l = e.tlmHlBg,
            a = d.tc ? d.tc : e.tlmOrigCol;
        if (0 == r) n && (e.v25 || (d.style.background = i, d.style.color = a), o && (o.style.color = a));
        else {
            var p = !d.tc || !d.bgc;
            e.actm && e.actm != t && chgBg(e, e.actm, 0, 1), e.v25 || (1 & r && (p && (d.bgc = d.bgColor), d.style.background = l), p && (d.tc = d.style.color), d.style.color = e.tlmHlCol), o && 2 & r && (p && (d.tc = o.style.color), o.style.color = e.tlmHlCol), e.actm = t, p && (d.tc || (d.tc = a), d.bgc || (d.bgc = i))
        }
    }
}

function f31() {
    var i, l = document.lastLoadHandler;
    for (document.lastLoadHandler = -1, i = 0; i <= l; i++) {
        var h = document.loadHandlers[i];
        if ("function" != typeof h) {
            var bPar = -1 == h.indexOf("(");
            eval(h + (bPar ? "();" : ";"))
        } else h()
    }
}
fontclr1 = fontclr2 = "#FFFFFF", "1155" != PC_CLNT_STYLE_ID && "1159" != PC_CLNT_STYLE_ID && "1164" != PC_CLNT_STYLE_ID || (fontclr1 = "#000"), "1155" != PC_CLNT_STYLE_ID && "1157" != PC_CLNT_STYLE_ID && "1159" != PC_CLNT_STYLE_ID && "1164" != PC_CLNT_STYLE_ID && "1169" != PC_CLNT_STYLE_ID && "1170" != PC_CLNT_STYLE_ID && "1171" != PC_CLNT_STYLE_ID && "1174" != PC_CLNT_STYLE_ID || (fontclr2 = "#000"), "undefined" == typeof PC_CLNT_TMPL_PATH || "d0055" != PC_CLNT_TMPL_PATH && "d0057" != PC_CLNT_TMPL_PATH && "d0050" != PC_CLNT_TMPL_PATH && "d0051" != PC_CLNT_TMPL_PATH && "d0005" != PC_CLNT_TMPL_PATH ? (m1.attr = new Array("19px", !1, !1, "#FFFFFF", "#050505", "#FFFFFF", "Roboto Condensed,Helvetica,sans-serif", drop_color, "#FFFFFF", "#FFFFFF"), m1.borderCol = "#4b4542") : (m1.attr = new Array(drpwid, !1, !1, fontclr1, drpclr1, fontclr2, drpfont, drpclr2, "#FFFFFF", "#FFFFFF"), m1.borderCol = drpbrdclr), NS60 = -1 != navigator.userAgent.indexOf("Netscape6/6.0"), Opera = -1 != navigator.userAgent.indexOf("Opera") || -1 != navigator.appName.indexOf("Opera") || window.opera, Opera7 = Opera && null != document.createElement && null != document.addEventListener, IE4 = document.all && !Opera, mac = IE4 && -1 != navigator.appVersion.indexOf("Mac"), DOM = document.documentElement && !IE4 && !Opera, IE4 && (av = navigator.appVersion, avi = av.indexOf("MSIE"), -1 == avi ? version = parseInt(av) : version = parseInt(av.substr(avi + 4))), addLoadHandler("f29"), addLoadHandler(window.onload), window.onerror = f32;