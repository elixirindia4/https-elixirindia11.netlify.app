(function(factory) {
    if (typeof define === "function" && define.amd) {
        define(["jquery"], function($) {
            factory($, window, document);
        });
    } else {
        factory(jQuery, window, document);
    }
})(function($, window, document, undefined) {
    "use strict";
    var pluginName = "intlTelInputs",
        id = 1,
        defaults = {
            autoFormat: true,
            autoHideDialCode: true,
            defaultCountry: "in_ctry",
            ipinfoToken: "",
            nationalMode: false,
            numberType: "MOBILE",
            onlyCountries: [],
            preferredCountries: ["in_ctry", "us_ctry", "ae_ctry", "uk_ctry", "au_ctry"],
            responsiveDropdown: false,
            utilsScript: ""
        },
        keys = {
            UP: 38,
            DOWN: 40,
            ENTER: 13,
            ESC: 27,
            PLUS: 43,
            A: 65,
            Z: 90,
            ZERO: 48,
            NINE: 57,
            SPACE: 32,
            BSPACE: 8,
            DEL: 46,
            CTRL: 17,
            CMD1: 91,
            CMD2: 224
        },
        windowLoaded = false;
    $(window).load(function() {
        windowLoaded = true;
    });

    function Plugin(element, options) {
        this.element = element;
        this.options = $.extend({}, defaults, options);
        this._defaults = defaults;
        this.ns = "." + pluginName + id++;
        this.isGoodBrowser = Boolean(element.setSelectionRange);
        this.hadInitialPlaceholder = Boolean($(element).attr("placeholder"));
        this._name = pluginName;
        this.init();
    }
    Plugin.prototype = {
        init: function() {
            var that = this;
            if (this.options.defaultCountry == "auto") {
                this.options.defaultCountry = "";
                var ipinfoURL = "//ipinfo.io";
                if (this.options.ipinfoToken) {
                    ipinfoURL += "?token=" + this.options.ipinfoToken;
                }
                $.get(ipinfoURL, function(response) {
                    if (response && response.country) {
                        that.options.defaultCountry = response.country.toLowerCase();
                    }
                }, "jsonp").always(function() {
                    that._ready();
                });
            } else {
                this._ready();
            }
        },
        _ready: function() {
            if (this.options.nationalMode) {
                this.options.autoHideDialCode = false;
            }
            if (navigator.userAgent.match(/IEMobile/i)) {
                this.options.autoFormat = false;
            }
            if (window.innerWidth < 500) {
                this.options.responsiveDropdown = true;
            }
            this._processCountryData();
            this._generateMarkup();
            this._setInitialState();
            this._initListeners();
        },
        _processCountryData: function() {
            this._setInstanceCountryData();
            this._setPreferredCountries();
        },
        _addCountryCode: function(iso2, dialCode, priority) {
            if (!(dialCode in this.countryCodes)) {
                this.countryCodes[dialCode] = [];
            }
            var index = priority || 0;
            this.countryCodes[dialCode][index] = iso2;
        },
        _setInstanceCountryData: function() {
            var i;
            if (this.options.onlyCountries.length) {
                this.countries = [];
                for (i = 0; i < allCountries.length; i++) {
                    if ($.inArray(allCountries[i].iso2, this.options.onlyCountries) != -1) {
                        this.countries.push(allCountries[i]);
                    }
                }
            } else {
                this.countries = allCountries;
            }
            this.countryCodes = {};
            for (i = 0; i < this.countries.length; i++) {
                var c = this.countries[i];
                this._addCountryCode(c.iso2, c.dialCode, c.priority);
                if (c.areaCodes) {
                    for (var j = 0; j < c.areaCodes.length; j++) {
                        this._addCountryCode(c.iso2, c.dialCode + c.areaCodes[j]);
                    }
                }
            }
        },
        _setPreferredCountries: function() {
            this.preferredCountries = [];
            for (var i = 0; i < this.options.preferredCountries.length; i++) {
                var countryCode = this.options.preferredCountries[i],
                    countryData = this._getCountryData(countryCode, false, true);
                if (countryData) {
                    this.preferredCountries.push(countryData);
                }
            }
        },
        _generateMarkup: function() {
            this.telInput = $(this.element);
            this.telInput.wrap($("<div>", {
                "class": "intl-tel-input"
            }));
            var flagsContainer = $("<div>", {
                "class": "flag-dropdown"
            }).insertAfter(this.telInput);
            var selectedFlag = $("<div>", {
                "class": "selected-flag"
            }).appendTo(flagsContainer);
            this.selectedFlagInner = $("<div>", {
                "class": "flag_ctry"
            }).appendTo(selectedFlag);
            $("<div>", {
                "class": "arrow_ctry"
            }).appendTo(this.selectedFlagInner);
            this.countryList = $("<ul>", {
                "class": "country-list ft5_p v-hide_ctry"
            }).appendTo(flagsContainer);
            if (this.preferredCountries.length) {
                this._appendListItems(this.preferredCountries, "preferred");
                $("<li>", {
                    "class": "divider_ctry"
                }).appendTo(this.countryList);
            }
            this._appendListItems(this.countries, "");
            this.dropdownHeight = this.countryList.outerHeight();
            this.countryList.removeClass("v-hide_ctry").addClass("hide_ctry");
            if (this.options.responsiveDropdown) {
                this.countryList.outerWidth(this.telInput.outerWidth());
            }
            this.countryListItems = this.countryList.children(".country_ctry");
        },
        _appendListItems: function(countries, className) {
            var tmp = "";
            for (var i = 0; i < countries.length; i++) {
                var c = countries[i];
                tmp += "<li class='country_ctry " + className + "' data-dial-code='" + c.dialCode + "' data-country-code='" + c.iso2 + "'>";
                tmp += "<div class='flag_ctry " + c.iso2 + "'></div>";
                tmp += "<span class='country-name'>" + c.name + "</span>";
                tmp += "<span class='dial-code_crty'>+" + c.dialCode + "</span>";
                tmp += "</li>";
            }
            this.countryList.append(tmp);
        },
        _setInitialState: function() {
            var val = this.telInput.val();
            if (this._getDialCode(val)) {
                this._updateFlagFromNumber(val);
            } else {
                var defaultCountry;
                if (this.options.defaultCountry) {
                    defaultCountry = this._getCountryData(this.options.defaultCountry, false, false);
                } else {
                    defaultCountry = this.preferredCountries.length ? this.preferredCountries[0] : this.countries[0];
                }
                this._selectFlag(defaultCountry.iso2);
                if (!val) {
                    this._updateDialCode(defaultCountry.dialCode, false);
                }
            }
            if (val) {
                this._updateVal(val, false);
            }
        },
        _initListeners: function() {
            var that = this;
            this._initKeyListeners();
            if (this.options.autoHideDialCode || this.options.autoFormat) {
                this._initFocusListeners();
            }
            var label = this.telInput.closest("label");
            if (label.length) {
                label.on("click" + this.ns, function(e) {
                    if (that.countryList.hasClass("hide_ctry")) {
                        that.telInput.focus();
                    } else {
                        e.preventDefault();
                    }
                });
            }
            var selectedFlag = this.selectedFlagInner.parent();
            selectedFlag.on("click" + this.ns, function(e) {
                if (that.countryList.hasClass("hide_ctry") && !that.telInput.prop("disabled")) {
                    that._showDropdown();
                }
            });
            if (this.options.utilsScript) {
                if (windowLoaded) {
                    this.loadUtils();
                } else {
                    $(window).load(function() {
                        that.loadUtils();
                    });
                }
            }
        },
        _initKeyListeners: function() {
            var that = this;
            if (this.options.autoFormat) {
                this.telInput.on("keypress" + this.ns, function(e) {
                    if (e.which >= keys.SPACE && !e.metaKey && window.intlTelInputUtils) {
                        e.preventDefault();
                        var isAllowedKey = e.which >= keys.ZERO && e.which <= keys.NINE || e.which == keys.PLUS,
                            input = that.telInput[0],
                            noSelection = that.isGoodBrowser && input.selectionStart == input.selectionEnd,
                            max = that.telInput.attr("maxlength"),
                            isBelowMax = max ? that.telInput.val().length < max : true;
                        if (isBelowMax && (isAllowedKey || noSelection)) {
                            var newChar = isAllowedKey ? String.fromCharCode(e.which) : null;
                            that._handleInputKey(newChar, true);
                        }
                        if (!isAllowedKey) {
                            that.telInput.trigger("invalidkey");
                        }
                    }
                });
            }
            this.telInput.on("keyup" + this.ns, function(e) {
                if (e.which == keys.ENTER) {} else if (that.options.autoFormat && window.intlTelInputUtils) {
                    var isCtrl = e.which == keys.CTRL || e.which == keys.CMD1 || e.which == keys.CMD2,
                        input = that.telInput[0],
                        noSelection = that.isGoodBrowser && input.selectionStart == input.selectionEnd,
                        cursorAtEnd = that.isGoodBrowser && input.selectionStart == that.telInput.val().length;
                    if (e.which == keys.DEL && !cursorAtEnd || e.which == keys.BSPACE || isCtrl && noSelection) {
                        that._handleInputKey(null, isCtrl && cursorAtEnd);
                    }
                    if (!that.options.nationalMode) {
                        var val = that.telInput.val();
                        if (val.substr(0, 1) != "+") {
                            var newCursorPos = that.isGoodBrowser ? input.selectionStart + 1 : 0;
                            that.telInput.val("+" + val);
                            if (that.isGoodBrowser) {
                                input.setSelectionRange(newCursorPos, newCursorPos);
                            }
                        }
                    }
                } else {
                    that._updateFlagFromNumber(that.telInput.val());
                }
            });
        },
        _handleInputKey: function(newNumericChar, addSuffix) {
            var val = this.telInput.val(),
                newCursor = null,
                cursorAtEnd = false,
                input = this.telInput[0];
            if (this.isGoodBrowser) {
                var selectionEnd = input.selectionEnd,
                    originalLen = val.length;
                cursorAtEnd = selectionEnd == originalLen;
                if (newNumericChar) {
                    val = val.substr(0, input.selectionStart) + newNumericChar + val.substring(selectionEnd, originalLen);
                    if (!cursorAtEnd) {
                        newCursor = selectionEnd + (val.length - originalLen);
                    }
                } else {
                    newCursor = input.selectionStart;
                }
            } else if (newNumericChar) {
                val += newNumericChar;
            }
            this.setNumber(val, addSuffix);
            if (this.isGoodBrowser) {
                if (cursorAtEnd) {
                    newCursor = this.telInput.val().length;
                }
                input.setSelectionRange(newCursor, newCursor);
            }
        },
        _initFocusListeners: function() {
            var that = this;
            if (this.options.autoHideDialCode) {
                this.telInput.on("mousedown" + this.ns, function(e) {
                    if (!that.telInput.is(":focus") && !that.telInput.val()) {
                        e.preventDefault();
                        that.telInput.focus();
                    }
                });
            }
            this.telInput.on("focus" + this.ns, function() {
                var value = that.telInput.val();
                that.telInput.data("focusVal", value);
                if (that.options.autoHideDialCode) {
                    if (!value) {
                        that._updateVal("+" + that.selectedCountryData.dialCode, true);
                        that.telInput.one("keypress.plus" + that.ns, function(e) {
                            if (e.which == keys.PLUS) {
                                var newVal = that.options.autoFormat && window.intlTelInputUtils ? "+" : "";
                                that.telInput.val(newVal);
                            }
                        });
                        setTimeout(function() {
                            var input = that.telInput[0];
                            if (that.isGoodBrowser) {
                                var len = that.telInput.val().length;
                                input.setSelectionRange(len, len);
                            }
                        });
                    }
                }
            });
            this.telInput.on("blur" + this.ns, function() {
                if (that.options.autoHideDialCode) {
                    var value = that.telInput.val(),
                        startsPlus = value.substr(0, 1) == "+";
                    if (startsPlus) {
                        var numeric = that._getNumeric(value);
                        if (!numeric || that.selectedCountryData.dialCode == numeric) {}
                    }
                    that.telInput.off("keypress.plus" + that.ns);
                }
                if (that.options.autoFormat && window.intlTelInputUtils && that.telInput.val() != that.telInput.data("focusVal")) {
                    that.telInput.trigger("change");
                }
            });
        },
        _getNumeric: function(s) {
            return s.replace(/\D/g, "");
        },
        _showDropdown: function() {
            this._setDropdownPosition();
            var activeListItem = this.countryList.children(".active");
            this._highlightListItem(activeListItem);
            this.countryList.removeClass("hide_ctry");
            this._scrollTo(activeListItem);
            this._bindDropdownListeners();
            this.selectedFlagInner.children(".arrow_ctry").addClass("up_ctry");
        },
        _setDropdownPosition: function() {
            var inputTop = this.telInput.offset().top,
                windowTop = $(window).scrollTop(),
                dropdownFitsBelow = inputTop + this.telInput.outerHeight() + this.dropdownHeight < windowTop + $(window).height(),
                dropdownFitsAbove = inputTop - this.dropdownHeight > windowTop;
            var cssTop = !dropdownFitsBelow && dropdownFitsAbove ? "-" + (this.dropdownHeight - 1) + "px" : "";
            this.countryList.css("top", cssTop);
        },
        _bindDropdownListeners: function() {
            var that = this;
            this.countryList.on("mouseover" + this.ns, ".country_ctry", function(e) {
                that._highlightListItem($(this));
            });
            this.countryList.on("click" + this.ns, ".country_ctry", function(e) {
                that._selectListItem($(this));
            });
            var isOpening = true;
            $("html").on("click" + this.ns, function(e) {
                if (!isOpening) {
                    that._closeDropdown();
                }
                isOpening = false;
            });
            var query = "",
                queryTimer = null;
            $(document).on("keydown" + this.ns, function(e) {
                e.preventDefault();
                if (e.which == keys.UP || e.which == keys.DOWN) {
                    that._handleUpDownKey(e.which);
                } else if (e.which == keys.ENTER) {
                    that._handleEnterKey();
                } else if (e.which == keys.ESC) {
                    that._closeDropdown();
                } else if (e.which >= keys.A && e.which <= keys.Z || e.which == keys.SPACE) {
                    if (queryTimer) {
                        clearTimeout(queryTimer);
                    }
                    query += String.fromCharCode(e.which);
                    that._searchForCountry(query);
                    queryTimer = setTimeout(function() {
                        query = "";
                    }, 1e3);
                }
            });
        },
        _handleUpDownKey: function(key) {
            var current = this.countryList.children(".highlight_ctry").first();
            var next = key == keys.UP ? current.prev() : current.next();
            if (next.length) {
                if (next.hasClass("divider_ctry")) {
                    next = key == keys.UP ? next.prev() : next.next();
                }
                this._highlightListItem(next);
                this._scrollTo(next);
            }
        },
        _handleEnterKey: function() {
            var currentCountry = this.countryList.children(".highlight_ctry").first();
            if (currentCountry.length) {
                this._selectListItem(currentCountry);
            }
        },
        _searchForCountry: function(query) {
            for (var i = 0; i < this.countries.length; i++) {
                if (this._startsWith(this.countries[i].name, query)) {
                    var listItem = this.countryList.children("[data-country-code=" + this.countries[i].iso2 + " ]").not(".preferred");
                    this._highlightListItem(listItem);
                    this._scrollTo(listItem, true);
                    break;
                }
            }
        },
        _startsWith: function(a, b) {
            return a.substr(0, b.length).toUpperCase() == b;
        },
        _updateVal: function(val, addSuffix) {
            var formatted;
            if (this.options.autoFormat && window.intlTelInputUtils) {
                formatted = intlTelInputUtils.formatNumber(val, this.selectedCountryData.iso2, addSuffix);
                var max = this.telInput.attr("maxlength");
                if (max && formatted.length > max) {
                    formatted = formatted.substr(0, max);
                }
            } else {
                formatted = val;
            }
            this.telInput.val(formatted);
        },
        _updateFlagFromNumber: function(number) {
            if (this.options.nationalMode && this.selectedCountryData && this.selectedCountryData.dialCode == "1" && number.substr(0, 1) != "+") {
                number = "+1" + number;
            }
            var dialCode = this._getDialCode(number);
            if (dialCode) {
                var countryCodes = this.countryCodes[this._getNumeric(dialCode)],
                    alreadySelected = false;
                if (this.selectedCountryData) {
                    for (var i = 0; i < countryCodes.length; i++) {
                        if (countryCodes[i] == this.selectedCountryData.iso2) {
                            alreadySelected = true;
                        }
                    }
                }
                if (!alreadySelected || this._isUnknownNanp(number, dialCode)) {
                    for (var j = 0; j < countryCodes.length; j++) {
                        if (countryCodes[j]) {
                            this._selectFlag(countryCodes[j]);
                            break;
                        }
                    }
                }
            }
        },
        _isUnknownNanp: function(number, dialCode) {
            return dialCode == "+1" && this._getNumeric(number).length >= 4;
        },
        _highlightListItem: function(listItem) {
            this.countryListItems.removeClass("highlight_ctry");
            listItem.addClass("highlight_ctry");
        },
        _getCountryData: function(countryCode, ignoreOnlyCountriesOption, allowFail) {
            var countryList = ignoreOnlyCountriesOption ? allCountries : this.countries;
            for (var i = 0; i < countryList.length; i++) {
                if (countryList[i].iso2 == countryCode) {
                    return countryList[i];
                }
            }
            if (allowFail) {
                return null;
            } else {
                throw new Error("No country data for '" + countryCode + "'");
            }
        },
        _selectFlag: function(countryCode) {
            this.selectedCountryData = this._getCountryData(countryCode, false, false);
            var ctry_code = countryCode.toUpperCase();
            ctry_code = ctry_code.substr(0, 2);
            this.selectedFlagInner.attr("class", "flag_ctry " + countryCode);
            var ccode = "+" + this.selectedCountryData.dialCode;
            var cname = this.selectedCountryData.name;
            var indexof = cname.indexOf("(");
            if (indexof != -1) {
                cname = cname.substr(0, indexof);
            }
            $.trim(cname);
            sync_country_flag(ccode, ctry_code, cname, countryCode);
            var title = this.selectedCountryData.name + ": +" + this.selectedCountryData.dialCode;
            this._updatePlaceholder();
            var listItem = this.countryListItems.children(".flag_ctry." + countryCode).first().parent();
            this.countryListItems.removeClass("active");
            listItem.addClass("active");
        },
        _updatePlaceholder: function() {
            if (window.intlTelInputUtils && !this.hadInitialPlaceholder) {
                var iso2 = this.selectedCountryData.iso2,
                    numberType = intlTelInputUtils.numberType[this.options.numberType || "FIXED_LINE"],
                    placeholder = intlTelInputUtils.getExampleNumber(iso2, this.options.nationalMode, numberType);
                this.telInput.attr("placeholder", placeholder);
            }
        },
        _selectListItem: function(listItem) {
            var countryCode = listItem.attr("data-country-code");
            this._selectFlag(countryCode);
            this._closeDropdown();
            this._updateDialCode(listItem.attr("data-dial-code"), true);
            this.telInput.trigger("change");
            this.telInput.focus();
        },
        _closeDropdown: function() {
            this.countryList.addClass("hide_ctry");
            this.selectedFlagInner.children(".arrow_ctry").removeClass("up_ctry");
            $(document).off(this.ns);
            $("html").off(this.ns);
            this.countryList.off(this.ns);
        },
        _scrollTo: function(element, middle) {
            var container = this.countryList,
                containerHeight = container.height(),
                containerTop = container.offset().top,
                containerBottom = containerTop + containerHeight,
                elementHeight = element.outerHeight(),
                elementTop = element.offset().top,
                elementBottom = elementTop + elementHeight,
                newScrollTop = elementTop - containerTop + container.scrollTop(),
                middleOffset = containerHeight / 2 - elementHeight / 2;
            if (elementTop < containerTop) {
                if (middle) {
                    newScrollTop -= middleOffset;
                }
                container.scrollTop(newScrollTop);
            } else if (elementBottom > containerBottom) {
                if (middle) {
                    newScrollTop += middleOffset;
                }
                var heightDifference = containerHeight - elementHeight;
                container.scrollTop(newScrollTop - heightDifference);
            }
        },
        _updateDialCode: function(newDialCode, focusing) {
            var inputVal = this.telInput.val(),
                newNumber;
            newDialCode = "+" + newDialCode;
            if (this.options.nationalMode && inputVal.substr(0, 1) != "+") {
                newNumber = inputVal;
            } else if (inputVal) {
                var prevDialCode = this._getDialCode(inputVal);
                if (prevDialCode.length > 1) {
                    newNumber = inputVal.replace(prevDialCode, newDialCode);
                } else {
                    var existingNumber = inputVal.substr(0, 1) != "+" ? $.trim(inputVal) : "";
                    newNumber = newDialCode + existingNumber;
                }
            } else {
                newNumber = !this.options.autoHideDialCode || focusing ? newDialCode : "";
            }
            this._updateVal(newNumber, focusing);
        },
        _getDialCode: function(number) {
            var dialCode = "";
            if (number.charAt(0) == "+") {
                var numericChars = "";
                for (var i = 0; i < number.length; i++) {
                    var c = number.charAt(i);
                    if ($.isNumeric(c)) {
                        numericChars += c;
                        if (this.countryCodes[numericChars]) {
                            dialCode = number.substr(0, i + 1);
                        }
                        if (numericChars.length == 4) {
                            dialCode = number.substr(0, i + 1);
                        }
                    }
                }
            }
            return dialCode;
        },
        destroy: function() {
            this._closeDropdown();
            this.telInput.off(this.ns);
            this.selectedFlagInner.parent().off(this.ns);
            this.telInput.closest("label").off(this.ns);
            var container = this.telInput.parent();
            container.before(this.telInput).remove();
        },
        getCleanNumber: function() {
            if (window.intlTelInputUtils) {
                return intlTelInputUtils.formatNumberE164(this.telInput.val(), this.selectedCountryData.iso2);
            }
            return "";
        },
        getNumberType: function() {
            if (window.intlTelInputUtils) {
                return intlTelInputUtils.getNumberType(this.telInput.val(), this.selectedCountryData.iso2);
            }
            return -99;
        },
        getSelectedCountryData: function() {
            return this.selectedCountryData || {};
        },
        getValidationError: function() {
            if (window.intlTelInputUtils) {
                return intlTelInputUtils.getValidationError(this.telInput.val(), this.selectedCountryData.iso2);
            }
            return -99;
        },
        isValidNumber: function() {
            var val = $.trim(this.telInput.val()),
                countryCode = this.options.nationalMode ? this.selectedCountryData.iso2 : "",
                containsAlpha = /[a-zA-Z]/.test(val);
            if (!containsAlpha && window.intlTelInputUtils) {
                return intlTelInputUtils.isValidNumber(val, countryCode);
            }
            return false;
        },
        loadUtils: function(path) {
            var utilsScript = path || this.options.utilsScript;
            if (!$.fn[pluginName].loadedUtilsScript && utilsScript) {
                $.fn[pluginName].loadedUtilsScript = true;
                $.ajax({
                    url: utilsScript,
                    success: function() {
                        $(".intl-tel-input input").intlTelInputs("utilsLoaded");
                    },
                    dataType: "script",
                    cache: true
                });
            }
        },
        selectCountry: function(countryCode) {
            if (!this.selectedFlagInner.hasClass(countryCode)) {
                this._selectFlag(countryCode);
                this._updateDialCode(this.selectedCountryData.dialCode, false);
            }
        },
        setNumber: function(number, addSuffix) {
            if (!this.options.nationalMode && number.substr(0, 1) != "+") {
                number = "+" + number;
            }
            this._updateFlagFromNumber(number);
            this._updateVal(number, addSuffix);
        },
        utilsLoaded: function() {
            if (this.options.autoFormat && this.telInput.val()) {
                this._updateVal(this.telInput.val());
            }
            this._updatePlaceholder();
        }
    };
    $.fn[pluginName] = function(options) {
        var args = arguments;
        if (options === undefined || typeof options === "object") {
            return this.each(function() {
                if (!$.data(this, "plugin_" + pluginName)) {
                    $.data(this, "plugin_" + pluginName, new Plugin(this, options));
                }
            });
        } else if (typeof options === "string" && options[0] !== "_" && options !== "init") {
            var returns;
            this.each(function() {
                var instance = $.data(this, "plugin_" + pluginName);
                if (instance instanceof Plugin && typeof instance[options] === "function") {
                    returns = instance[options].apply(instance, Array.prototype.slice.call(args, 1));
                }
                if (options === "destroy") {
                    $.data(this, "plugin_" + pluginName, null);
                }
            });
            return returns !== undefined ? returns : this;
        }
    };
    $.fn[pluginName].getCountryData = function() {
        return allCountries;
    };
    $.fn[pluginName].setCountryData = function(obj) {
        allCountries = obj;
    };
    var allCountries = [
        ["Afghanistan", "af_ctry", "93"],
        ["Albania", "al_ctry", "355"],
        ["Algeria", "dz_ctry", "213"],
        ["American Samoa", "as_ctry", "1-684"],
        ["Andorra", "ad_ctry", "376"],
        ["Angola", "ao_ctry", "244"],
        ["Anguilla", "ai_ctry", "1-264"],
        ["Antarctica", "aq_ctry", "672"],
        ["Antigua And Barbuda", "ag_ctry", "1-268"],
        ["Argentina", "ar_ctry", "54"],
        ["Armenia", "am_ctry", "374"],
        ["Aruba", "aw_ctry", "297"],
        ["Australia", "au_ctry", "61"],
        ["Austria", "at_ctry", "43"],
        ["Azerbaijan", "az_ctry", "994"],
        ["Bahamas", "bs_ctry", "1-242"],
        ["Bahrain", "bh_ctry", "973"],
        ["Bangladesh", "bd_ctry", "880"],
        ["Barbados", "bb_ctry", "1-246"],
        ["Belarus", "by_ctry", "375"],
        ["Belgium", "be_ctry", "32"],
        ["Belize", "bz_ctry", "501"],
        ["Benin", "bj_ctry", "229"],
        ["Bermuda", "bm_ctry", "1-441"],
        ["Bhutan", "bt_ctry", "975"],
        ["Bolivia", "bo_ctry", "591"],
        ["Bosnia And Herzegovina", "ba_ctry", "387"],
        ["Botswana", "bw_ctry", "267"],
        ["Bouvet Island", "bv_ctry", "47"],
        ["Brazil", "br_ctry", "55"],
        ["British Indian Ocean Territory", "io_ctry", "246"],
        ["Brunei", "bn_ctry", "673"],
        ["Bulgaria", "bg_ctry", "359"],
        ["Burkina Faso", "bf_ctry", "226"],
        ["Burundi", "bi_ctry", "257"],
        ["Cambodia", "kh_ctry", "855"],
        ["Cameroon", "cm_ctry", "237"],
        ["Canada", "ca_ctry", "1"],
        ["Cape Verde", "cv_ctry", "238"],
        ["Cayman Islands", "ky_ctry", "1-345"],
        ["Central African Republic", "cf_ctry", "236"],
        ["Chad", "td_ctry", "235"],
        ["Chile", "cl_ctry", "56"],
        ["China", "cn_ctry", "86"],
        ["China (Hong Kong S.A.R.)", "hk_ctry", "852"],
        ["China (Macau S.A.R.)", "mo_ctry", "853"],
        ["Christmas Islands", "cx_ctry", "61"],
        ["Cocos Islands", "cc_ctry", "891"],
        ["Colombia", "co_ctry", "57"],
        ["Comoros", "km_ctry", "269"],
        ["Congo", "cg_ctry", "242"],
        ["Cook Islands", "ck_ctry", "682"],
        ["Costa Rica", "cr_ctry", "506"],
        ["Cote D Ivoire", "ci_ctry", "225"],
        ["Croatia", "hr_ctry", "385"],
        ["Cuba", "cu_ctry", "53"],
        ["Cyprus", "cy_ctry", "357"],
        ["Czech Republic", "cz_ctry", "420"],
        ["Democractic Republic Of Congo", "cd_ctry", "243"],
        ["Denmark", "dk_ctry", "45"],
        ["Djibouti", "dj_ctry", "253"],
        ["Dominica", "dm_ctry", "1-767"],
        ["Dominican Republic", "do_ctry", "1-809"],
        ["East Timor", "tl_ctry", "670"],
        ["Ecuador", "ec_ctry", "593"],
        ["Egypt", "eg_ctry", "20"],
        ["El Salvador", "sv_ctry", "503"],
        ["Equatorial Guinea", "gq_ctry", "240"],
        ["Eritrea", "er_ctry", "291"],
        ["Estonia", "ee_ctry", "372"],
        ["Ethiopia", "et_ctry", "251"],
        ["Falkland Islands", "fk_ctry", "500"],
        ["Faroe Islands", "fo_ctry", "298"],
        ["Fiji Islands", "fj_ctry", "679"],
        ["Finland", "fi_ctry", "358"],
        ["France", "fr_ctry", "33"],
        ["French Guiana", "gf_ctry", "594"],
        ["French Polynesia", "pf_ctry", "689"],
        ["French Southern Territories", "tf_ctry", "262"],
        ["Gabon", "ga_ctry", "241"],
        ["Georgia", "ge_ctry", "995"],
        ["Germany", "de_ctry", "49"],
        ["Ghana", "gh_ctry", "233"],
        ["Gibraltar", "gi_ctry", "350"],
        ["Greece", "gr_ctry", "30"],
        ["Greenland", "gl_ctry", "299"],
        ["Grenada", "gd_ctry", "1-473"],
        ["Guadeloupe", "gp_ctry", "590"],
        ["Guam", "gu_ctry", "1-671"],
        ["Guatemala", "gt_ctry", "502"],
        ["Guinea", "gn_ctry", "224"],
        ["Guinea-Bissau", "gw_ctry", "245"],
        ["Guyana", "gy_ctry", "592"],
        ["Haiti", "ht_ctry", "509"],
        ["Heard And Mcdonald Islands", "hm_ctry", "672"],
        ["Holy See", "va_ctry", "379"],
        ["Honduras", "hn_ctry", "504"],
        ["Hungary", "hu_ctry", "36"],
        ["Iceland", "is_ctry", "354"],
        ["India", "in_ctry", "91"],
        ["Indonesia", "id_ctry", "62"],
        ["Iran", "ir_ctry", "98"],
        ["Iraq", "iq_ctry", "964"],
        ["Ireland", "ie_ctry", "353"],
        ["Israel", "il_ctry", "972"],
        ["Italy", "it_ctry", "39"],
        ["Jamaica", "jm_ctry", "1-876"],
        ["Japan", "jp_ctry", "81"],
        ["Jordan", "jo_ctry", "962"],
        ["Kazakhstan", "kz_ctry", "7"],
        ["Kenya", "ke_ctry", "254"],
        ["Kiribati", "ki_ctry", "686"],
        ["Korea", "kr_ctry", "82"],
        ["Korea, North", "kp_ctry", "850"],
        ["Kuwait", "kw_ctry", "965"],
        ["Kyrgyzstan", "kg_ctry", "996"],
        ["Lao People's Democratic Republic", "la_ctry", "856"],
        ["Latvia", "lv_ctry", "371"],
        ["Lebanon", "lb_ctry", "961"],
        ["Lesotho", "ls_ctry", "266"],
        ["Liberia", "lr_ctry", "231"],
        ["Libya", "ly_ctry", "218"],
        ["Liechtenstein", "li_ctry", "423"],
        ["Lithuania", "lt_ctry", "370"],
        ["Luxembourg", "lu_ctry", "352"],
        ["Macedonia", "mk_ctry", "389"],
        ["Madagascar", "mg_ctry", "261"],
        ["Malawi", "mw_ctry", "265"],
        ["Malaysia", "my_ctry", "60"],
        ["Maldives", "mv_ctry", "960"],
        ["Mali", "ml_ctry", "223"],
        ["Malta", "mt_ctry", "356"],
        ["Marshall Islands", "mh_ctry", "692"],
        ["Martinique", "mq_ctry", "596"],
        ["Mauritania", "mr_ctry", "222"],
        ["Mauritius", "mu_ctry", "230"],
        ["Mayotte", "yt_ctry", "269"],
        ["Mexico", "mx_ctry", "52"],
        ["Micronesia", "fm_ctry", "691"],
        ["Moldova", "md_ctry", "373"],
        ["Monaco", "mc_ctry", "377"],
        ["Mongolia", "mn_ctry", "976"],
        ["Montenegro", "me_ctry", "382"],
        ["Montserrat", "ms_ctry", "1-664"],
        ["Morocco", "ma_ctry", "212"],
        ["Mozambique", "mz_ctry", "258"],
        ["Myanmar", "mm_ctry", "95"],
        ["Namibia", "na_ctry", "264"],
        ["Nauru", "nr_ctry", "674"],
        ["Nepal", "np_ctry", "977"],
        ["Netherlands Antilles", "an_ctry", "599"],
        ["New Caledonia", "nc_ctry", "687"],
        ["New Zealand", "nz_ctry", "64"],
        ["Nicaragua", "ni_ctry", "505"],
        ["Niger", "ne_ctry", "227"],
        ["Nigeria", "ng_ctry", "234"],
        ["Niue", "nu_ctry", "683"],
        ["Norfolk Island", "nf_ctry", "672"],
        ["Northern Mariana Islands", "mp_ctry", "1-670"],
        ["Norway", "no_ctry", "47"],
        ["Oman", "om_ctry", "968"],
        ["Pakistan", "pk_ctry", "92"],
        ["Palau", "pw_ctry", "680"],
        ["Palestinian National Authority", "ps_ctry", "970"],
        ["Panama", "pa_ctry", "507"],
        ["Papua New Guinea", "pg_ctry", "675"],
        ["Paraguay", "py_ctry", "595"],
        ["Peru", "pe_ctry", "51"],
        ["Philippines", "ph_ctry", "63"],
        ["Pitcairn Island", "pn_ctry", "872"],
        ["Poland", "pl_ctry", "48"],
        ["Portugal", "pt_ctry", "351"],
        ["Puerto Rico", "pr_ctry", "1"],
        ["Qatar", "qa_ctry", "974"],
        ["Reunion", "re_ctry", "262"],
        ["Romania", "ro_ctry", "40"],
        ["Russia", "ru_ctry", "7"],
        ["Rwanda", "rw_ctry", "250"],
        ["Saint Helena", "sh_ctry", "290"],
        ["Saint Kitts And Nevis", "kn_ctry", "1-869"],
        ["Saint Lucia", "lc_ctry", "1-758"],
        ["Saint Pierre And Miquelon", "pm_ctry", "508"],
        ["Saint Vincent And The Grenadin", "vc_ctry", "1-784"],
        ["Samoa", "ws_ctry", "685"],
        ["San Marino", "sm_ctry", "378"],
        ["Sao Tome And Principe", "st_ctry", "239"],
        ["Saudi Arabia", "sa_ctry", "966"],
        ["Senegal", "sn_ctry", "221"],
        ["Serbia", "rs_ctry", "381"],
        ["Serbia And Montenegro", "cs_ctry", "381"],
        ["Seychelles", "sc_ctry", "248"],
        ["Sierra Leone", "sl_ctry", "232"],
        ["Singapore", "sg_ctry", "65"],
        ["Slovakia", "sk_ctry", "421"],
        ["Slovenia", "si_ctry", "386"],
        ["Solomon Islands", "sb_ctry", "677"],
        ["Somalia", "so_ctry", "252"],
        ["South Africa", "za_ctry", "27"],
        ["South Georgia", "gs_ctry", "995"],
        ["South Sudan", "ss_ctry", "211"],
        ["Spain", "es_ctry", "34"],
        ["Sri Lanka", "lk_ctry", "94"],
        ["Sudan", "sd_ctry", "249"],
        ["Suriname", "sr_ctry", "597"],
        ["Svalbard And Jan Mayen Islands", "sj_ctry", "47"],
        ["Swaziland", "sz_ctry", "268"],
        ["Sweden", "se_ctry", "46"],
        ["Switzerland", "ch_ctry", "41"],
        ["Syria", "sy_ctry", "963"],
        ["Taiwan", "tw_ctry", "886"],
        ["Tajikistan", "tj_ctry", "992"],
        ["Tanzania", "tz_ctry", "255"],
        ["Thailand", "th_ctry", "66"],
        ["The Gambia", "gm_ctry", "220"],
        ["The Netherlands", "nl_ctry", "31"],
        ["Togo", "tg_ctry", "228"],
        ["Tokelau", "tk_ctry", "690"],
        ["Tonga", "to_ctry", "676"],
        ["Trinidad And Tobago", "tt_ctry", "1-868"],
        ["Tunisia", "tn_ctry", "216"],
        ["Turkey", "tr_ctry", "90"],
        ["Turkmenistan", "tm_ctry", "993"],
        ["Turks And Caicos Islands", "tc_ctry", "1-649"],
        ["Tuvalu", "tv_ctry", "688"],
        ["Uganda", "ug_ctry", "256"],
        ["Ukraine", "ua_ctry", "380"],
        ["United Arab Emirates", "ae_ctry", "971"],
        ["United Kingdom", "uk_ctry", "44"],
        ["United States Minor Outlying I", "um_ctry", "1"],
        ["United States Of America", "us_ctry", "1"],
        ["Uruguay", "uy_ctry", "598"],
        ["Uzbekistan", "uz_ctry", "998"],
        ["Vanuatu", "vu_ctry", "678"],
        ["Venezuela", "ve_ctry", "58"],
        ["Vietnam", "vn_ctry", "84"],
        ["Virgin Islands (British)", "vg_ctry", "1-284"],
        ["Virgin Islands (Us)", "vi_ctry", "1-340"],
        ["Wallis And Futuna Islands", "wf_ctry", "681"],
        ["Western Sahara", "eh_ctry", "212"],
        ["Yemen", "ye_ctry", "967"],
        ["Yugoslavia", "yu_ctry", "38"],
        ["Zambia", "zm_ctry", "260"],
        ["Zimbabwe", "zw_ctry", "263"]
    ];
    for (var i = 0; i < allCountries.length; i++) {
        var c = allCountries[i];
        allCountries[i] = {
            name: c[0],
            iso2: c[1],
            dialCode: c[2],
            priority: c[3] || 0,
            areaCodes: c[4] || null
        };
    }
});

function sync_country_flag(isd, iso, cname, countryCode) {
    if (countryCode == undefined) {
        countryCode = iso.toLowerCase() + "_ctry";
    }
    $('.cnty_isd').attr("placeholder", isd).val(isd);
    $('.selected-flag .flag_ctry').attr("class", "flag_ctry " + countryCode);
    $('.cnty_iso').val(iso.toUpperCase());
    $('.cnty_name').val(cname);
    check_country_flag();
    $("form").each(function(index) {
        if (this.name) {
            popupopen = this.name;
            check_country_flag();
        }
    })
}